from pathlib import Path
import subprocess,json,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');c=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a,cwd=r):return subprocess.check_output(a,cwd=cwd,text=True).strip()
m=json.loads(Path('/tmp/cpp-m27-07-plan-merge.json').read_text());assert m['merged'];rev=m['sha'];path='products/cpp-rt-car/batches/M27-07.yaml';d=yaml.safe_load(run('git','show',rev+':'+path,cwd=c))
assert not run('git','status','--porcelain');run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==d['sources']['baseline_commit'];run('git','switch','-c','agent/m27-07-native','origin/main')
d['sources'].update(control_plane_revision=rev,canonical_revision=rev,canonical_blob_sha=run('git','rev-parse',rev+':'+path,cwd=c));(r/'contracts/active-batch.yaml').write_text(yaml.safe_dump(d,sort_keys=False,width=100))
p=r/'AGENTS.md';p.write_text(p.read_text()+f'\n## M27-07 native golden host preparation\n\nOwner selected07; canonical control603 `{rev}` activates only this batch\nfrom target291. Add an optional installed Linux host using existing native XDMA\ninterfaces and frozen golden workload/codecs. Native replay stays disabled; no\ncapability spoofing. Test ordinary injected drivers and absent-device refusal;\nnever access live endpoints during verification. Preserve production and prior\nevidence. Full local/all32 exact-head checks, risk review, scoped publication,\nguarded merge and canonical closure remain mandatory and authorized.08 and\noriginal05/06 excluded work plus external qualification remain separate.\n')
out=r/'samples/golden_xdma_native';out.mkdir();(r/'tests/golden_xdma_native').mkdir()
s=(r/'samples/golden_xdma/io.hpp').read_text();s=s.replace('#include "simulated_driver.hpp"','#include "../golden_xdma/codec.hpp"\n#include <rt/xdma_backend.hpp>\n#include "configuration.hpp"').replace('namespace golden::xdma {','namespace golden::xdma::native {').replace('} // namespace golden::xdma','} // namespace golden::xdma::native')
s=s.replace('  SimulatedDriver *simulation_;\n  const bool simulated_;','  rt::XdmaDriverApi driver_;\n  Configuration config_;\n  std::uint64_t origin_;')
a=s.index('  rt::HalV2BackendRegistration\n  simulated(');b=s.index('  static rt::CallbackResult provide',a);s=s[:a]+s[b:]
a=s.index('    if (s.world_->configuration.fault == 4');b=s.index('    rt::DeviceTimelineInfo info;',a);s=s[:a]+s[b:]
s=s.replace('  explicit Io(SimulatedDriver &driver, bool simulated = true)\n      : simulation_(&driver), simulated_(simulated) {}','  Io(rt::XdmaDriverApi driver, Configuration config, std::uint64_t origin)\n      : driver_(driver), config_(std::move(config)), origin_(origin) {}')
s=s.replace('    runtime_ = &r;', '    if (!config_.valid()) return rt::Status::invalid_argument;\n    runtime_ = &r;')
s=s.replace('simulation_->api()', 'driver_').replace('simulated_ ? simulated(registration) : registration', 'registration')
s=s.replace('t.device_offset = ref ? 8192 : 0;', 't.device_offset = ref ? config_.output[lane] : config_.input[lane];')
s=s.replace("    if (simulated_)\n      binding.simulation = rt::DeviceRateSimulationPolicy{5'000'000'000ull};\n",'')
s=s.replace('application_frame(sampled, world_->buffers[c], c,','decode(sampled, world_->buffers[c], c,').replace('application_frame(host_[lane].output, world_->buffers[c], c,','decode(host_[lane].output, world_->buffers[c], c,')
s=s.replace('  void time(std::uint64_t value) noexcept { simulation_->now.store(value); }','''  // Normalize only the application copy; Runtime retains the original native
  // timestamp/checksum envelope. The FPGA must echo the nominal output template.
  bool decode(const Frame &frame, Frame &application, std::size_t channel,
              std::size_t count) const noexcept {
    Frame copy = frame;
    rt::SampledIoFrameHeader h;
    std::memcpy(&h, copy.data(), sizeof(h));
    if (h.first_sample_timestamp) {
      if (h.first_sample_timestamp < origin_ ||
          h.first_sample_timestamp - origin_ > UINT64_MAX - clock_origin)
        return false;
      h.first_sample_timestamp = clock_origin + h.first_sample_timestamp - origin_;
      std::memcpy(copy.data(), &h, sizeof(h));
    }
    return application_frame(copy, application, channel, count);
  }''')
(out/'io.hpp').write_text('// Native preparation wiring; frozen model and codecs remain in the prior kits.\n'+s)
s=(r/'samples/golden_xdma/session.hpp').read_text().replace('namespace golden::xdma {','namespace golden::xdma::native {').replace('} // namespace golden::xdma','} // namespace golden::xdma::native')
s=s.replace('  Clock clock;', '  rt::RuntimeClock &clock;\n  const std::uint64_t origin;')
s=s.replace('  Session(Options options, Jobs *jobs, Memory &memory, Io &io,\n          Physics *physics = nullptr)\n      : physics_(physics), io_(io), jobs_(jobs), memory_(memory),\n        world(options), runtime(std::in_place, clock) {}','  Session(Options options, Memory &memory, Io &io, rt::RuntimeClock &source,\n          std::uint64_t epoch)\n      : physics_(nullptr), io_(io), jobs_(nullptr), memory_(memory),\n        clock(source), origin(epoch), world(options), runtime(std::in_place, clock) {}')
s=s.replace('if (!world.options.valid())','if (!world.options.valid() || world.options.host || world.options.external ||\n        world.options.campaign != Campaign::nominal)')
s=s.replace('const bool replay_enabled = !physics_ || physics_->replay_enabled();','constexpr bool replay_enabled = false;')
s=s.replace('1000 + tick * fixed::tick_ns','origin + tick * fixed::tick_ns')
a=s.index('  void time(std::uint64_t value)');b=s.index('  template <unsigned Kind>',a)
s=s[:a]+'''  rt::Status step(std::size_t tick) noexcept {
    return runtime->step(frame(tick));
  }
'''+s[b:]
a=s.index('  std::vector<std::byte> checkpoint(');b=s.index('  rt::Status close()',a);s=s[:a]+s[b:]
(out/'session.hpp').write_text('// Native graph assembly based on the frozen golden XDMA graph; replay disabled.\n'+s)
print('Activated and created native graph wiring')
