from pathlib import Path
import subprocess,json,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24');t=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');b=r/'products/cpp-rt-car'
def run(*a,cwd=r):return subprocess.check_output(a,cwd=cwd,text=True).strip()
assert not run('git','status','--porcelain');run('git','fetch','origin','main');run('git','switch','-c','agent/cpp-m27-07-plan','origin/main')
run('git','fetch','origin','main',cwd=t);base=run('git','rev-parse','origin/main',cwd=t);assert base=='3b9fc08afc1e7c4b5e6230b80f1235477a5acbab'
p=b/'batches/M27-07.yaml';d=yaml.safe_load(p.read_text());d['sources'].update(baseline_commit=base,activation='owner_selected',owner_scope='Owner explicitly selected07 after completed owner-scoped05/06. Implement only native golden XDMA host preparation using existing adapters and frozen workloads, ordinary simulated-driver and installed-host validation. Standing scoped publication/guarded merge and completed zero-step control-only exception persist; no target/local functional waiver.08 remains planned. Original05 campaign/continuous and06 signature expansion remain unperformed.')
d['dependencies']=['M27-01','M27-06'];d['scope']['forbidden_paths'] += ['rt/','src/','include/','samples/golden_system/','samples/golden_cuda/','samples/golden_xdma/','tests/golden_system/','tests/golden_cuda/','tests/golden_xdma/','tests/runtime_robustness/','tests/release_verification/','tools/release_rebuild.py']+[f'docs/evidence/M27-0{i}-*' for i in range(1,7)]
p.write_text(yaml.safe_dump(d,sort_keys=False,width=100))
intro=f'''# M27-07 selected: native golden XDMA host preparation

Owner selected07 after target PR291 merged at `{base}` and canonical
closure602. Add a separate optional installed Linux host using the existing XDMA
adapter, explicit host staging and named tuple/configuration requirements. Preserve
the frozen golden workload, simulated kits, Runtime, ABI/defaults and prior evidence.
Validate ordinary fake-driver protocol/lifecycle/format refusals and actual installed
host compilation and absent-device refusal before device side effects. No live
endpoint is accessed by this batch. Physical FPGA/bitstream/driver behavior, safe
outputs, thermal/saturation/device-loss/endurance and RT qualification remain
unperformed pending a named approved bench.

Full local verification, all32 exact-head target checks, applicable sanitizer/static/
package/ABI checks, retained failures, risk review and guarded integration/canonical
closure remain mandatory. Standing scoped publication/merge authority persists;
only completed zero-step control infrastructure failures have the existing exception.
M27-08 stays planned. Original05 campaign/continuous and06 signature expansion,
actual Unreal, controlled performance, unfamiliar-consumer review and production
signing/release/deployment remain separate and unperformed.

## Historical checkpoints

'''
for name in ['README.md','CODEX_HANDOFF.md','milestones/M27.md']:
 p=b/name;p.write_text(intro+p.read_text())
p=b/'roadmap.yaml';s=p.read_text();start=s.index('  - id: M27\n');part=s[start:];part=part.replace('    next_batch: null','    next_batch: M27-07',1);lines=part.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('    planning_note:'));lines[i]='    planning_note: Owner selected M27-07 native golden XDMA host preparation after completed01-06. Add optional installed host and ordinary fake-driver/absent-device validation; no physical/RT claim.08 planned. Original05 campaigns/continuous and06 signature expansion remain unperformed.';p.write_text(s[:start]+'\n'.join(lines)+'\n')
p=b/'automation.json';d=json.loads(p.read_text());next(x for x in d['batches'] if x['id']=='M27-07')['reason']='Owner selected07: existing native adapter, explicit staging, named configuration, checked ownership, installed host compilation and ordinary simulated-driver/absent-device validation only. No live endpoint or qualification claim;08 remains planned.';p.write_text(json.dumps(d,indent=2)+'\n')
for phase in ['publish','merge','pipeline']:
 s=Path('/tmp/cpp-m27-05-scope-'+phase+'.py').read_text().replace('cpp-m27-05-scope','cpp-m27-07-plan').replace('agent/cpp-m27-05-regression-scope','agent/cpp-m27-07-plan').replace('M27-05','M27-07').replace('owner-scoped C++ regression coverage','native golden XDMA host preparation').replace('ordinary Runtime regression coverage','native golden XDMA host preparation')
 Path('/tmp/cpp-m27-07-plan-'+phase+'.py').write_text(s)
print('Prepared07 canonical plan')
