from pathlib import Path
import subprocess,json,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
for _ in range(120):
 p=subprocess.run(['gh','api','repos/tranquilWorks/portfolio-control/actions/runs/37028341691'],capture_output=True,text=True)
 if p.returncode==0:
  d=json.loads(p.stdout)
  if d['run_attempt']>=2 and d['status']=='completed':
   assert d['conclusion']=='success',d['conclusion'];break
 time.sleep(10)
else:raise SystemExit('Pending')
with open('/tmp/cpp-m27-07-plan-merge02.log','w') as f:
 p=subprocess.run(['python3','/tmp/cpp-m27-07-plan-merge.py'],stdout=f,stderr=subprocess.STDOUT,cwd=r)
assert p.returncode==0
for name in ['implement','files','docs']:
 p=subprocess.run(['python3','/tmp/cpp-m27-07-'+name+'.py']);assert p.returncode==0
