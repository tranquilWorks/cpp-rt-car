from pathlib import Path
import json,gzip,hashlib,subprocess,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');out=r/'docs/evidence/M27-07-final-checkpoint';out.mkdir(exist_ok=False)
assert 'PASS complete Runtime/native backend' in Path('/tmp/cpp-m27-07-sanitizers03.log').read_text()
assert 'PASS actual native CLI' in Path('/tmp/cpp-m27-07-package-final.log').read_text()
assert 'completed=' in Path('/tmp/cpp-m27-07-contract-final.log').read_text()
files=[p for p in Path('/tmp').glob('cpp-m27-07-*') if p.is_file() and p.suffix in ('.log','.json','.txt','.py')]
for folder in ['cpp-m27-07-sanitizers','cpp-m27-07-package02','cpp-m27-07-package-wiring','cpp-m27-07-package-final-host']:
 for p in (Path('/tmp')/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and (p.suffix in ('.log','.json','.plist') or p.name in ('CMakeCache.txt','CPackConfig.cmake')):files.append(p)
records=[]
for p in sorted(set(files)):
 raw=p.read_bytes();dest=out/'retained'/(str(p.relative_to('/tmp'))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));records.append({'original':str(p),'retained':str(dest.relative_to(out)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
(out/'retained-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
paths=[p for folder in ['samples/golden_xdma_native','tests/golden_xdma_native'] for p in (r/folder).glob('*') if p.is_file()]+[r/'CMakeLists.txt',r/'tests/CMakeLists.txt',r/'tests/package_consumer/CMakeLists.txt',r/'tools/check_release_contract.py']
bindings={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};(out/'reviewed-sources.json').write_text(json.dumps(bindings,indent=2)+'\n')
# Installed implementation bytes match the reviewed source, independently of the checkout.
prefix=Path('/tmp/cpp-m27-07-package-final-prefix/custom data/rtfw/examples/golden_xdma_native')
assert all((prefix/p.name).read_bytes()==p.read_bytes() for p in (r/'samples/golden_xdma_native').glob('*') if p.is_file())
b=yaml.safe_load((r/'contracts/active-batch.yaml').read_text());changed=set(subprocess.check_output(['git','diff','--name-only',b['sources']['baseline_commit']],cwd=r,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines())
for p in changed:
 assert any(fnmatch.fnmatch(p,x) for x in b['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in b['scope']['forbidden_paths']),p
(out/'scope-review.json').write_text(json.dumps({'baseline':b['sources']['baseline_commit'],'canonical':b['sources']['canonical_revision'],'changed_paths':sorted(changed)},indent=2)+'\n')
print('Retained',len(records),'records; final installed source bytes match; scope/source checks PASS',flush=True)
