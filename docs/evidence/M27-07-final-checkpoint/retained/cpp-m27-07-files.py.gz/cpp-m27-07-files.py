from pathlib import Path
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
files={}
files['samples/golden_xdma_native/configuration.hpp']=r'''#pragma once
#include "../golden_xdma/codec.hpp"
#include <array>
#include <charconv>
#include <filesystem>
#include <fstream>
#include <map>
#include <string>
#include <string_view>
namespace golden::xdma::native {
struct Configuration {
  std::string tuple, bitstream;
  std::array<std::string, 7> paths{}; // H2C0/1, C2H0/1, user, event0/1
  std::array<std::uint64_t, 2> input{}, output{};
  bool valid() const noexcept {
    if (tuple.empty() || tuple.size() > 128 || bitstream.size() != 64 ||
        bitstream.find_first_not_of("0123456789abcdef") != std::string::npos ||
        bitstream.find_first_not_of('0') == std::string::npos)
      return false;
    for (std::size_t i = 0; i < paths.size(); ++i) {
      if (paths[i].empty() || paths[i][0] != '/' || paths[i].size() >= 4096 ||
          paths[i].find('\0') != std::string::npos)
        return false;
      for (std::size_t j = 0; j < i; ++j)
        if (paths[i] == paths[j]) return false;
    }
    const std::array<std::uint64_t, 4> offsets{input[0],output[0],input[1],output[1]};
    for (std::size_t i = 0; i < offsets.size(); ++i) {
      const auto bytes = frame_size(i);
      // Linux pread/pwrite uses signed off_t; keep all windows disjoint even
      // when both channel nodes expose the same AXI-MM address space.
      if (offsets[i] % 64 || offsets[i] > INT64_MAX - bytes) return false;
      for (std::size_t j = 0; j < i; ++j)
        if (offsets[i] < offsets[j] + frame_size(j) &&
            offsets[j] < offsets[i] + bytes) return false;
    }
    return true;
  }
};
inline bool read_configuration(const std::filesystem::path &path, Configuration &out) {
  std::error_code ec;
  if (!std::filesystem::is_regular_file(path, ec) || ec ||
      std::filesystem::file_size(path, ec) > 32768 || ec) return false;
  std::ifstream stream(path);
  std::map<std::string,std::string> rows;
  std::string line;
  while (std::getline(stream,line)) {
    if (line.empty() || line[0] == '#') continue;
    const auto at = line.find('=');
    if (at == std::string::npos || at == 0 || at + 1 == line.size() ||
        !rows.emplace(line.substr(0,at),line.substr(at+1)).second) return false;
  }
  if (!stream.eof() || rows.size() != 15 ||
      rows["layout"] != "golden-xdma-native-v1" ||
      rows["driver_revision"] != "8721136e74a66500b02d16cb41922d966139cd46") return false;
  Configuration candidate;
  candidate.tuple = rows["tuple"]; candidate.bitstream = rows["bitstream_sha256"];
  constexpr std::array<std::string_view,7> names{"h2c0","h2c1","c2h0","c2h1","user","event0","event1"};
  for (std::size_t i=0;i<names.size();++i) candidate.paths[i]=rows[std::string(names[i])];
  constexpr std::array<std::string_view,4> offsets{"input0","output0","input1","output1"};
  std::array<std::uint64_t,4> parsed{};
  for (std::size_t i=0;i<offsets.size();++i) {
    const auto &text=rows[std::string(offsets[i])];
    const auto p=std::from_chars(text.data(),text.data()+text.size(),parsed[i]);
    if (p.ec!=std::errc{} || p.ptr!=text.data()+text.size()) return false;
  }
  if (rows.size()!=15) return false; // unknown/missing keys never default
  candidate.input={parsed[0],parsed[2]};candidate.output={parsed[1],parsed[3]};
  if (!candidate.valid()) return false;
  out=std::move(candidate);return true;
}
enum class Availability { ready, absent, invalid };
inline Availability availability(const Configuration &config) {
  if (!config.valid()) return Availability::invalid;
  bool missing=false;
  for (const auto &path:config.paths) {
    std::error_code ec;
    const auto status=std::filesystem::status(path,ec);
    if (status.type()==std::filesystem::file_type::not_found) { missing=true;continue; }
    if (ec || !std::filesystem::is_character_file(status)) return Availability::invalid;
  }
  return missing ? Availability::absent : Availability::ready;
}
} // namespace golden::xdma::native
'''
files['samples/golden_xdma_native/main.cpp']=r'''#include "session.hpp"
#include <rt/xdma_linux.hpp>
#include <iostream>
namespace gn=golden::xdma::native;
class Clock final : public rt::RuntimeClock {
public:
  std::uint64_t now_ns() noexcept override {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count());
  }
};
int main(int argc,char **argv) {
  if (argc!=3 || std::string_view(argv[1])!="--prepare") {
    std::cerr<<"usage: golden_xdma_native --prepare NAMED_TUPLE_CONFIG\n";return 2;
  }
  try {
    gn::Configuration config;
    if (!gn::read_configuration(argv[2],config)) { std::cerr<<"invalid configuration\n";return 2; }
    const auto available=gn::availability(config);
    if (available==gn::Availability::invalid) { std::cerr<<"invalid endpoint configuration\n";return 2; }
    if (available==gn::Availability::absent) {
      std::cout<<"NOT_RUN missing device; no driver initialized\n";return 3;
    }
    // All validation above precedes driver construction, worker creation and
    // output submission. Endpoints are supplied by an approved bench operator.
    const std::array<std::string_view,2> h2c{config.paths[0],config.paths[1]},
        c2h{config.paths[2],config.paths[3]},events{config.paths[5],config.paths[6]};
    rt::LinuxXdmaConfig native;native.h2c_paths=h2c;native.c2h_paths=c2h;
    native.user_path=config.paths[4];native.event_paths=events;
    rt::LinuxXdmaDriver driver(native);
    Clock clock;
    auto memory=std::make_unique<golden::Memory>();
    const auto origin=clock.now_ns();
    auto io=std::make_unique<gn::Io>(driver.api(),config,origin);
    auto session=std::make_unique<gn::Session>(golden::Options{},*memory,*io,clock,origin);
    const auto prepared=session->prepare();
    // Even failed startup may own resources. Never release borrowed storage or
    // the driver until checked stop succeeds. Persistent failure terminates via
    // Session's existing fail-stop destructor contract rather than freeing it.
    auto stopped=session->close();
    for (unsigned retry=0;stopped!=rt::Status::ok && retry<2;++retry) stopped=session->close();
    if (prepared!=rt::Status::ok || stopped!=rt::Status::ok) {
      std::cerr<<"preparation failed startup="<<int(prepared)<<" stop="<<int(stopped)<<'\n';return 1;
    }
    std::cout<<"PREPARED tuple="<<config.tuple<<" bitstream="<<config.bitstream
             <<"; graph/startup/stop only; scenario execution and physical safety UNVERIFIED\n";
    return 0;
  } catch (const std::exception &e) { std::cerr<<"preparation error: "<<e.what()<<'\n';return 1; }
}
'''
files['samples/golden_xdma_native/CMakeLists.txt']=r'''cmake_minimum_required(VERSION 3.20)
project(golden_xdma_native LANGUAGES CXX)
if(NOT CMAKE_SYSTEM_NAME STREQUAL "Linux" OR NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
  message(FATAL_ERROR "Native golden XDMA preparation requires 64-bit Linux")
endif()
if(NOT TARGET rtfw::xdma_linux)
  find_package(rtfw 1.2 CONFIG REQUIRED COMPONENTS runtime xdma_backend xdma_linux)
endif()
add_executable(golden_xdma_native main.cpp)
target_link_libraries(golden_xdma_native PRIVATE rtfw::runtime rtfw::xdma_linux rt)
'''
files['tests/golden_xdma_native/test_native.cpp']=r'''#include "../../samples/golden_xdma_native/session.hpp"
#include "../../samples/golden_xdma/simulated_driver.hpp"
#include "../golden_cuda/allocation.hpp"
#include <iostream>
namespace gn=golden::xdma::native;
namespace gx=golden::xdma;
#define CHECK(x) do { if (!(x)) { std::cerr<<"FAIL "<<__LINE__<<": "<<#x<<'\n';return false;} } while(false)
gn::Configuration config() {
  gn::Configuration c;c.tuple="software-fixture";c.bitstream=std::string(64,'a');
  for(std::size_t i=0;i<7;++i)c.paths[i]="/nonexistent/golden-native-"+std::to_string(i);
  c.input={0,32768};c.output={8192,40960};return c;
}
struct Fake {
  gx::SimulatedDriver card{16};
  rt::XdmaDriverApi api() {
    auto a=card.api();a.user_data=this;
    a.initialize=[](void *p) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().initialize(&s);};
    a.shutdown=[](void *p) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().shutdown(&s);};
    a.reset=[](void *p) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().reset(&s);};
    a.request_stop=[](void *p) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().request_stop(&s);};
    a.monotonic_time_ns=[](void *p) noexcept {return static_cast<Fake*>(p)->card.now.load();};
    a.control_read32=[](void *p,std::uint32_t o) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().control_read32(&s,o);};
    a.control_write32=[](void *p,std::uint32_t o,std::uint32_t v) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().control_write32(&s,o,v);};
    a.wait_user_event=[](void *p,std::uint32_t i,std::uint64_t t) noexcept {auto &s=static_cast<Fake*>(p)->card;return s.api().wait_user_event(&s,i,t);};
    a.transfer=[](void *p,rt::XdmaDirection d,std::uint32_t ch,std::uint64_t off,void *h,std::uint64_t n) noexcept {
      auto &s=static_cast<Fake*>(p)->card;
      if(ch>1 || (off!=ch*32768ull && off!=ch*32768ull+8192))
        return rt::XdmaTransferResult{rt::XdmaDriverResult::invalid_value,0};
      return s.api().transfer(&s,d,ch,off-ch*32768ull,h,n);
    };return a;
  }
};
bool positive() {
  auto c=config();CHECK(c.valid());
  Fake f;golden::Clock clock;
  auto memory=std::make_unique<golden::Memory>();
  auto io=std::make_unique<gn::Io>(f.api(),c,1000);
  auto s=std::make_unique<gn::Session>(golden::Options{},*memory,*io,clock,1000);
  CHECK(s->prepare()==rt::Status::ok);
  CHECK(io->native_capabilities().deterministic_mock==0);
  CHECK(s->plan.phase_count==10 && s->plan.sampled_io_channel_count==4);
  CHECK(s->controls());
  rtfw_physics_allocation::begin();
  auto result=s->step(0);
  const auto allocations=rtfw_physics_allocation::end();
  CHECK(result==rt::Status::ok && allocations==0);
  CHECK(f.card.downloads>=2 && f.card.controls==f.card.events);
  CHECK(s->close()==rt::Status::ok && !f.card.live && memory->live_count()==0);
  CHECK(s->close()==rt::Status::ok);
  return true;
}
bool refusal(gx::SimulatedDriver::Fault fault) {
  Fake f;golden::Clock clock;
  auto memory=std::make_unique<golden::Memory>();
  gn::Io io(f.api(),config(),1000);gn::Session s(golden::Options{},*memory,io,clock,1000);
  CHECK(s.prepare()==rt::Status::ok);
  f.card.fault_lane=0;f.card.fault=fault;
  CHECK(s.step(0)!=rt::Status::ok);
  f.card.fault=gx::SimulatedDriver::Fault::none;
  CHECK(s.close()==rt::Status::ok && !f.card.live && memory->live_count()==0);
  return true;
}
bool ownership() {
  Fake f;golden::Clock clock;auto memory=std::make_unique<golden::Memory>();
  gn::Io io(f.api(),config(),1000);gn::Session s(golden::Options{},*memory,io,clock,1000);
  f.card.fail_after_acquire=true;
  CHECK(s.prepare()!=rt::Status::ok);
  CHECK(s.close()==rt::Status::ok && !f.card.live && memory->live_count()==0);
  return true;
}
bool formats() {
  auto c=config();auto bad=c;bad.output[0]=0;CHECK(!bad.valid());bad=c;bad.input[1]=UINT64_MAX;CHECK(!bad.valid());
  Fake f;gn::Io io(f.api(),c,2000);
  golden::Frame sample{},application{};
  gx::sampled_header(sample,1,2,1,2000,rt::SampledIoFrameStatus::produced);
  CHECK(io.decode(sample,application,1,16));
  gx::sampled_header(sample,1,2,1,1999,rt::SampledIoFrameStatus::produced);
  CHECK(!io.decode(sample,application,1,16));
  gx::sampled_header(sample,1,2,1,2001,rt::SampledIoFrameStatus::produced);
  CHECK(!io.decode(sample,application,1,16));
  gx::sampled_header(sample,1,2,1,2000,rt::SampledIoFrameStatus::produced);
  sample[golden::header_bytes]^=std::byte{1};CHECK(!io.decode(sample,application,1,16));
  CHECK(f.card.initializes==0 && f.card.uploads==0);return true;
}
int main() {
  if(!formats() || !positive() || !ownership())return 1;
  for(auto f:{gx::SimulatedDriver::Fault::short_transfer,gx::SimulatedDriver::Fault::header_corrupt,
              gx::SimulatedDriver::Fault::payload_corrupt,gx::SimulatedDriver::Fault::stale_sequence,
              gx::SimulatedDriver::Fault::missing_ack})if(!refusal(f))return 1;
  std::cout<<"PASS native capability, golden graph, zero allocation, protocol/format/ownership\n";
}
'''
files['tests/golden_xdma_native/CMakeLists.txt']=r'''if((WIN32 OR CMAKE_SYSTEM_NAME STREQUAL "Linux") AND CMAKE_SIZEOF_VOID_P EQUAL 8)
  add_executable(test_golden_xdma_native test_native.cpp ../golden_cuda/allocation.cpp)
  target_link_libraries(test_golden_xdma_native PRIVATE rtfw::runtime rtfw::xdma_backend)
  if(WIN32)
    target_link_libraries(test_golden_xdma_native PRIVATE psapi)
  endif()
  rtfw_enable_project_warnings(test_golden_xdma_native)
  add_test(NAME golden_xdma_native_contract COMMAND test_golden_xdma_native)
  set_tests_properties(golden_xdma_native_contract PROPERTIES TIMEOUT 120)
endif()
if(TARGET rtfw_xdma_linux)
  add_subdirectory(${PROJECT_SOURCE_DIR}/samples/golden_xdma_native ${CMAKE_CURRENT_BINARY_DIR}/host)
  add_test(NAME golden_xdma_native_absent COMMAND ${RTFW_PYTHON_EXECUTABLE}
      ${CMAKE_CURRENT_SOURCE_DIR}/test_cli.py $<TARGET_FILE:golden_xdma_native>)
endif()
'''
files['tests/golden_xdma_native/test_cli.py']=r'''"""Actual host entry point; temporary missing/regular paths only, no live nodes."""
import pathlib, subprocess, sys, tempfile

def run(binary):
    with tempfile.TemporaryDirectory(prefix="native golden absent ") as directory:
        root=pathlib.Path(directory)
        rows={"tuple":"software-absence-test","bitstream_sha256":"a"*64,
              "driver_revision":"8721136e74a66500b02d16cb41922d966139cd46",
              "layout":"golden-xdma-native-v1","input0":"0","output0":"8192",
              "input1":"32768","output1":"40960"}
        for name in ("h2c0","h2c1","c2h0","c2h1","user","event0","event1"):
            rows[name]=str(root/name)
        config=root/"tuple.cfg"
        def invoke(expected):
            result=subprocess.run([binary,"--prepare",str(config)],capture_output=True,text=True,timeout=20)
            assert result.returncode==expected,(result.returncode,result.stdout,result.stderr)
            return result
        def save(): config.write_text("".join(f"{k}={v}\n" for k,v in rows.items()))
        save();result=invoke(3);assert "NOT_RUN missing device; no driver initialized" in result.stdout
        assert sorted(p.name for p in root.iterdir())==["tuple.cfg"]
        (root/"h2c0").write_text("ordinary file remains unchanged")
        invoke(2);assert (root/"h2c0").read_text()=="ordinary file remains unchanged"
        (root/"h2c0").unlink()
        rows["output0"]="0";save();invoke(2)
        rows["output0"]="8192";rows["unknown"]="1";save();invoke(2)
        del rows["unknown"];save();config.write_text(config.read_text()+"tuple=duplicate\n");invoke(2)
        save();del rows["event1"];save();invoke(2)
    print("PASS actual native CLI absence/configuration refusals; no live endpoint")
if __name__=="__main__":run(sys.argv[1])
'''
for name,body in files.items():(r/name).write_text(body)
p=r/'tests/CMakeLists.txt';p.write_text(p.read_text()+'\nadd_subdirectory(golden_xdma_native)\n')
p=r/'CMakeLists.txt';p.write_text(p.read_text()+'''\n# Optional source kit; no default SDK target/header inventory changes.\ninstall(FILES\n  samples/golden_xdma_native/CMakeLists.txt\n  samples/golden_xdma_native/configuration.hpp\n  samples/golden_xdma_native/io.hpp\n  samples/golden_xdma_native/session.hpp\n  samples/golden_xdma_native/main.cpp\n  samples/golden_xdma_native/README.md\n  DESTINATION ${CMAKE_INSTALL_DATADIR}/rtfw/examples/golden_xdma_native)\ninstall(FILES docs/golden_xdma_native.md DESTINATION ${CMAKE_INSTALL_DATADIR}/rtfw)\n''')
print('Wrote host, configuration and ordinary tests')
