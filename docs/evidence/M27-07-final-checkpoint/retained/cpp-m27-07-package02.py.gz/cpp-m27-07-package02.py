from pathlib import Path
import subprocess,json,hashlib,shutil,sys
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');work=Path('/tmp/cpp-m27-07-package02');work.mkdir(exist_ok=True);records=[]
def run(*args,expected=0):
 args=list(map(str,args));print('COMMAND',json.dumps(args),flush=True);p=subprocess.run(args,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(p.stdout,flush=True);records.append({'command':args,'exit':p.returncode});(work/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert (p.returncode==0) if expected==0 else (p.returncode!=0);return p.stdout
sdk=work/'SDK build'
for optional in [False,True]:
 label='optional' if optional else 'default';prefix=work/(label+' relocated prefix');original=work/(label+' original prefix');archives=work/(label+' archives')
 run('cmake','-S',r,'-B',sdk,'-DCMAKE_BUILD_TYPE=Release','-DENABLE_TESTS=OFF','-DRTFW_BUILD_EXAMPLES=OFF','-DRTFW_BUILD_RUNTIME_DEMO=OFF','-DRTFW_BUILD_EXPERIMENTAL=OFF','-DRTFW_BUILD_BENCHMARKS=OFF','-DRTFW_ENABLE_CUDA=OFF','-DRTFW_ENABLE_XDMA='+('ON' if optional else 'OFF'),'-DSIM_SANITIZERS=','-DSIM_WERROR=ON','-DCMAKE_INSTALL_INCLUDEDIR=sdk include','-DCMAKE_INSTALL_DATADIR=custom data','-DCMAKE_INSTALL_PREFIX='+str(original))
 run('cmake','--build',sdk,'--parallel','2');run('cmake','--install',sdk)
 run('cpack','--config',sdk/'CPackConfig.cmake','-G','TGZ','-B',archives,'-D','CPACK_PACKAGING_INSTALL_PREFIX=/','-D','CPACK_PACKAGE_FILE_NAME=native-golden-'+label)
 shutil.rmtree(original)
 run(sys.executable,r/'tools/extract_release_archive.py','--artifact-dir',archives,'--destination',prefix)
 kit=prefix/'custom data/rtfw/examples/golden_xdma_native';build=work/(label+' host build')
 out=run('cmake','-S',kit,'-B',build,'-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',expected=0 if optional else 1)
 if not optional:assert 'rtfw_FOUND to FALSE' in out and not (prefix/'lib/librtfw_xdma_linux.a').exists();continue
 run('cmake','--build',build,'--parallel','2')
 run(sys.executable,r/'tests/golden_xdma_native/test_cli.py',build/'golden_xdma_native')
 commands=(build/'compile_commands.json').read_text();assert str(r) not in commands and str(sdk) not in commands and str(original) not in commands
 copied=work/'copied fake consumer';copied.mkdir(exist_ok=True)
 # Standalone fake test shares installed frozen and new source kits, never private headers.
 source=(r/'tests/golden_xdma_native/test_native.cpp').read_text().replace('../../samples/',str(prefix/'custom data/rtfw/examples')+'/').replace('#include "../golden_cuda/allocation.hpp"','#include "allocation.hpp"')
 (copied/'main.cpp').write_text(source)
 for n in ['allocation.cpp','allocation.hpp']:(copied/n).write_bytes((r/'tests/golden_cuda'/n).read_bytes())
 (copied/'allocation.cpp').write_text((copied/'allocation.cpp').read_text().replace('../cuda_physics/allocation_guard.hpp','allocation_guard.hpp'))
 (copied/'allocation_guard.hpp').write_bytes((r/'tests/cuda_physics/allocation_guard.hpp').read_bytes())
 (copied/'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.20)\nproject(native_fake LANGUAGES CXX)\nfind_package(rtfw CONFIG REQUIRED COMPONENTS runtime xdma_backend)\nadd_executable(native_fake main.cpp allocation.cpp)\ntarget_link_libraries(native_fake PRIVATE rtfw::runtime rtfw::xdma_backend)\n')
 fb=work/'fake consumer build';run('cmake','-S',copied,'-B',fb,'-DCMAKE_PREFIX_PATH='+str(prefix));run('cmake','--build',fb,'--parallel','2');run(fb/'native_fake')
print('PASS actual default-component refusal, relocated optional installed host, missing-device CLI and copied native fake consumer',flush=True)
