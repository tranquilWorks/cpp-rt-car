from pathlib import Path
import json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');p=r/'samples/golden_audit/catalog.py';s=p.read_text();e=json.loads(Path('/tmp/cpp-m28-05-ledger-expectations.json').read_text())
constants='\n\n# Reviewed M28-05 reconciliation policy. Updating an obligation is an explicit\n# evidence review, never a result inferred from a successful retry or bundle hash.\nCLOSEOUT_FINDINGS = '+repr(e['findings'])+'\nCLOSEOUT_CARDS = '+repr(e['cards'])+'\nCLOSEOUT_ACTIONS = '+repr(e['remaining'])+'\n'
code='''

def closeout_references(ledger):
    refs = []
    for row in ledger['requirements']:
        for kind in ('sources', 'tests', 'evidence'):
            refs.extend(row[kind])
    for row in ledger['findings'] + ledger['deliveries']:
        refs.extend(row['evidence'])
    return refs


def verify_closeout(ledger, audit, reader):
    require(set(ledger) == {'schema', 'batch', 'baseline', 'requirement_binding',
            'claims', 'requirements', 'findings', 'existing_cards', 'remaining_actions',
            'deliveries'}, 'closeout fields')
    require(type(ledger['schema']) is int and ledger['schema'] == 1 and
            ledger['batch'] == 'M28-05' and
            ledger['baseline'] == 'b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e', 'closeout identity')
    require(ledger['requirement_binding'] == REQUIREMENT_BINDING, 'closeout canonical binding')
    require(ledger['claims'] == dict(software_complete=False, cap_m20_complete=False,
            physical='NOT_RUN', rt='NOT_RUN', unreal='NOT_RUN', human_acceptance='NOT_RUN',
            controlled_performance='NOT_RUN', authenticated_provenance='NOT_RUN',
            release='NOT_RUN', deployment='NOT_RUN') and
            type(ledger['claims']['software_complete']) is bool and
            type(ledger['claims']['cap_m20_complete']) is bool, 'invalid closeout acceptance claim')
    require(ledger['existing_cards'] == CLOSEOUT_CARDS, 'existing owner-stage identities')
    require(ledger['remaining_actions'] == CLOSEOUT_ACTIONS and
            set(ledger['remaining_actions']) == {r['id'] for r in audit['remaining_actions']},
            'closeout remaining-action inventory')
    rows, findings = ledger['requirements'], ledger['findings']
    require([r['id'] for r in rows] == [r['id'] for r in audit['requirements']],
            'closeout missing/duplicate requirement IDs')
    require([f['id'] for f in findings] == list(CLOSEOUT_FINDINGS),
            'closeout missing/duplicate finding IDs')
    ids = {r['id'] for r in rows}
    for f in findings:
        require(set(f) == {'id', 'status', 'requirements', 'evidence', 'assessment',
                'dependencies', 'next_action', 'cards'}, 'closeout finding fields')
        require(f['status'] == CLOSEOUT_FINDINGS[f['id']], 'invalid finding disposition')
        require(f['requirements'] and len(f['requirements']) == len(set(f['requirements'])) and
                set(f['requirements']) <= ids, 'finding requirement links')
        require(len(f['dependencies']) == len(set(f['dependencies'])) and
                set(f['dependencies']) <= set(CLOSEOUT_FINDINGS) and
                f['id'] not in f['dependencies'], 'finding dependency links')
        require(len(f['cards']) == len(set(f['cards'])) and
                set(f['cards']) <= {c['id'] for c in CLOSEOUT_CARDS}, 'finding card links')
        require(f['evidence'] and isinstance(f['assessment'], str) and len(f['assessment']) >= 40
                and isinstance(f['next_action'], str) and len(f['next_action']) >= 30,
                'finding evidence/action missing')
        if f['status'] in ('external_acceptance', 'owner_excluded'):
            require(f['cards'], 'missing existing acceptance identity')
    visiting, visited = set(), set()
    by_id = {f['id']: f for f in findings}
    def visit(key):
        require(key not in visiting, 'cyclic closeout dependencies')
        if key in visited:
            return
        visiting.add(key)
        for dependency in by_id[key]['dependencies']:
            visit(dependency)
        visiting.remove(key)
        visited.add(key)
    for key in by_id:
        visit(key)
    for row, original in zip(rows, audit['requirements']):
        require(set(row) == {'id', 'requirement', 'original_status', 'status', 'evidence',
                'sources', 'tests', 'dependencies', 'assessment', 'next_action'},
                'closeout requirement fields')
        require(row['requirement'] == original['requirement'] and
                row['original_status'] == original['status'], 'closeout requirement drift')
        require(all(row[k] == original[k] for k in ('evidence', 'sources', 'tests')),
                'closeout original evidence drift')
        deps = [f['id'] for f in findings if row['id'] in f['requirements']]
        require(row['dependencies'] == deps, 'closeout requirement dependency mismatch')
        status = ('claim_limit' if '/limit/' in row['id'] else
                  'retained_evidence_with_obligations' if deps else 'retained_portable_evidence')
        require(row['status'] == status, 'invalid requirement acceptance claim')
        require(isinstance(row['assessment'], str) and len(row['assessment']) >= 30 and
                isinstance(row['next_action'], str) and len(row['next_action']) >= 30,
                'requirement assessment/action missing')
    require([d['id'] for d in ledger['deliveries']] ==
            ['M27-%02d' % i for i in range(1, 9)] + ['M28-%02d' % i for i in range(1, 5)],
            'missing predecessor delivery')
    for d in ledger['deliveries']:
        require(set(d) == {'id', 'evidence'} and d['evidence'], 'delivery evidence')
    for ref in closeout_references(ledger):
        reference_line(reader(ref['path']), ref)
    return ledger


def closeout_page(ledger, reader):
    def links(refs):
        return ' · '.join('<a href="source/' + r['path'] + '.html#L' +
                         str(reference_line(reader(r['path']), r)) + '">' +
                         html.escape(r['path']) + '</a>' for r in refs)
    parts = ['<!doctype html><html lang="en"><meta charset="utf-8">'
             '<title>M28-05 acceptance reconciliation</title>'
             '<style>body{max-width:1100px;margin:2rem auto;font:17px/1.5 system-ui}'
             'section{border-top:1px solid #bbb;padding:1rem}table{border-collapse:collapse}'
             'td,th{border:1px solid #bbb;padding:.5rem;vertical-align:top}</style>'
             '<h1>M28-05 acceptance and remaining-work ledger</h1>'
             '<p><a href="index.html">Original golden audit</a> · '
             '<a href="closeout.json">Machine-readable ledger</a></p>'
             '<p>All 112 original requirements are retained. Software-complete and CAP-M20 '
             'completion are not claimed. Physical, RT, Unreal, independent human, controlled '
             'performance, authenticated provenance, release and deployment acceptance remain '
             'NOT_RUN. Dependencies include capability-level context; they do not mean every '
             'implemented subcriterion has failed. Original audit statuses describe implementation, '
             'not current global acceptance. No waiver or human risk acceptance is inferred.</p>']
    parts += ['<h2>Retained findings and obligations</h2>']
    for f in ledger['findings']:
        deps = ' · '.join('<a href="#' + d + '">' + d + '</a>' for d in f['dependencies']) or 'None'
        parts += ['<section id="' + f['id'] + '"><h3>' + f['id'] + ' — ' + f['status'] +
                  '</h3><p>' + html.escape(f['assessment']) + '</p><p>Next: ' +
                  html.escape(f['next_action']) + '</p><p>Dependencies: ' + deps +
                  '</p><p>Existing acceptance identities: ' + html.escape(', '.join(f['cards']) or 'None') +
                  '</p><p>Evidence: ' + links(f['evidence']) + '</p></section>']
    parts += ['<h2>Complete original requirement inventory</h2>']
    for row in ledger['requirements']:
        deps = ' · '.join('<a href="#' + d + '">' + d + '</a>' for d in row['dependencies']) or 'None'
        parts += ['<section id="' + row['id'].replace('/', '-') + '"><h3>' + row['id'] + '</h3><p>' +
                  html.escape(row['requirement']) + '</p><p>Original implementation disposition: ' +
                  row['original_status'] + '; reconciliation: ' + row['status'] + '</p><p>' +
                  html.escape(row['assessment']) + '</p><p>Dependencies: ' + deps + '</p><p>Next: ' +
                  html.escape(row['next_action']) + '</p><p>Source: ' + links(row['sources']) +
                  '</p><p>Checks: ' + links(row['tests']) + '</p><p>Evidence: ' + links(row['evidence']) +
                  '</p></section>']
    parts += ['<h2>Existing final-stage identities</h2><p>These are pointers to existing '
              'canonical cards or criteria, not newly created qualification cards. Pinned '
              'repository paths and URLs below are provenance text; this bundle stays offline.</p><ul>']
    for card in ledger['existing_cards']:
        parts += ['<li>' + html.escape(card['id'] + ' — ' + card['url'] + ' (blob ' + card['blob'] + ')') + '</li>']
    parts += ['</ul><h2>Delivered batch evidence</h2>']
    for d in ledger['deliveries']:
        parts += ['<p>' + d['id'] + ': ' + links(d['evidence']) + '</p>']
    return ('\\n'.join(parts) + '</html>\\n').encode()
'''
pos=s.index('\ndef render(root):');s=s[:pos]+constants+code+s[pos:]
s=s.replace("    refs = references(mapping, audit)\n    paths", "    ledger = verify_closeout(load(root / 'docs/closeout/ledger.json'), audit, lambda p: read(root, p))\n    refs = references(mapping, audit) + closeout_references(ledger)\n    paths",1)
s=s.replace("'capabilities.json': encoded(audit)}", "'capabilities.json': encoded(audit), 'closeout.json': encoded(ledger),\n              'closeout.html': closeout_page(ledger, lambda p: read(root, p))}",1)
s=s.replace("    sections = ['<h2 id=\"scenario\">", "    sections = ['<p><a href=\"closeout.html\">Current M28-05 acceptance and remaining-work ledger</a></p>', '<h2 id=\"scenario\">",1)
old="    refs = references(mapping, audit)\n    require(set(inventory['sources'])"
new="    ledger = verify_closeout(load(directory / 'closeout.json'), audit,\n                             lambda p: read(directory, 'source/' + p + '.txt'))\n    require(read(directory, 'closeout.html') == closeout_page(ledger,\n            lambda p: read(directory, 'source/' + p + '.txt')), 'fabricated closeout page')\n    refs = references(mapping, audit) + closeout_references(ledger)\n    require(set(inventory['sources'])"
assert old in s;s=s.replace(old,new,1);p.write_text(s)
