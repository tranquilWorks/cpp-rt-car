# M28-04 delivered: native full-frame deadline investigation

[Target PR297](https://github.com/tranquilWorks/cpp-rt-car/pull/297) merged
at `b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e` after full portable181/strict169 and all32 original hosted records
passed at exact head `007d1614562f6b313e953019c99ac7294a203414`. Tested/fetched tree `10247835e6f8f0f57a757587df01c0998cdaa960` matches. Clean/head/
base/review guards passed. No target/local gate was waived. Canonical activation615
bound additive offline diagnostics and evidence; production is unchanged.

The unchanged native full-frame probe passed ordinary and ASan/UBSan/leak runs;
initialized TSan reproduced status-18, zero allocations and original assertion48.
Its full-frame result remains FAILED. The mandatory original preparation/protocol
suite passed all three modes. Pre-main TSan failures remain separately retained.

Offline fixed-storage timestamps show first-frame expiry in submitted state4,
quarantine, successful late native completion without successful frame publication,
and final slot release after checked shutdown. The callback consumed206.102us wall
and206.582us thread CPU; native completion reached Runtime895.297us after the500us
budget began. This supports an instrumented-host timing limitation, not a proved
production defect or repair. The asynchronous interval cannot be uniquely divided
into backend execution versus descheduling. No actual sanitizer report was ignored.

A test-only2ms hold before the first500us submission caused the original frame to
fail in ordinary, ASan and initialized TSan, with zero allocations. The analyzer
checks expiry during the hold, quarantine and retained ownership until shutdown.
No deadline or original assertion changes. Diagnostic source copies, exact patch,
source/archive/member hashes, all raw failures and draft mistakes are retained.
No diagnostics enter product CMake targets or installed artifacts. Clang14 analysis
and fail-closed diagnostic artifact controls pass. The offline compiler emits a retained
-Wreturn-type warning for the renamed original main's unused default branch.
The sole wrapper caller always selects --frame, whose paths explicitly return;
the original default protocol is compiled separately with its actual main. Source
review confirms no diagnostic caller reaches that fallthrough; no warning-free
offline compiler build is claimed.

Actual final-source CPack was extracted to a relocated prefix after deleting the
original install. Unchanged native protocol/full-frame tests and modern/legacy
Runtime consumers pass4/4. Copied source hashes match; consumer include paths do
not reference checkout, SDK build or original prefix. Installed contract and
provenance match the exact clean head/tree. Diagnostics are absent from the package.

- build-linux (gcc, RelWithDebInfo, ON), job111144363684: Original CommandBatch.SampledSimulationUnselectedMock: startup=-2 expected=-18, native_timeout=8000000, entered1, cleanup0/live0. Other186/187 CTests passed, including original native contract and closeout_startup. Same retained M28-03 startup timing observation; no source or assertion change and no repair claimed.
- build-linux (gcc, RelWithDebInfo, ON), job111151770421: First unchanged retry: original CommandBatch.SampledSimulationUnselectedNative failed in m17_command_batch_timeline, startup=-2 expected=-18 at unchanged8ms, entered1, cleanup0/live0. Mock case passed; other186/187 CTests passed. This repeats the separately retained native startup observation; no source/assertion/deadline/workflow change or repair claim.

M28-05 acceptance/findings reconciliation is next to select; M28-05..06 remain
inactive. Broader loopback cancel/submit race, optional experimental SDK missing
hal.hpp, historical sampled startup/Windows overlap and original native-frame TSan
failure remain open software findings. Original05/06 exclusions and all owner-stage
physical CUDA/XDMA/FPGA/HIL/RT/endurance, licensed Unreal, controlled performance,
independent human acceptance, production signing/release/deployment stay open.

## Historical checkpoints

# M28-04 selected: instrumented simulated-driver deadline investigation

Owner selected the next batch after M28-03 target296/control614 completed. Target
main is `526c13065475650f6c86de0ea8fc760d699a07a3`. Only M28-04 is active;
M28-05..06 and all final owner-stage activity remain inactive.

Retain the unchanged original native `--frame` probe in ordinary, ASan/UBSan and
initialized TSan execution. Its 500us native submission bound and all original
oracle/refusal assertions remain intact. Separate pre-main sanitizer failures
from initialized functional outcomes. Trace scheduling and ownership in explicitly
marked offline diagnostic builds using test-owned fixed-storage hooks. Diagnostic
copies never enter the shipped Runtime or replace the original failing result.

Initial scope adds diagnostics and evidence only. No private defect has yet been
independently demonstrated. Production changes require a precise causal finding
and bounded canonical amendment before editing. All local and original32 hosted
gates, appropriate instrumentation/static/no-allocation/ABI/default/package checks,
risk review and guarded target/control integration remain required.

This software investigation cannot establish physical or controlled timing.
Existing startup findings, broader loopback race, optional SDK missing hal.hpp,
original05/06 exclusions and owner-stage bench/engine/human/release work stay open.

## Historical checkpoints

# M28-03 delivered: sampled startup and cleanup investigation

[Target PR296](https://github.com/tranquilWorks/cpp-rt-car/pull/296) merged
at `526c13065475650f6c86de0ea8fc760d699a07a3` after full portable181/strict169 and all32 original hosted records
passed at exact head `fe483d0d5bda115e073877f9a27b1154e55e2f8b`. Tested/fetched tree `0caa6f3811c1f5936a6fcde163758bbd10cda1a3` matches. Clean/head/
base/review guards passed. No target/local gate was waived. Activation613 bound
only additive public-API controls, current docs and evidence; production is unchanged.

The investigation distinguishes ownership from the original startup failure.
Held native work requires invalid_state(-2) while cleanup retains borrowed memory;
completed timeout cleanup returns device_timeout(-18); failed native shutdown takes
precedence as device_error(-19). The channel separately preserves device_timeout and
unknown safety. Repeated stop, restart/step refusal while pending, late completion,
zero-live cleanup and exact safe frames are tested. Logical expiry after successful
native readback cannot publish application state or a Runtime timeline.

Thirteen fixed scenarios exercise the public Runtime and actual XDMA backend with
an injected driver, including before-acceptance expiry, mock/native pending work,
successful startup/frame/shutdown, shutdown-error retry, an independent successful
owner while another retains work, and concurrent independent owners. Frame/checked-
stop allocations remain zero with a positive observer control. The original8ms safe
argument, original two-second fixture wait and all predecessor tests stay unchanged.
New selected100ms simulator-watchdog controls are separate from logical expiry.

Normal controls, unchanged13 sampled GTests and startup_poll_reliability pass.
ASan/UBSan/leaks, initialized TSan and Clang14 analysis pass. Runtime instrumented
archive/member hashes and current rt/core byte equality are bound; new fixture,
allocation observer and XDMA backend are freshly instrumented. New-fixture ordering
mistakes, setup refusal and pre-main TSan failures remain retained as such.

Actual final-source CPack was extracted to a relocated prefix after deleting the
original install. Copied new/old startup suites, all12 original sampled cases, and
modern/legacy Runtime consumers pass16/16, with no checkout/SDK-build/original-prefix
include paths. Installed contract bytes and provenance match the exact clean head/tree.

Historical M27-02/M27-07 and later native/mock unselected startup -2-versus-18 findings
remain valid timing observations. The Windows M27-02 startup -18-versus0 after2024ms
is distinct: the original two-second injected-driver hold reproduces a possible
path here, but does not establish that historical cause. No production defect or
repair was independently established; this closes the scoped investigation and
additive controls, not all startup-timing obligations. Retry success closes none of
those findings.

First-attempt hosted failures and required unchanged retries are listed below.
All failures are retained as observations; none is claimed repaired. Final guards
require actual successful logs for every listed job and all32 original check names.
No assertion, source, deadline or workflow is relaxed.

- Relocated package consumer (ubuntu-22.04-x86_64-gcc-11), job111130448260: Original sampled_simulation_package_consumer case4: startup=-2 expected=-18, native_timeout=8000000, entered1, cleanup0/live0. Other64/65 tests passed.
- build-linux (clang, RelWithDebInfo, ON), job111130448339: Original SampledSimulationUnselectedMock: startup=-2 expected=-18, native_timeout=8000000, entered1, cleanup0/live0. New closeout_startup passed; other186/187 CTests passed.
- build-linux (gcc, RelWithDebInfo, OFF), job111130448288: Original SampledSimulationUnselectedMock: startup=-2 expected=-18, native_timeout=8000000, entered1, cleanup0/live0. New closeout_startup passed; other186/187 CTests passed.

M28-04 simulated/native frame timing is next to select; M28-04..06 remain inactive.
The broader loopback cancel/submit race, experimental SDK missing hal.hpp, historical
startup assertions and native-frame timing stay open software findings. Original05/06
exclusions and all final owner physical CUDA/XDMA/FPGA/HIL/RT/endurance, licensed
Unreal, controlled performance, independent human acceptance, production signing/
release/deployment obligations remain open.

## Historical checkpoints

# M28-03 selected: sampled startup and cleanup timing investigation

Owner selected M28-03 after M28-02 target295/control612 completed. Target main is
`b5275b0a6094ddab1ab902632cc7cf35e9d20e59`. Activate only this investigation;
M28-04..06 remain inactive. Standing scoped publication/guarded integration applies.

Read the retained M27-02/M27-07 and later raw startup logs. Native/mock unselected
cases reported -2 instead of -18 at the unchanged 8ms bound, then cleanup0/live0.
The separate Windows startup observation reported -18 instead of0 after2024ms.
Existing controlled native work proves -2 is required while cleanup owns borrowed
storage, with device_timeout retained separately in sampled channel status. That
is not evidence of a newly reproduced production defect or the exact historical
Windows cause.

Initial cause-specific scope is additive public-API startup/timeout/late completion/
repeated-stop/independent-owner controls, evidence and necessary current docs/hash
bindings. Preserve all original tests, assertions, 8ms/2s deadlines, Runtime/backend
sources, ABI/defaults and prior evidence. Any independently reproduced production
defect requires a bounded canonical amendment before repair. Keep unresolved timing
observations explicit; never substitute retry success or new tests for a repair.

Require focused instrumented/static/no-allocation/actual installed-package checks,
full local and all32 original exact-head hosted gates, risk review, guarded target
merge and canonical closure. Original05/06 exclusions, broader backend race, SDK
HAL-header gap and final owner bench/real Unreal/human/signing/release/deployment
obligations remain open. No physical or controlled-performance claim follows.

## Historical checkpoints

# M28-02 delivered: benchmark timeout and submission accounting

[Target PR295](https://github.com/tranquilWorks/cpp-rt-car/pull/295) merged
at `b5275b0a6094ddab1ab902632cc7cf35e9d20e59` after full portable180/strict168 and all32 original exact-head hosted
records passed at `7fe4a90432738e40564be35197bd7e4189355023`. The portable profile keeps the optional benchmark
selection enabled; every predecessor test remains included. Tested/fetched tree
`fa8a9759da80517ee9734b112dff88a6a8a60375` matches. Clean/head/base/review guards passed. No target/local gate was
waived. Canonical610 and amendment611 supply the activation and ordering scope.

The unchanged held-submit control retains the original1ms deadline and observes
one timeout terminal, one provider call, zero accepted submissions and no copied
output, then fails the original exact-one-submission predicate. The corrected
provider records that terminal observation as a lower bound and reconciles stable
backend accounting only after checked stop joins the submission lane. Exactly one
submit attempt and its returned status distinguish0-to-0,0-to-1 and1-to-1 states;
copy/action/completion/cancellation/rejection and nonpublication checks remain exact.
The historical hosted benchmark failure's precise cause remains unproven.

Initialized TSan independently reproduces a pre-existing loopback cancel/submit
storage race against unchanged provider source. A fixture-owned observer for the
two failure/timeout cases publishes submit's returned status with release ordering;
cancel forwards only after acquired acceptance. Before acceptance it returns
invalid_argument promptly and storage remains owned until checked shutdown. No
callback mutex/allocation, Runtime/backend change, deadline or schema change follows.
Other workloads, old tests, ABI/defaults and historical evidence stay unchanged.

Retain the broader loopback backend cancel/submit race as an unresolved software
finding for subsequent M28 closeout; this provider-local correction does not repair
all direct backend callers. Also retain the optional experimental full-SimCore SDK
missing hal.hpp, sampled startup failures and simulated native-frame timing finding.

The final26 fixed accounting/schedule scenarios pass normally, ASan/UBSan/leaks,
initialized TSan and Clang14 static analysis. Baseline predicate/race failures,
first-candidate race and pre-main TSan failures are preserved. All17 selected
benchmark-related CTests (including the additive accounting entry), complete
inventories/CLI validators and original no-allocation checks pass. Final full
profiles repeat the expanded accounting suite and all predecessor coverage.

The final committed source was repackaged into an actual optional benchmark CPack
archive and extracted to a relocated prefix after deleting the original install.
Copied accounting tests, original installed Runtime provider, and current/legacy
public Runtime consumers pass without checkout/build/original-prefix includes.
Installed timeout/error CLI cases pass fake and steady clocks with the unchanged
installed validators, two warmups/five measurements. Installed source/contract bytes
match final source; CLI and golden provenance bind the exact clean commit/tree.

The first hosted Windows RelWithDebInfo job111108966732 failed only the unchanged
GPUStub.Overlap assertion: overlap=-43476200ns versus the required positive value.
The benchmark and new accounting tests passed in that same187-test execution.
The raw failure remains an unresolved timing observation for later M28 software
triage. Final integration requires an actual unchanged Windows retry187/187 pass
alongside all32 original checks; a retry pass does not erase the original finding.

The original GCC Debug OFF job111108966819 (copied as111114859528 in attempt2)
also failed the unchanged SampledSimulationUnselectedMock assertion, status=-2
versus-18 at the original8ms bound. The benchmark and accounting tests passed.
Retain this as another observation of the existing M28-03 startup/cleanup finding.
Final acceptance also requires an actual unchanged GCC186/186 retry pass; the
copied failed record is not a second execution and never counts as fresh evidence.

M28-03 sampled startup/cleanup timing is next to select. M28-03..06 stay inactive.
The broader backend race and SDK gap remain software triage items, not bench/human
work. Original05/06 exclusions and all final owner physical CUDA/XDMA/FPGA/HIL/RT/
endurance, real Unreal, controlled performance, independent human acceptance,
production signing/release/deployment obligations remain open. This closes only
the scoped M28-02 provider correction and its canonical software evidence.

## Historical checkpoints

# M28-02 provider acceptance/cancellation ordering amendment

The first initialized TSan run of the actual provider held after backend acceptance
reports loopback cancel reading completion storage while submit writes it. Raw
M28-02 evidence is retained. Extend only the already allowed device.cpp repair
with a fixture-owned observer for failure/timeout cases: publish acceptance after
submit returns, forward cancellation only after that publication, and preserve
failed cancellation before acceptance plus checked-stop ownership. No mutex or
allocation is added to backend callbacks. Bind final acceptance and backend
accounting after shutdown. Runtime/backend sources and all old workloads/tests,
1ms deadline, schemas and defaults remain unchanged.

Reproduce the race against unchanged provider source with the same scheduling
control; require corrected initialized TSan, before/after-acceptance/stop controls,
actual CLI, existing benchmark suites and installed-source consumers. This scoped
provider correction does not repair every direct use of the pre-existing loopback
backend; retain that independent software finding for subsequent M28 closeout.
All local/full/all32/source/review/merge guards remain mandatory. Only M28-02 is
active; later software and final owner-stage obligations remain open.

## Historical checkpoints

# M28-02 selected: benchmark timeout and submission accounting

Owner selected02 after M28-01 target294/control609. Exact target baseline is
`ab22bb4580de18794fcb2bad2b72b4e8a1e104c5`. The retained held-submit control
proves that the original1ms deadline can produce a terminal timeout before the
backend records acceptance; the provider's exact-one-submission assumption is
not guaranteed. Preserve the historical failure without claiming its exact cause.

Repair only `bench/providers/runtime_cases/device.cpp`, add independent
closeout_benchmark controls and additive test wiring, and refresh necessary
current documentation/hash bindings. Establish valid zero/one acceptance
transitions, preserve terminal/output checks and checked cleanup, and test before
and after acceptance plus successful submission and actual accounting errors.
Keep Runtime, all old tests/deadlines, catalog/schema, ABI/defaults and historical
evidence unchanged. Require full local/all32 exact-head, instrumentation/static,
allocation, actual CLI/installed provider, risk review and guarded integration.

M28-03..06 stay inactive. Retain the optional experimental SDK HAL-header gap,
startup/simulated timing findings, original05/06 exclusions and all final owner
bench/physical XDMA/Unreal/human/performance/signing/release/deployment gates.

## Historical checkpoints

# M28-01 delivered: concurrent experimental clock initialization

[Target PR294](https://github.com/tranquilWorks/cpp-rt-car/pull/294) merged
at `ab22bb4580de18794fcb2bad2b72b4e8a1e104c5` after portable161/strict167 and all32 original exact-head hosted records
passed at `3bb6ec2ecf0afe1ee8dbb7a5a5c826e5bd2d8472`. Tested/fetched tree `9418209bea72de67c3d4591068e04768969fbea7` matches. Clean/head/base/review
guards passed; no target/local functional gate was waived. Canonical608 supplies
activation at937a5b100ba48798d0fafc6bfb57457c16ef600b.

The unchanged clock exposed an unpublished calibration callback in a deterministic
public-API control; initialized TSan independently proved shared clock writes in
concurrent initialization and concurrent caller-thread SimCore construction.
The correction serializes only off-path writers and publishes versioned atomic
calibration. Reads take one snapshot attempt, fall back during publication and
never lock the writer mutex. Stale failed reads cannot disable a newer generation,
failed calibration disables TSC, and reinitialization preserves the monotonic
floor. Existing50ms calibration,1ms drift and all old tests/deadlines remain.

New publication/stale/concurrency/allocation controls and repeated caller-thread
owner construction/run/destruction pass. The existing FMA-off2/4/8-thread
determinism, clock and timing tests pass instrumented ASan/UBSan/leaks and initialized
TSan, along with unchanged earlier causal-control negatives. New clock/owner static
analysis passes. Other experimental global policies are not newly qualified.
Only the clock header changes production behavior; supported Runtime/defaults/ABI,
old tests, package inventories, workflows and historical evidence are preserved.

Final committed source was repackaged into an actual optional experimental CPack
archive and extracted under custom relocated include/data paths after removing the
original install. Copied installed clock and supported current/legacy Runtime
consumers pass; header and installed release-contract bytes match final source.

Retain the failed initial full-SimCore installed-owner attempt: the optional SDK
omits hal.hpp required by simcore/hal.hpp. This pre-existing experimental packaging
gap remains unresolved for subsequent M28 closeout triage; clock installation and
supported public Runtime checks do not close it. Full-owner lifecycle validation
uses the source build. Also retain the initial diagnostic/link/classifier setup
failures, TSan pre-main failures and original reproduced baseline races.

The first hosted Clang RelWithDebInfo ON job111070486800 failed the unchanged
SampledSimulationUnselectedNative assertion (-2 versus -18, original8ms bound).
Its raw failure is retained as the existing M28-03 startup finding. The first
hosted TSan job111070486689 (copied as111082033729 in attempt2) also failed the
unchanged mock variant, SampledSimulationUnselectedMock, with -2 versus -18 at8ms;
no TSan race warning was reported. Retain that additional startup observation for
M28-03. Final all32 acceptance requires actual unchanged retry passes and does not
erase either finding.

M28-02 benchmark accounting is next to select. M28-02..06 remain inactive;
startup/native-frame timing findings, original05/06 exclusions, and final owner
physical CUDA/XDMA/RT/endurance, real Unreal, controlled performance, independent
human review, production signing/release/deployment acceptance remain open.
This completes only the scoped clock repair and its canonical software closure.

## Historical checkpoints

# M28-01 selected: concurrent experimental clock initialization

Owner selected01 after plan607. Baseline is target293
`389e3fc84cfc2a5946b6e555befdff0962f3989a`. Reproduce the shared clock
initialization race, publish consistent calibration without blocking clock reads,
preserve injected-reader/fallback/monotonic behavior and caller-thread owner arenas.
Only the experimental clock header, new closeout_clock tests/additive wiring and
necessary current documentation/hash bindings are in scope. Preserve every old
test, assertion, deadline, supported Runtime/default/ABI and historical evidence.
Full local/all32 exact-head, instrumented/static/allocation/installed-consumer
gates, risk review and guarded target/canonical integration remain mandatory.
M28-02..06 and final owner bench/engine/human/signing/release stage stay inactive.

## Historical checkpoints

# M28 planned: software closeout before the owner final stage

The owner requested batches for all remaining work that can be completed without
bench testing or human input. M27-01 through08 scoped software is delivered;
target PR293 is merged at `389e3fc84cfc2a5946b6e555befdff0962f3989a` and canonical closure606
at `33173abafe0193aa82e262ace582fe19b9bd10c6`.

Six new planning contracts follow in order. None is selected or activated by this
planning change. Refresh baseline and cause-specific paths when selecting each
batch; the target active contract remains the completed M27-08. Read
[M28](milestones/M28.md) for the queue, acceptance and final-stage handoff.
M28 is scoped software closeout, not global M18/M19/M20/M25/M26 acceptance.

Original05/06 exclusions remain unperformed. Native timing investigations use
injected/simulated drivers only. Real CUDA/XDMA/FPGA, Unreal, controlled performance,
independent consumer review, production signing, release and deployment stay last
under the owner and their existing procedures. No live endpoint is accessed.

## Historical checkpoints

# M27-08 portable migration/readiness delivered; planned software queue complete

[Target PR293](https://github.com/tranquilWorks/cpp-rt-car/pull/293) merged at
`389e3fc84cfc2a5946b6e555befdff0962f3989a` after complete portable160/strict165 and all32 exact-head hosted records
passed at `2d44c92f310eadbd16610368e6173e190ee885d0`. Fetched/tested tree `60731105b0a0f2600f3dbd83d44b0108cdb538f1` matches;
clean/head/base/no-unresolved-review guards passed. Canonical605 supplies activation
at8a3e60b27959f8759d01b4629a2cc90510e24b46. No target/local gate was waived.

The inventory maps existing supported platform/API/package checks. New current-SDK
version/component discovery accepts documented same-major requests and refuses
future/other-major/exact-old/unknown-required requests. The same copied public
consumer builds through modern and legacy CMake targets against an actual relocated
CPack archive after removing the original prefix. Include paths are independent
of the checkout/build/original install. Both emit identical fixed workload records. Final-head hosted relocated consumers
retain their original65 Linux/66 MSVC CTest records. The mandatory ALL build
target additionally runs both installed migration consumers and all eight discovery
requests; raw logs record the required build verification.

Each installed executable passed4096 cycles:790528 callbacks,8192 owner lifetimes,
4096 checkpoint reexecutions,8192 expected state refusals and24576 balanced provider
acquisitions/releases with zero live regions/violations. Measured wall durations
were53.958946s and55.082664s, distinct from79052800 logical nanoseconds per run.
The final committed head was additionally repackaged and the installed release
contract was byte-compared with final source; fresh copied consumers/discovery
and both4096-cycle observations passed again. Retain both package attempts: the
earlier package preceded the last release-contract digest refresh.
Only three explicit provider regions per owner are accounted; total heap/physical
endurance are not inferred. The bounded runner retains complete cycle/diagnostic
logs, hashes, exact commands, measured duration and start/terminal journals.
Nonzero/missing/unbalanced output, timeout and interruption cannot pass; a hard-
killed parent leaves incomplete evidence and work is not automatically resumed.

Full Runtime ASan/UBSan/leaks, initialized TSan16 cycles and Clang14 static checks
pass. All47 pre-main TSan startup failures preceding initialized attempt48 remain.
First contract documentation/digest refresh failures and canonical605 temporary-Git
cleanup failure remain retained; unchanged hosted activation retry passed. Existing
production, old tests/assertions/deadlines, ABI/defaults and workflows are unchanged.
The first candidate added three installed CTest records and passed their platform
jobs, but the frozen XDMA package verifier correctly rejected the changed65-test
inventory. That real failure is retained. The correction changes only new wiring:
mandatory installed migration build verification preserves every original CTest
record/assertion/count. The unchanged full XDMA package verifier passes locally,
and final full/hosted gates are rerun at the corrected head. New wiring is additive. This is added compatibility coverage,
not a claimed production repair or fabricated historical-binary migration result.

M27-01 through08 scoped software cards are delivered. No further M27 software card
is planned. Remaining finite obligations, under their original procedures:

- Original05 generated-input/continuous and06 signature expansion remain unperformed
  under owner exclusions; CAP-M20 is not promoted.
- Retained experimental concurrent-clock and benchmark assumptions, sampled native
  startup timing and07 full-native-frame TSan deadline findings remain open.
- Actual licensed Unreal and unfamiliar-consumer/independent human acceptance.
- Named hardware CUDA/XDMA/FPGA/driver/bitstream/safe-output/device-loss/thermal/
  saturation/endurance and real-time qualification.
- Controlled performance, authenticated provenance/production signing, release
  approval/publication and deployment.

Portable readiness does not close global acceptance or authorize a release.
Closure PR records full control validation and guarded integration.

## Historical checkpoints

# M27-08 selected: platform migration and bounded portable soak

Owner selected08 after target292 merged at `7567c9621d49dc113bca2fd4951cb477d5d63b67` and canonical closure604.
Inventory the existing supported platform/package/API checks; add only missing
same-major installed-package discovery/migration behavior and ordinary fixed
lifecycle/replay/owner-isolation repetitions. Retain exact inputs, observable
outcomes, complete logs, interruption/failure journals and resource conservation
observations. Distinguish logical work from measured wall time. Additive test
wiring is permitted; all old tests, production, ABI/defaults and evidence remain.

No generated-input campaign, deliberate crash/memory-error fixture, scanner,
continuous schedule, new workflow or signature expansion is activated. Original05
and06 exclusions remain unperformed. Existing32 hosted checks, full local gates,
risk review and guarded target/canonical closure remain required and authorized.
Portable repetition is not physical endurance, controlled performance, RT, human
acceptance, release approval or deployment. Native07 full-frame TSan deadline and
historical timing/initialization limitations stay open. Actual Unreal, named
hardware qualification, signing and publication remain separate. This is the last
planned M27 software card; closure must list the finite remaining obligations.

## Historical checkpoints

# M27-07 native golden XDMA preparation delivered;08 remains planned

[Target PR292](https://github.com/tranquilWorks/cpp-rt-car/pull/292) merged at
`7567c9621d49dc113bca2fd4951cb477d5d63b67` after complete portable157/strict162 and all32 exact-head hosted records
passed at `83cc0413fc1e7bfeb877a8eef8ef8644b1e73aff`. Fetched/tested tree `8f598454c394aa9cd8aae44525e4e9f2fcfca97c` matches;
clean/head/base/no-unresolved-review guards passed. Control603 supplies activation
at38437dba944fc305c35e5421411893d84473725d. No target/local gate was waived.

The new optional installed Linux host assembles the frozen golden graph through
the existing native XDMA adapter, explicit borrowed staging and named endpoint/
driver/bitstream/window configuration. Native capabilities and deadlines remain;
replay is disabled. The CLI performs startup and checked stop only, never reports
a completed native golden run. Partial ownership and failed-stop retry are tested.
The actual relocated optional CPack host compiles and refuses missing devices;
final installed kit bytes match reviewed sources. Default SDK component refusal,
independent copied fake consumer, optional consumer wiring, native command protocol/
format refusals, zero submit/poll allocation, full Runtime/native-backend ASan/UBSan/
leaks, initialized TSan and Clang14 static checks pass.

An additional full native-frame probe passes ordinary execution and an earlier
ASan run but exceeded the unchanged500-us native Runtime submission deadline under
initialized TSan (status-18, zero allocations). That failed execution observation
is retained; full frame/oracle/refusal assertions remain callable with --frame.
The required preparation/protocol suite does not assert instrumented-host timing.
No old test, native deadline, production source, ABI/default or workflow was changed.
The initial Clang Debug ON hosted job reproduced the historical
SampledSimulationUnselectedNative status-2 versus expected-18 timing result;
the new preparation test passed. The unchanged job retry passed before integration;
its original failure remains retained and the historical limitation remains open.
The first package-harness diagnostic mismatch and canonical hosted temporary-Git-
cleanup failure are retained; the latter passed an unchanged rerun. No live node
was opened. Tuple fields are operator assertions, not loaded-image attestation.

M27-01 through07 software are delivered. Only08 platform/migration/portable-soak
readiness remains planned/inactive. Native hardware golden execution, physical
FPGA/driver behavior, safe outputs, device-loss/thermal/saturation/endurance and
RT qualification remain unperformed. Original05 campaign/continuous and06 signature
expansion remain excluded/unperformed; CAP-M20 is not promoted. Actual licensed
Unreal, controlled performance, unfamiliar-consumer review and production signing/
release/deployment remain separate. Historical timing/initialization limitations
remain open. Closure PR records complete control validation and guarded integration.

## Historical checkpoints

# M27-07 selected: native golden XDMA host preparation

Owner selected07 after target PR291 merged at `3b9fc08afc1e7c4b5e6230b80f1235477a5acbab` and canonical
closure602. Add a separate optional installed Linux host using the existing XDMA
adapter, explicit host staging and named tuple/configuration requirements. Preserve
the frozen golden workload, simulated kits, Runtime, ABI/defaults and prior evidence.
Validate ordinary fake-driver protocol/lifecycle/format refusals and actual installed
host compilation and absent-device refusal before device side effects. No live
endpoint is accessed by this batch. Physical FPGA/bitstream/driver behavior, safe
outputs, thermal/saturation/device-loss/endurance and RT qualification remain
unperformed pending a named approved bench.

Full local verification, all32 exact-head target checks, applicable sanitizer/static/
package/ABI checks, retained failures, risk review and guarded integration/canonical
closure remain mandatory. Standing scoped publication/merge authority persists;
only completed zero-step control infrastructure failures have the existing exception.
M27-08 stays planned. Original05 campaign/continuous and06 signature expansion,
actual Unreal, controlled performance, unfamiliar-consumer review and production
signing/release/deployment remain separate and unperformed.

## Historical checkpoints

# M27-06 owner-scoped build verification delivered;07 and08 remain planned

[Target PR291](https://github.com/tranquilWorks/cpp-rt-car/pull/291) merged at
`3b9fc08afc1e7c4b5e6230b80f1235477a5acbab` after full portable156/strict161 and all32 exact-head hosted records
passed at `d044fd11cbf49103f8ca7c5ddc1aeb5188a8e581`. Fetched/tested tree `848ca42960cad057cd028c0832c56e959f0ebe8c` matches;
clean/head/base/no-unresolved-review guards passed. Control601 supplies the
owner-scoped activation. No target/local functional gate was waived.

The new ordinary package command compiles the default C++ SDK twice in fresh
build directories, extracts actual CPack archives, builds and runs a copied public
consumer against each, and compares archive bytes and complete member inventories.
It records clean expected source/tree, declared dependencies, actual tool/driver
identities, command outputs/statuses, build configuration hashes and isolated
installed-consumer bindings. Source45cf8a1e10f4e0508132b225e0d761c032eb8ff9
produced two matching3,043,883-byte archives with601 members and SHA-256
445f6499733ea0b3ebe9e92f25e512b6117df7dcb9620f5e09a5a46c8f93cea4. All14
commands and both installed consumers passed. Final evidence-only edits retain
the source-bound implementation; reviewed hashes and actual reports are retained.

Eight ordinary comparison/source/failure tests pass alongside all original
assertions. An intermediate driver accepted a normally completed command beyond
its output limit; an actual predecessor-negative control fails the new oracle and
the final implementation passes. Stale-generated-documentation and premature-launch
attempts remain retained. Earlier completed owned build trees were archived with
verified bytes/modes/links before removal. Production/native/experimental sources,
SDK inventory, ABI/defaults, old provenance/fixture tools and workflows are unchanged.
No existing acceptance or timing check was weakened.

The build entry point is Linux-only. Reports are unsigned local observations,
not hermetic builds, complete host-library closure, authenticated provenance,
cross-host/toolchain reproducibility, signing or release qualification. Interruption
scheduling was not separately exercised. Original06 signature-fixture expansion
remains unperformed by owner scope. Original05 campaign/continuous obligations
also remain unperformed; CAP-M20 is not promoted.

M27-01 through04 and owner-scoped05/06 software are delivered. Remaining planned
software batches are07 native golden XDMA host preparation and08 platform/migration/
portable soak readiness; neither is activated. Physical/RT qualification, actual
licensed Unreal, controlled performance, unfamiliar-consumer review and production
signing/release/deployment remain separate. Historical startup/timing and
experimental initialization limitations remain open. Full local/hosted control
validation and guarded closure integration are recorded in the closure PR.

## Historical checkpoints

# M27-06 selected: independent C++ build and provenance verification

Owner-scoped05 has integrated at b8d54b3aced4083dfd91d34c65e871eab7e2e3c0; its closure evidence follows below.
The already requested06 is now activated from that exact target baseline. The
existing artifact mode copies one archive into two candidate directories; add
actual independent fresh-directory builds, observed source/tool/dependency records
and exact archive/member comparisons with installed consumer checks. Preserve
existing tooling and original32 gates. No signing fixtures or additional workflows
are included; original06 signature expansion stays unperformed.07/08 remain inactive.

# M27-05 owner-scoped regression coverage delivered; M27-06 selected next

[Target PR290](https://github.com/tranquilWorks/cpp-rt-car/pull/290) merged at
`b8d54b3aced4083dfd91d34c65e871eab7e2e3c0` after full portable156/strict161 and all32 exact-head hosted records
passed at `08f73cd2590b45707597dabd6ebfac6e93e6f116`. Fetched/tested tree `c8934389dfbdaa6173fa0f81f3b9f77d12fe5843` matches;
clean/head/base/no-unresolved-review guards passed. Control600 supplies the
owner amendment. No target/local gate was waived.

The new fixed public-API C++ test covers independent Runtime owners, lifecycle
transitions, checkpoint round trips/refusals, compatible ordinary cross-owner
restoration, actual active replay inspection and typed payload canonical bytes,
round trips and refused inputs with preserved output. The same test passed as an
independent consumer of both default and optional relocated CPack SDKs. All71
preserved optional SDK consumers, complete Runtime and test ASan/UBSan/leaks,
initialized TSan, Clang14 analysis and contract/ABI checks passed. All30 Runtime
translation-unit compile commands per sanitizer and exact source bindings remain
retained. Production/native/experimental implementations, original tests,
ABI/defaults and workflows are unchanged.

Retained attempts include an initial unconfigured target, a partial-instrumentation
TSan report not reproduced with complete instrumentation, a Clang14 diagnostic
compatibility failure corrected in the new test helper, sanitizer startup mapping
failures and actual disk exhaustion. Completed owned SDK/sanitizer builds were
archived with verified hashes, modes and links before their originals were removed.
The withdrawn prototype setup failure is retained; no campaign or seeded-defect
execution ran. Fixed examples do not prove exhaustive coverage or concurrency.

This closes only the owner-scoped05 delivery. Original sustained/continuous
campaign, seeded-defect and extra-workflow obligations remain unperformed;
CAP-M20 is not promoted. M27-06 is selected next for ordinary build/provenance
verification, with its activation scope to be refreshed from this merge. M27-07
native XDMA host preparation and08 platform/migration/portable soak remain
inactive. Physical/RT, actual Unreal, controlled performance, unfamiliar-consumer
review and production signing/release/deployment remain separate. Prior timing
and experimental initialization limitations remain open.

Full local/hosted control validation and guarded closure integration are recorded
in the closure PR.

## Historical checkpoints

# Owner scope: ordinary C++ regression and build-provenance work

The owner selected M27-06 after M27-05, then requested that work stay within the
C++ simulation project and avoid the behaviors interrupting the conversation.
M27-05 is narrowed to deterministic public-API regression coverage. Deliberate
crash fixtures, generated-input campaigns, scanners and additional workflows are
withdrawn. Their original acceptance remains unperformed; no continuous-coverage
or security-clearance claim follows. The unpublished prototype is retained as
withdrawn evidence and was never run as a campaign.

Complete the bounded regression tests, installed consumer, ordinary sanitizer/
static and full local checks, all32 baseline hosted records and guarded target/
canonical closure. Then activate selected M27-06 for build/provenance verification.
M27-07/08 and independent hardware/RT/Unreal/human/production release remain separate.
Standing scoped publication/merge authorization persists; no target/local waiver.

## Historical checkpoints

# M27-05 selected: reproducible fuzz and security campaigns

M27-04 target289/control596 is complete. The owner selected05 on target
b17606103e034ec4d6e9a49d5201f1ff33a95631. Preserve the existing smoke/static/
dependency/SBOM gates and add fully instrumented bounded campaigns, uncovered
parser/lifecycle oracles, retained corpus/resource/source/tool evidence, and
seeded sanitizer defect discovery with independent replay/minimization.

Inventory found that the old runtime-profile and live-control replay harnesses
link Runtime without instrumenting that archive in the existing smoke build;
replay is also absent from the smoke runner. The new campaign build instruments
actual implementations separately. Existing production, harnesses, tests,
ABI/default/schema/deadlines and all prior evidence remain unchanged.

The additional least-privilege pull-request/manual workflow has no schedule.
All32 baseline exact-head records plus its campaign check are required (33 total),
along with complete local profiles, focused controls, static/sanitizer/package
checks, risk review and guarded target/canonical integration. Only05 selected;
06..08 and hardware/RT/Unreal/human/controlled-performance/production-signing/
release/deployment remain inactive. Bounded fuzzing is not continuous coverage
or vulnerability clearance. Standing scoped publication/merge authority persists.

## Historical checkpoints

# M27-04 delivered; M27-05 through08 remain planned

[Target PR289](https://github.com/tranquilWorks/cpp-rt-car/pull/289) merged at
`b17606103e034ec4d6e9a49d5201f1ff33a95631` after all32 exact-head hosted records succeeded at `cf993bb956ca89332f42d53ad087a1fcea98e1b3`.
Fetched/tested tree `f359c22ca4e1418d9c3f86878757c5d99b4a5c40` matches; clean/head/base/no-unresolved-review guards passed.
Canonical activation595 is integrated. No target/local functional gate was waived.

The optional installed telemetry source kit now captures bounded copied schema2
snapshots at caller-owned quiescent host boundaries and exports native Perfetto
protobuf, OTLP HTTP/protobuf logs/metrics and Windows TraceLogging. Explicit
session/Runtime/clock provenance, integer preservation, sequence/loss conservation,
queue backpressure, failed-sink retention and bounded drain/discard shutdown keep
capture, encoding and transport outside Runtime lanes. The intermediate JSON
spool is separately versioned and is not itself a native telemetry format.
Transport acceptance is distinguished from downstream delivery; ETW reports an
emission attempt rather than an acknowledgement. No automatic transport retry.

Fresh focused3 CTests with6 parser groups,25 preserved observability/no-allocation
tests, new queue/sample ASan/UBSan/leaks and initialized TSan, Clang14 analysis,
real Perfetto Trace Processor34 events/128 metrics, real OpenTelemetry Collector
34 logs/128 metrics,8 transport negatives, real Windows ETL/TDH collection,
default/optional relocated CPack and71 preserved SDK consumers pass. Independent
malformed-loss baseline controls fail before the fix and pass after it. Final
exact-head full portable155/strict160 and all32 hosted records pass with exact
baseline names/multiplicity. The Windows installed consumer actually compiles
and collects the source kit. Original Runtime/native/experimental implementations,
old tests, ABI/defaults/schema/deadlines remain unchanged.

The actual sample-clock race, Windows compile failure, undeclared loss acceptance,
failed sanitizer startup and candidate02 unchanged sampled-simulation timing
failure remain retained. Candidate01 docs-contract failed the preserved
CommandBatch.SampledSimulationUnselectedMock startup case4; its raw log remains.
Final-head GCC optional SDK also returned startup case7
status -2 instead of the preserved -18 expectation; the source is byte-identical
to baseline and the precise cause is not established by that log. Its failed
attempt and unchanged-head retry are retained, without weakening the oracle.
Focused sanitizer runs instrumented the new source translation units and linked
the unchanged Runtime archive. The separate hosted executor TSan gate instruments
Runtime and passed128 tests. Native ETL was collected and
decoded on the Windows runner; no local downloaded ETL is claimed. Synthetic
caller-provided clock anchors do not qualify physical clock synchronization.
Only CAP-M20 scenario3's native exporter implementation mapping is promoted;
all other release/security/performance/qualification criteria remain independent.

M27-01 through04 software are delivered. M27-05 fuzz/security,06 test-identity
provenance tooling,07 native golden XDMA host preparation and08 platform/migration/
portable soak remain planned/inactive until selected. M19 actual licensed Unreal,
M18 physical/RT, controlled performance, unfamiliar-consumer review and production
signing/release/deployment remain separate. Prior experimental concurrent clock
initialization and historical benchmark precise-cause limitations remain open.
Full local control validation, hosted disposition and guarded closure integration
are recorded in the closure PR.

## Historical checkpoints

# M27-04 selected: optional non-RT telemetry exporters

M27-03 target288/control594 is complete. The owner selected04 on target
5f9a8a4c554cb065cb2ace33f10444d07466c313. Deliver an installed optional
source kit with bounded host snapshot queues, explicit process/session/Runtime
identity, caller-provided clock correlation and loss/backpressure accounting.
Native Perfetto protobuf and OTLP HTTP/protobuf use official optional tooling;
Windows TraceLogging must be collected and decoded on real Windows CI.
The intermediate snapshot spool is not a native telemetry format. No Runtime
lane, public ABI/schema, default SDK target/header or prior implementation/test
changes. Full local profiles, native consumers, sanitizer/static/relocated SDK,
all32 exact-head hosted records, risk review and guarded target/canonical closure
remain required. Only04 is active;05..08 and independent hardware/RT/Unreal/
human/controlled-performance/signing/release/deployment remain inactive.
Standing scoped publication/merge authority persists; no target/local gate waiver.

## Previous checkpoints

# M27-03 delivered; M27-04 through08 remain planned

[Target PR288](https://github.com/tranquilWorks/cpp-rt-car/pull/288) merged at
`5f9a8a4c554cb065cb2ace33f10444d07466c313` after all32 exact-head hosted records succeeded at `f76b19da76caedbdcf1159f2e3a9f8a7b06c610c`.
Fetched/tested tree `009ead1a07c7ee71fefe7602cad6baffd460efd8` matches; clean/head/base/no-unresolved-review guards passed.
Canonical activation590 and cause-driven amendments591/592 plus source-binding amendment593 are integrated.
No target/local functional gate was waived.

Experimental SimCore now waits for worker initialization before frame reuse and
for every dispatched worker to return before shared metadata/counters/reduction
storage reuse. Watchdog callbacks publish only atomic state; coordinator frame
completion logs and applies every pending trip, including the final frame.
Watchdog shutdown publishes stop under its condition-variable predicate mutex.
The clock validates each sample before monotonic publication using the existing
1ms drift bound; an atomic compare/exchange loop prevents stale floor overwrite.
Calibration/default selection and original workloads/deadlines remain unchanged.
Actual baseline negative controls establish each claimed cause independently.

Fresh focused53, unchanged10-repeat2/4/8-thread matrix and Runtime owner lifecycle,
startup/dispatch/watchdog/clock/shutdown causal controls, ASan/UBSan/leaks and TSan,
Clang14 analysis, contract, actual default/optional relocated CPack and71 SDK
consumers pass. Final exact-head full portable152/strict157 and all32 hosted
records pass with exact baseline names/multiplicity. Earlier timeouts, actual
sanitizer races, failed fixture drafts and startup mapping failures remain retained.
No supported Runtime, benchmark, original test, ABI or native source was changed.

The M23 submission fixture classification remains bounded: withholding public
submit entry can expire the original1ms deadline with no backend submissions,
violating the fixture's unchanged exact-one assumption. The original historical
provider_error lacks predicate detail, so its precise cause remains unresolved.
Concurrent process-global experimental clock initialization remains unsupported;
new owner tests serialize construction on each execution thread. No claim that
all historical experimental timeouts have one cause or are universally eliminated.

M27-01 through03 software are delivered. M27-04 non-RT exporters,05 fuzz/security,
06 test-identity provenance tooling,07 native golden XDMA host preparation and
08 platform/migration/portable soak remain planned/inactive until selected.
M19 actual licensed Unreal, M18 physical/RT, controlled performance, unfamiliar
consumer review and production signing/release/deployment remain separate.
Full local control validation, hosted disposition and guarded closure integration
are recorded in the closure PR.

## Historical checkpoints

# M27-03 clock sample validation amendment

Debugger-owned child runs of the unchanged determinism workload stop making
normal progress in SimCore::step sleep. One snapshot shows frame382 requesting
21.4ms sleep for a1ms period while the TSC conversion coefficient is inconsistent
with elapsed steady time. The current check runs only every4096 reads. A separate
mocked-counter negative shows a bad sample poisons the monotonic floor even after
fallback, returning roughly50trillion ns ahead of steady time. These are software
diagnostics, not CPU-frequency or controlled-performance measurements.

Also permit only include/simcore/highres_clock.hpp to validate samples before
publication/floor updates and publish monotonic results with a proper atomic
compare/exchange loop. Preserve the existing1ms drift threshold, calibration and
default TSC selection, all original tests/workloads and supported Runtime. Reject
backward/nonfinite/out-of-range samples. Concurrent clock initialization remains
a separately retained limitation. Keep the experimental watchdog stop repair
below and require combined fresh complete gates; only03 is selected.

## Historical checkpoints

# M27-03 experimental watchdog stop amendment

The first candidate passes48focused tests and a six-test TSan run, but its fresh
10-repeat original workload still times out. A controlled scheduling probe proves
the experimental watchdog destructor can notify before the worker enters its
condition-variable wait, then hang in join. Permit only rt/include/rt/watchdog.hpp
to publish stop under the existing mutex. This header is used by experimental
SimCore and its tests; it is absent from the default SDK and supported Runtime.
Preserve every other rt/include file and all rt/src, original tests/deadlines,
ABIs and previous evidence. Require actual baseline negative, repaired positive,
fresh complete validation and all32 exact-head gates. Standing scoped authority
persists. Other M27 cards and external qualification stay inactive.

## Historical checkpoints

# M27-03 watchdog handoff amendment

Required TSan of the unchanged determinism workload found the experimental
watchdog callback racing frame advancement and degradation settings. The same
allowed SimCore header may transfer those actions through its existing atomic
pending channel to the coordinator at quiescent boundaries, including final
frame and teardown. Preserve original deadlines/ladder behavior/tests and
require baseline negative plus fresh complete gates. This is part of the
selected03 completion; supported Runtime and benchmarks remain protected.
Process-global clock/construction limitations remain separate. Standing scoped
publication/integration authorization persists; later batches stay inactive.

## Historical checkpoints

# M27-03 selected: submission and experimental timeout investigation

M27-02 is complete in target287/control589. The owner selected M27-03 on
b60a73b1e9bacd6ace250dfa1d5d51fab862eaa7. The unchanged local baseline
reproduces an experimental 8-thread FMA-off hang; TSan independently reports
worker arena initialization racing frame reset. Establish deterministic causal
controls and repair only experimental worker readiness/dispatch lifetime.
Trace the M23 benchmark submission finding separately; preserve its original
fixture and supported Runtime. Unestablished causes remain explicitly unresolved.
Keep original seeds, 1500 frames, 5000 elements, deadlines, assertions, ABIs and
support claims. Require focused/full/sanitizer/static/package verification, all32
exact-head gates, risk review and guarded target/canonical integration under
standing authorization. M27-04..08 and external qualification remain inactive.

## Historical checkpoints

# M27-02 delivered; M27-03 through08 remain planned

[Target PR287](https://github.com/tranquilWorks/cpp-rt-car/pull/287) merged at
`b60a73b1e9bacd6ace250dfa1d5d51fab862eaa7` after all32 exact-head hosted records succeeded at `f66052bd27bea3f26fcf986b73e861666571b949`.
Fetched/tested tree `0bae78b38d4f91aa9a1a7e8f0ec3280016c66e25` matches; clean/head/base/no-unresolved-review guards passed.
Canonical activation586 and required hash-binding amendment587 are integrated.
No target/local functional gate was waived.

The shared device service lane previously consumed one-shot command polling
faults before that backend published an owner. An independently failing baseline
control proves success after an idle-consumed overflow. The private correction
retains the first unclaimed callback/count failure in private atomic state and
delivers it before accepting successful completions, checking before and after
polling to cover publication within the callback. Ordinary polling remains active
for late native completion reaping. Completion matching checks published state
before reading slot identity. The atomic occupies existing padding; exact default
MemoryPlan equality passes. No public layout, native source, deadline or ABI change.

The retained startup -2 versus -18 finding is separately classified: channel
status preserves timeout/unknown safety, while startup/repeated stop must retain
invalid_state and live ownership until native completion permits cleanup/live0.
Controlled baseline and repaired probes establish that contract. The original
timing-sensitive immediate-cleanup assertions remain unchanged and can still
fail under host scheduling variation. This is an explicit retained limitation,
not a claim that those assertion failures have been eliminated. The final-head
Clang RelWithDebInfo experimental job and hosted TSan gate also reproduced the old unselected-mock
assertion: -2 versus -18, native8ms, later cleanup0/live0; the new suite passed and the hosted TSan log had no sanitizer race report.
Their complete failed logs and unchanged-head rerun remain retained.
Windows Debug also failed preserved startup and independent-stop assertions at
2024/2004ms, returning timeout rather than success with later cleanup0/live0;
the new suite passed. Duration aligns with the existing injected-card2s hold
bound, while the host watchdog is5s; the exact cause is unestablished. This
separate timing finding remains open, not claimed fixed by the unchanged rerun.

Verification: fresh exact-head portable152/strict156 and all32 records with the
baseline names/multiplicity;26 ordered fault cases, reset and successful subsequent
work, ten complete repeats, owner isolation; pending startup/repeated stop/actual native release;117
preserved command/rate/replay/allocation/MemoryPlan tests and unchanged M17 late
native completion/recovery; ASan/UBSan/leaks and three complete TSan runs; Clang14 production36-TU and new fixture analysis; zero allocation with
positive control; exact default MemoryPlan/checkpoint/active bytes; actual default
and optional relocated CPack independent consumers plus all71 prior SDK consumers.
The rejected first candidate suppressed idle polling and failed native-reaping
checks. An intermediate draft missed publication within poll; deterministic
negative controls reject it and the baseline. TSan found unpublished Runtime
slot reads and unsafe reset/reuse in the new test wrapper: published-state
checks repair Runtime, while only the new wrapper serializes reset/reuse storage
with nonblocking poll. All actual failures and TSan launch failures remain
hash-bound in target evidence and this closure; races were corrected, not waived.
An empty prediagnostic TSan crash has no established cause. No prior test,
assertion, native source, deadline or evidence was weakened or removed.

M27-01 and02 software are delivered. M27-03 submission/experimental timeouts,
04 non-RT exporters,05 fuzz/security,06 test-identity provenance tooling,
07 native golden XDMA host preparation,08 platform/migration/portable soak remain
planned/inactive until selected/refreshed. M19 actual licensed Unreal, M18
physical/RT, controlled performance, unfamiliar-consumer review and production
signing/release/deployment remain independent obligations. This is portable
software/protocol evidence, not physical or qualification acceptance.

Control closure's first executed hosted validation exposed a missing `jsonschema`
dependency in the workflow. A clean environment reproduced four existing import
failures; adding the locally validated pinned version4.10.3 makes those unchanged
tests pass. The failed run is retained under `control-ci-repair`; it was not
eligible for the zero-step exception. Fresh full local and exact repaired-head
hosted validation are required and recorded in the closure PR.

Full local control validation, hosted disposition and guarded closure integration
are recorded in the closure PR. The standing completed failure with steps=[]
exception applies only to control hosted infrastructure after full local PASS.

## Historical checkpoints

# M27-02 selected: startup and poll failure conservation

M27-01 is complete in target286/control585. The owner selected M27-02.
Its refreshed baseline is target677fae6976f8eddd6ed7e060f222c3535a9e7ae2.
Investigate startup -2 versus -18 and one-shot native polling overflow with
controlled ordering; distinguish fixture expectations from production defects.
Preserve safe8ms, native sources, earlier tests and retryable cleanup ownership.
Require baseline controls, focused/sanitizer/static/no-allocation/installed SDK,
full profiles and all32 exact-head target gates, followed by guarded integration
and canonical closure. The current Linux toolchain supports portable software
investigation; physical/RT/Unreal/signing/release remain separate. Other M27
cards stay inactive. Standing scoped publication/merge authority persists.

## Historical checkpoints

# M27-01 delivered; later software batches remain planned

[Target PR286](https://github.com/tranquilWorks/cpp-rt-car/pull/286) merged at
`677fae6976f8eddd6ed7e060f222c3535a9e7ae2` after all32 exact-head hosted records succeeded at `b0fb98248cbd47f4f2f72b966d90d56463c05386`.
Fetched/tested tree `c67efad7af0017974d1898a9cae7a87d426ee64e` matches; clean/head/base/no-unresolved-review guards passed.
Canonical plan582 selected only M27-01. No target/local gate was waived.

Foreign trusted active replay now checks the outer live-control owner and nested
active owner against their separate identity namespaces before replay bookkeeping.
Rejection preserves application state, mailbox accounting, action/correlation,
cursor and checkpoint bytes, permitting later valid admission/capture/own replay.
Ordinary compatible cross-owner replay remains supported. Production changes are
private to host_runtime.cpp; public ABI/defaults/serialization/native backends,
prior tests/source kits, sample guards and protected CI remain unchanged.

Verification: independent baseline failures in12 v1/v2 fresh/restored/used-owner
cases while ordinary cross-owner cases pass; repaired14-case regression suite plus
full golden recovery probe;93 preserved replay/allocation/MemoryPlan tests;
ASan/UBSan/leaks and TSan on the new suite and golden probe; Clang14 production
static36 and two new fixture translation units; exact baseline/default MemoryPlan
and checkpoint/active bytes; actual default/optional CPack with removed original
prefixes, custom paths/spaces, outside-checkout public consumers and inspected
compile commands; all71 preserved optional SDK consumers and missing SDK/kit
negatives. Exact-head full portable151/strict155 and all32 hosted gates passed.

Retained failures include baseline later-capture corruption, the initial test
formatting/include commands, first draft comparing the separate owner counters
against the same namespace (caught by7 preserved tests), and TSan address mapping failures plus one empty prediagnostic process crash
whose cause is unestablished. The corrected regression explicitly separates owner counters.
The first hosted Clang RelWithDebInfo/OFF job also reproduced the retained startup
-2 versus expected -18 finding in unchanged mock/native tests; both new replay
tests passed. Its complete failed log and exact-head rerun disposition are retained.
The original docs-contract workflow also reproduced startup case4 -2 versus -18
in unchanged sampled_simulation_package_consumer (70 other consumers passed).
Its full failed log and unchanged-head workflow rerun are retained separately.
This does not establish a startup repair; M27-02 remains separate.
No earlier failure, assertion or deadline was removed or weakened. Hash-bound
raw logs, baseline/repaired artifacts/binaries, package evidence and risk review
are retained in target evidence and the local verified archive.

Only M27-01 is delivered. M27-02 startup/device-poll conservation,03 submission/
experimental timeout investigation,04 non-RT telemetry exporters,05 fuzz/security
automation,06 test-identity signing/provenance verification,07 native golden XDMA
host preparation, and08 platform/migration/portable soak remain planned/inactive
until owner selection and refreshed activation. Existing M19 Unreal work requires
its licensed real engine environment. M18 physical/RT, controlled performance,
M25 unfamiliar-consumer review, production signing, release and deployment remain
separate. Broader invalid-replay/post-execution transactionality is unproven;
this bounded repair does not close every remaining capability or qualification.

Full local control validation, hosted disposition and guarded closure integration
are recorded in the closure PR. The standing completed failure with steps=[]
exception applies only to control hosted infrastructure after full local PASS.

## Historical checkpoints

# M27 software follow-up queue; M27-01 selected

The owner requested concrete batches for the remaining software work and the
first implementation now. [M27](milestones/M27.md) defines eight bounded cards:
trusted replay rejection; startup/poll reliability; retained timing findings;
non-RT exporters; fuzz/security campaigns; signing/provenance verification tooling;
native XDMA host preparation; and platform/migration/portable soak readiness.
Existing M19-02/03/04 remain the separately environment-gated Unreal sequence.

Only M27-01 is selected. A direct public-API baseline probe reproduces the foreign
trusted active replay rejection followed by failure to capture a valid recovery
artifact (checkpoint lacks compatible live-control correlation state). The batch
must repair that private ordering without changing ordinary cross-owner replay,
public formats/defaults, previous tests or sample guards. Canonical integration
precedes target activation; full local/all32 and guarded target/closure remain
required. No later batch, hardware, Unreal, production signing, release or deployment
is activated. M26-06 target285/control581 remains complete, with all broader gates
and prior failed evidence retained.

## Historical checkpoints

# M26-06 delivered; broader capability acceptance remains open

The living documentation and capability audit [target PR285](https://github.com/tranquilWorks/cpp-rt-car/pull/285)
merged at `2f0c9954e29d9e5b6a4ee8a2105fc13b43206181` after all32 exact-head hosted checks passed at `809265c691fa3d7638088de8050e5490a644ffb2`.
Fetched/tested tree `f0a93d3c43520680036620ee8d45406735755a14` matches. Clean/head/base/no-unresolved-review guards
passed; no target or local functional gate was waived. All six bounded M26
software batches are delivered. This does not close every capability or the
broader assertion that only qualification/release gates remain.

The offline installed manual maps all100 frozen scenario entries and112 canonical
CAP-M15 through CAP-M26 outcomes/details to exact source, tests, evidence and
explicit dispositions. The canonical requirement bytes/revision/blob and frozen
contract digest are pinned; omissions, duplicate rows, stale source/anchors,
co-forged contract metadata and false qualification are independently rejected.
Default CPack ships the manual; benchmark-enabled CPack adds one source-kit command
for the complete showcase and bounded regression soak through preserved public SDKs.

Validation: exact-head full portable149/strict153;24 focused audit tests;257 generated
manual files and378 SDK/source link checks; actual default/optional CPack relocation
with removed original prefixes, custom paths/spaces, outside-checkout build and
mandatory compile-command isolation; all71 preserved optional SDK consumers and
missing-component/source/provenance/binary/stale-manual negatives. The installed
full showcase executes25 benchmark bundles/175 invocations,36 settings and11 faults.
The16-cycle soak adds288 nominal and96 fault/recovery sessions,6,912 nominal logical
ticks and87.44260299 wall seconds, with native/host CPU, simulated CUDA kernel/Graph,
XDMA/combined and actual external controllers. Full state, paired replay, counters,
cleanup, source/executable hashes and durable execution journals are independently
revalidated;11 mutation controls pass. This is bounded portable regression evidence,
not physical endurance, RT or controlled performance qualification.

Raw state/replay/logs, provenance, binaries and exact hashes are retained in the
target M26-06-checkpoint verified3,213-file archive and complete relocated workspace.
Retained failures include initial new Python configure variable, first package's
missing-component diagnostic assertion, and its missing compile-command/private-path
observation. The corrected second complete package passes outside the checkout.
The first complete package archive remains retained; no failure is erased. The hosted CUDA toolkit job spent about50minutes on slow/retried Azure Ubuntu mirror downloads before compilation. Its run was canceled only after every sibling job passed, the full log was retained, and only that same-head job was rerun; final all32 success remains mandatory. A
single-file Git attribute preserves intentional Markdown hard breaks in the exact
historical M20 source snapshot; prior evidence and ordinary whitespace checks remain.

Remaining actions are explicit: M18 named physical CUDA/XDMA/combined and RT
campaigns, including real golden XDMA host integration as needed; M19 Unreal editor
and packaged lifecycle integration; M20 native Perfetto/OpenTelemetry/ETW exporters
(current portable exporter is JSON), controlled performance, continuous security/fuzz,
authenticated signing/provenance, platform/migration/soak and release/deployment;
M25 independent unfamiliar-consumer review. The immutable broader M26 exit expectation
is not silently rewritten or represented as achieved by this audit.

Preserve protected findings: M23 timing-sensitive submission fixture; R4 startup
invalid_state(-2) versus expected device_timeout(-18) with cleanup/live0; Windows/Linux
experimental SimCore4/8thread timeouts; one-shot native poll-overflow unexpected ok
(idle-poll window only an inference); foreign replay on a fresh restored Runtime
owner can invalidate later correlation capture. The existing sample pre-effect guard
avoids that replay path without a Runtime repair claim. No Runtime/native/prior
kit/test/ABI/deadline/protected CI source changed. No later batch, hardware operation,
Unreal, human review, signing, release or deployment is activated.

Full local control validation, hosted disposition and guarded closure merge are
recorded in this closure PR. The standing completed zero-step infrastructure
exception is control-only and cannot waive a target/local functional gate.

## Historical checkpoints

# M26-06 selected: living documentation and feature-completion audit

The owner requested M26-06 after target PR284 and canonical closure578.
The [batch](batches/M26-06.yaml) delivers a source-linked installed manual,
complete CAP-M15 through CAP-M26 requirement accounting and fresh relocated
replay/fault/soak evidence. Integrate this plan before target activation.
Preserve all prior implementations, frozen identities, tests and failed evidence.
Standing scoped publication and guarded merge authorization continues.

The audit must distinguish completed portable composition from remaining
engineering, human review and qualification. In particular, M20 release work,
M25 unfamiliar-consumer review, M18 physical/RT and M19 Unreal are not silently
closed. No subsequent batch, release or hardware activity is activated.

## Historical checkpoints

# M26-05 complete; M26-06 is the remaining software audit

The benchmark, fault and control showcase [target PR284](https://github.com/tranquilWorks/cpp-rt-car/pull/284)
merged at `912ce878ad311d38e452a5d2916ee0daa6ee3f72` after all32 exact-head hosted checks passed at `a25a96ac614fc274582d57492f2d1640dea67461`.
Fetched/tested tree `46f7ea4ad6485103605003fb8297166646dd4803` matches. Clean/head/base/no-unresolved-review guards
passed; no target or local functional gate was waived.

The optional installed public-SDK kit executes fifteen meaningful M23 cases,
25 benchmark bundles/175 invocations, all36 settings across13 frozen levers and
all11 fault campaigns. CPU, owned simulated CUDA kernel/Graph, XDMA and combined
variants support native workers, independent host jobs and actual external CIL
controllers. Full-state/replay/counter/configuration/source/executable checks
independently recompute report, fault and coverage artifacts. Actual64-slot trace
pressure loses20 records; replay guards refuse lost/foreign-owner evidence before
Runtime effects and recover with a paired fresh owner. Separate bounded Runtime
and HAL-copy experiments state their scope and retain low-capacity failures.

Validation: exact-head full portable148/strict152, focused2/2 including14
checksum-repaired/false-evidence mutations and configuration-selection negatives,
ASan/UBSan/leaks2/2, TSan contract plus complete453.64s local process workflow,
Clang14 static7 and actual relocated CPack71 optional SDK consumers. Standalone,
source embedding, original-prefix removal, custom paths/spaces, missing-input
negatives, actual external processes and separate fake/steady workflows pass.
Final hosted compiler/FMA/sanitizer/package/docs gates pass at the exact head.
Raw/state/replay/report archives, file/binary hashes, acceptance mapping and risk
review are retained in the target's docs/evidence/M26-05-checkpoint.

The new TSan aggregate's initial300s timeout is retained; its900s budget covers
the measured complete run while preserving175 invocations, all child bounds,
checks/instrumentation, prior timeouts and Runtime deadlines. A Windows Debug
failure exposed Release-only executable lookup; explicit CMake configuration
selection now reaches all seven executables, with missing/ambiguous selections
rejected. The final installed/embedded package and hosted Windows gates verify
that correction. Backend identity metadata and the linked negative hashes were
also corrected; earlier evidence remains retained.

Preserve protected findings separately: M23 timing-sensitive submission fixture,
R4 startup cleanup-status mismatch (-2 versus expected-18 with cleanup/live0),
Windows/Linux experimental SimCore determinism timeouts (4/8-thread FMA-off),
and the one-shot native poll-
overflow fixture finding (unexpected ok; unchanged isolated20/20 then complete
full passes). A possible idle-poll injection window is an inference, not a proven
root cause. Direct foreign replay on a fresh restored owner can invalidate later
correlation capture; this sample's pre-effect guard avoids it without a Runtime
repair claim. Local pre-main sanitizer loader failures, disk interruption and
intermittent API errors are retained. No prior source/test/assertion was weakened.

M26-06 living documentation/feature-completion audit is next and remains inactive.
CAP-M26 stays incomplete until that separate audit. Independent human first-use,
physical CUDA/XDMA/combined/HIL, RT1/RT2, controlled performance, Unreal,
signing/release and deployment remain separate and unperformed without named
evidence. Artifact hashes do not authenticate physical execution.

Full local control validation, hosted disposition and guarded closure merge are
recorded in this closure PR. The standing completed zero-step infrastructure
exception is control-only and cannot waive a target/local functional gate.

## Historical checkpoints

# M26-05 selected: benchmark, fault, and control showcase

The owner requested M26-05 after [target279](https://github.com/tranquilWorks/cpp-rt-car/pull/279)
and [canonical closure575](https://github.com/tranquilWorks/portfolio-control/pull/575).
The [batch](batches/M26-05.yaml) scopes the fifteen frozen M23 provider cases,
finite actual tuning experiments, eleven faults including telemetry loss,
exact live-control outcomes, independent machine-readable reports and an
optional benchmark-enabled installed source kit. Merge this plan before target
activation. Preserve all earlier kits, framework/Runtime/native sources,
frozen identities and test/evidence gates. Standing scoped publication/merge
and control-only completed zero-step infrastructure authority continue.

M26-06 remains inactive and owns the final living documentation/capability audit.
The known M23 timeout, R4 cleanup-status fixture and Windows experimental
scheduler findings remain separately scoped. No human, physical/HIL/RT,
controlled-performance, Unreal or release/deployment claim is added.

## Historical M26-04 completion

# M26-04 complete; two software batches remain

The golden XDMA sampled loopback [target PR279](https://github.com/tranquilWorks/cpp-rt-car/pull/279)
merged at `6d6dbc98a4f1d6eb438d61cbeecc2a0f1d1ba252` after all32 exact-head checks passed at `a3dd6116e128d7a4f8eb48031b3ac7359596122b`.
Fetched/tested tree `e19616888de52f7260d4ac1ded5f9f1a9435e984` matches. Clean/head/base/no-unresolved-review
and fetched-tree guards passed; no target or local functional gate was waived.

The complete installed public-SDK kit executes the frozen sensor/actuator loop
through actual Runtime sampled channels and native XDMA worker batches using
an owned simulated driver. CPU and combined CUDA kernel/Graph physics run with
native workers, independent host jobs or an actual external CIL controller.
Exact full-state parity, sampled safety/sequence/age, operation/resource counts,
originating-owner trusted replay and paired fresh-owner checkpoint recovery pass.
Transport faults, missing/duplicate/stale samples, native queue/cancel, partial
lifecycle failures, retained ownership, checked retry and independent owners are
covered. Only the owned simulator enables mock replay and host timing policy.

Repairs280/281/282/283 were separately integrated and canonically reactivated
before completion. Preserve ring4, native CUDA1/XDMA2 with aggregate3 admission,
safe8ms logical/backend deadlines, finite5s simulator watchdog, all public/ABI/
schema/default identities, prior kits/tests/evidence and native backend sources.
The feature adds no further Runtime or native driver changes.

Validation: contract, full portable148/strict152, focused37, ASan/UBSan/leaks25,
TSan25, zero ordinary/aligned allocations with positive controls, Clang static,
actual relocated CPack after removed original prefix with custom paths/spaces,
all56 prior SDK consumers plus9 XDMA variants=65, source embedding and negatives.
The native43/host31/external11 process suites and independent artifact checks
include invalid inputs, missing peers, foreign variants and checksum-repaired
corruptions. Reviewed source identities and all failed attempts remain retained.

New complete1024-tick sanitizer cases initially exceeded their new120-second
process harness; an unchanged O1 kernel run completed in121.09s. Only these new
cases receive300s under sanitizers. The new native43-case CLI aggregate also receives120+3*300=1020s only
under sanitizers, retaining every existing child300s bound. Hosted TSan at
superseded73a3 passed121/122 but this aggregate hit120s after40 short cases;
its unchanged fully instrumented local43-case probe then passed in785.59s.
The corrected final hosted TSan gate passed122/122; its complete native CLI
aggregate passed in321.16s with all43 cases and original child bounds. The full
workload, owner replay, every
assertion/instrumentation check, ordinary/prior test timeouts and Runtime safety
deadlines remain unchanged. O2 experiments were not adopted. Prior Windows
scheduler-sensitive fixture failures and API errors remain documented separately;
complete final-head hosted jobs passed. The earlier feature checkpoint Clang
Debug ON job109692309651 passed167/168 but a protected R4 startup-timeout
fixture returned invalid_state instead of device_timeout; subsequent cleanup
succeeded with live0. Pending-cleanup timing is an inference from unchanged
Runtime/fixture sources, not a reproduced root cause. The failed log and finding
are retained as a separate unresolved fixture follow-up. It recurred at the
corrected a3dd local strict151/152 and GCC optional SDK69/70 gates with the
same startup-2/expected-18 diagnostic and successful cleanup/live0. Complete
local/hosted reruns passed at identical final head; no assertion/deadline changed.
Final-head Windows RelWithDebInfo attempt1 passed167/168 CTests; protected
simcore_all timed out at its unchanged300s limit, last reporting experimental
4-thread FMA-off determinism. All new XDMA tests passed. The Windows Debug
sibling was canceled. Complete Windows jobs passed on the corrected final candidate; no rerun
was issued on superseded73a3 because the aggregate TSan harness needed a
correction. This separate experimental timeout remains retained, without
source/deadline changes or a proven root cause. No performance claim follows.

Remaining software batches are M26-05 benchmark/fault/control showcase and
M26-06 living documentation/feature-completion audit. Both remain inactive;
M26-05 is next to plan, and CAP-M26 remains incomplete. M25 unfamiliar-consumer
review is UNPERFORMED. Physical CUDA/XDMA/combined/HIL, RT1/RT2, controlled
performance, independent human review, Unreal, signing/release and deployment
remain separate. Artifact hashes do not authenticate physical execution.

Full local control validation and hosted control disposition are recorded in
this closure PR. The standing completed zero-step infrastructure exception is
control-only and never substitutes for a target/local functional gate.

## Historical checkpoints

# M26-04 reactivation after sampled timing/completion cleanup repair

M26-04R4 target PR283 merged at 3ecf5695f67b604504a6caa7d5fc6073c3984a92, tested head fb72c963b53f05e0478c1c261ec779fb75c5778d, tree a90a55fd39a27a8ba73f02a69101f6af19482613.
All32 exact-head checks and full111+115, focused123/new13, ASan/UBSan/leaks13,
TSan13, three allocation controls,36TU plus final delta/fixture static, actual CPack relocated full56SDK
and exact default MemoryPlan/checkpoint/active bytes pass. Fetched tree matches.
Runtime/fixture/experimental/sanitizer startup and Windows failures are retained;
no gate waived.

Reactivate only preserved M26-04 draft279 after this canonical amendment merges.
Finish all original acceptance with fresh feature gates. Frozen ring4, native
CUDA1/XDMA2/aggregate3 opt-in, safe8ms and all prior Runtime/native/test/evidence
remain protected. The retained feature source and earlier probe results require fresh complete
feature verification and are not feature closure. M26-05/M26-06 and physical/human/RT/Unreal/performance/release
remain separate. Standing scoped publication/integration authority persists.

## Historical checkpoint

# M26-04R4 bounded cleanup amendment

Timeout regression exposed a retained native completion after Runtime polling
quiesces; eight checked stops cannot unregister its referenced buffer, and
Runtime destruction fails closed. Extend R4 only to bounded completion collection
on checked stop after lane quiescence, using existing private storage/API.
No wait/deadline/public/native-source change. Require controlled baseline
negative, resource/retry tests and fresh local/all32 gates. Then complete
feature279; M26-05/M26-06 remain inactive.

## Earlier checkpoint

# M26-04R4: existing simulator timing on sampled lifecycle submissions

The owner requested repair and completion. Feature279 retains an isolated native
XDMA event-hold reproducer: regular simulated work uses the configured host
watchdog, while startup/shutdown omit it and fail with the logical clock fixed.
Scope only private propagation of the already approved explicit mock policy in
[M26-04R4](batches/M26-04R4.yaml). Preserve safe8ms logical/backend timing and
native/default behavior, public formats and all three prior repairs. Require
baseline negatives, full local/all32 gates, then integrate, canonically reactivate
and complete M26-04. No new public decision or later-batch activation.

## Historical checkpoint

# M26-04 reactivation after sampled recovery repair

M26-04R3 target PR282 merged at f5402b9a646a6d7adfbb54f5eca2170a69a6e292, tested head 42ab0fd4ce0b981fab3448ad1bb938111ad19a14, tree e710e2b781aa5e62839391a7fc3a346caaa57ce2.
All32 exact-head checks and full110+114, focused110/new11, ASan/UBSan/leaks11,
TSan11, three allocation controls,36TU static, actual CPack relocated full55SDK
and exact default MemoryPlan/checkpoint/active bytes pass. Fetched tree matches.
Disk-full/setup/fixture/sanitizer startup failures are retained; no gate waived.

Reactivate only preserved M26-04 draft279 after this canonical amendment merges.
Finish all original acceptance with fresh feature gates. Frozen ring4, native
CUDA1/XDMA2/aggregate3 opt-in, safe8ms and all prior Runtime/native/test/evidence
remain protected. The16 native fault and36 campaign probes are prerequisites,
not feature closure. M26-05/M26-06 and physical/human/RT/Unreal/performance/release
remain separate. Standing scoped publication/integration authority persists.

## Historical checkpoint

# M26-04R3: sampled-I/O lifecycle and checkpoint prerequisite

Capacity repair281 and reactivation566 are merged. Preserved feature279 at
e9d7d025552c61379c4d4530888ce512a31b266a demonstrates two protected Runtime
correctness defects: retry after safe ACK/partial teardown resubmits to stopped
workers; restoring a produced sampled frame clears required producer provenance.
Complete bounded [M26-04R3](batches/M26-04R3.yaml) within the owner's repair-and-
finish sequence, under standing scoped publication/integration authority. No new
public policy/format/capability is authorized. If existing bytes cannot prove exact
reconstruction, a separate explicit design decision is required. Preserve all
failed evidence and both repairs; require fresh local/all32 gates, integrate
separately, then canonically reactivate and finish M26-04. M26-05/M26-06 inactive.

## Earlier checkpoint

# M26-04 reactivation after capacity policy repair

M26-04R2 target [PR281](https://github.com/tranquilWorks/cpp-rt-car/pull/281)
merged at `242793be0cb1ff75b56c74e5b89d0f6e8a21fd76` after all32 exact-head checks at `187f2ea721d7da38bb5bf2563a6e0cceda35dbc9`;
fetched tree equals tested `89db0965a0b5cd0c75866158f39e5d901afe3d3c`. Full local109+113, focused113,
sanitizers51+51, allocation controls, production36TU static, relocated full52 SDK,
ABI/default-v1 and exact default MemoryPlan/checkpoint/active bytes passed.
Every failed setup/build and startup-only TSan mapping attempt remains retained.
No target or local functional gate was waived. Storage repair280 stays integrated.

Reactivate [M26-04](batches/M26-04.yaml) after this amendment merges. Reconcile
preserved feature279 and complete all original feature acceptance with fresh gates.
Only new combined execution selects native_per_backend: aggregate reservation3,
actual CUDA1/XDMA2; frozen XDMA storage stays2, sampled ring stays4 and safe8ms stays.
The prerequisite24-tick six-mode parity/replay probe is not full feature closure.
Preserve all Runtime/native/repair sources and prior tests/evidence. M26-05/M26-06
remain inactive. Human/physical/RT/Unreal/performance/release gates stay separate.
Standing scoped publication/merge authority persists.

## Historical checkpoint

# M26-04R2 approved: per-backend native capacity

Owner approved the concrete capacity repair proposal and requested finish.
Implement [M26-04R2](batches/M26-04R2.yaml) after canonical integration, preserving
uniform defaults and native CUDA1/XDMA2 while aggregate admission reserves3.
Require all32 target gates, merge separately, then canonically reactivate and
complete retained M26-04 draft279. Storage repair280 and all prior evidence stay
preserved. M26-05/M26-06 remain inactive. Standing scoped merge authority and
control-only completed zero-step exception persist; no target/local waiver.

## Earlier checkpoint

# M26-04 reactivation after four-slot storage repair

M26-04R target [PR280](https://github.com/tranquilWorks/cpp-rt-car/pull/280)
merged at `e8caf4396cd5987d9aa4a4bf3dad9a178cf2ded7` after all32 exact-head checks at `a7a6b06c5f3293f8ed35634555e8c15a89ab92a9`;
fetched tree equals tested `c479c55163e550affd17f5f8b8a653c1e9733506`. Full local108+112, focused37,
sanitizers52+52, allocation controls, production36TU static, relocated SDK/package,
ABI/default-v1 and exact two-slot checkpoint/active bytes passed. Retain every
failed attempt, including Windows aligned-fixture C4324 and TSan startup mapping.
No target or local functional gate was waived.

Reactivate [M26-04](batches/M26-04.yaml) after this canonical amendment merges.
Reconcile preserved feature PR279 with repaired main, then complete every feature
acceptance item and fresh local/all32 hosted verification before closure. Actual
frozen ring4 now uses real storage. Preserve all Runtime/native backends and
repair regressions/evidence. The earlier two-slot diagnostic remains diagnostic.
M26-05/M26-06 stay inactive. Human, physical/RT, Unreal, controlled performance,
signing/release/deployment remain separate. Standing scoped authority persists.

## Historical checkpoint

# M26-04R approved: explicit four-slot sampled storage

Owner approved the proposed separate repair and requested resume/complete.
Merge [M26-04R](batches/M26-04R.yaml), implement against merged M26-03, verify
all32 exact-head target gates and integrate; then canonically reactivate and
complete retained M26-04 draft279 at998ec43035229406e93e6294e0834a0b4204b767.
Existing ring_capacity4 will select real bounded storage, preserving default2,
public layouts/artifact schemas and all earlier source/tests/evidence. The
frozen-four-versus-Runtime-two diagnostic remains retained; no sample downgrade.
M26-05/M26-06 and human/physical/RT/Unreal/performance/release stay separate.
Standing scoped publication/merge and control-only completed zero-step exception
persist; no target/local functional gate exception.

## Earlier M26-04 checkpoint

M26-04 header-description correction: both the preserved application envelope and public sampled-I/O header are 120 bytes. Their checksum, status, sequence/generation and timestamp semantics differ and require an explicit codec. No implementation scope, acceptance, protected source or gate changes. M26-05/M26-06 remain inactive.

# M26-04 selected: XDMA HAL HIL-loopback

Owner requested M26-04 after target PR277 and control closure PR557 merged.
The [canonical batch](batches/M26-04.yaml) scopes a new public-SDK source kit
for actual Runtime sampled-I/O through the native XDMA candidate with an owned
simulated driver, both CPU physics and combined CUDA kernel/Graph physics,
acknowledged safe outputs, faults/recovery and installed/process/replay evidence.
Merge this plan before target activation. Preserve the frozen workload, all prior
kits/tests/evidence, native backends/Runtime/ABI and protected CI. Eight logical
phases may use explicit bounded terminal-bookkeeping callbacks with truthful
physical graph/budget accounting. Only owned simulators select mock capability
and finite host watchdog; native replay/physical safety are not claimed.

M26-03 merged targetb0564fef90ce9cc3537e2814e8e972c4e32cc168 with all32 final checks;
control closurea82253d2cb2c290f77c2be7c9c7af88cfc0ae9ef records exact identities.
The known unchanged M23 timeout-fixture submission assumption and failed stress
probes remain separately scoped benchmark follow-up. M26-05/M26-06 stay inactive;
human/physical/RT/Unreal/controlled-performance/release gates remain separate.
Standing scoped publication/integration authority and the control-only completed
zero-step exception persist; no target or local functional exception applies.

## Historical M26-03 completion

# M26-03 complete; three software batches remain

CUDA golden physics [target PR277](https://github.com/tranquilWorks/cpp-rt-car/pull/277)
merged at `b0564fef90ce9cc3537e2814e8e972c4e32cc168`, exact tested head `a8cca85514a78b98e2feeca412054d8330cebd76`,
fetched/tested tree `7a36cf6e8bc272d9f8ccbbfc261daf04cc7c6ea4`. All32 exact-head records passed with
M26-02's exact names/multiplicity, including both scaling-smoke records.
Hosted runs: 36544897817, 36544902871, 36544902881, 36544902889, 36544902937, 36544902950. Clean/head/base/no-unresolved-review guards and
fetched merged-tree equality passed; no target or local functional gate was waived.

The installed public-SDK kit runs CPU fallback and actual Runtime CUDA
kernel/Graph command batches over the frozen integer SoA scenario. Native and
independent host execution, actual external CIL processes, complete-state CPU/
kernel/Graph parity, exact backend/resource/telemetry artifacts, originating-owner
trusted replay and fresh-owner paired-checkpoint recovery are covered. Tick6
actual driver loss/query/reset faults prove no failed publication, retained
ownership and checked cleanup retry. Native CUDA remains nondeterministic for
replay; only the owned injected-driver simulator declares mock semantics.

The separately approved simulator timing prerequisite PR278 merged at
c78075e2b30efba48db4f0ca8136110b1399baf5 after all32 gates. Canonical reactivation
[control555](https://github.com/tranquilWorks/portfolio-control/pull/555) merged at
7ce76ddfd4d3061b3b55bfffc88f6e8ca11e9548, blobef229993dec359b6e35662100475473bb2760350.
Only the simulator selects its explicit five-second host watchdog; logical and
command budgets stay one millisecond. Runtime/native backends, frozen scenario/
oracles, earlier kits/tests/evidence, stable ABI and protected CI remain unchanged.

Validation: explicit contract, quick107/107 and full portable107/strict111 PASS;
focused golden40/40, old CPU Python25, ASan/UBSan/leaks23 and TSan23 C++ cases,
zero-allocation and concurrency/lifetime checks, O0 CLI/process sanitizer suites,
40 artifact mutation controls and Clang static analysis PASS. Actual relocated
CPack after removed original prefix, custom paths/spaces, complete prior SDK,
source embedding and negative controls PASS. Optional real CUDA host/PTX/launcher
compile and51 toolkit SDK consumers pass. Driver-independent help0 and absent
driver/toolkit stub NOT_RUN/3 pass. No physical CUDA execution was performed.

Retained failures/corrections: foreign Runtime replay originally diverged after
execution, corrected at the sample import boundary before side effects; cleanup
fault fixture now injects actual unregister failure; one reusable event per owner
is counted correctly; automatic3MiB Windows test arena moved to heap; new matrix
and process tests split into bounded cases without removing any workload or
assertion; fully instrumented fixture uses-O1 with Debug/O0 Runtime/backend;
GCC11 allocation guard moved unchanged into its own new TU with positive count
controls; Windows exact unsupported_best_effort policy fallback is checked.
The final-head first GCC Debug/FMA-on job passed126/127 but failed the unchanged
M23 timeout fixture: provider_error before measurement. A retained ASan stress
probe and diagnostic-only copy show terminal timeout with zero submissions, one
provider/producer and no publication: the default1ms host deadline can precede
backend submission, while the old fixture asserts exactly one. This baseline
benchmark assertion remains scheduler-sensitive and requires separately scoped
follow-up (relevant to the later showcase); protected source/assertions/timeouts
were not edited. The complete original hosted job was rerun at the same head;
all32 final records passed. Failed probes are not counted as passes.

All original timeouts, compiler failures, source-provenance rejection, retries
and corrections remain in target M26-03 evidence. No warning, sanitizer diagnostic,
prior test or timeout was weakened. Agent review is not independent human review.

Remaining software scopes: M26-04 XDMA HAL loopback; M26-05 benchmark/fault/control
showcase; M26-06 living documentation and feature-completion audit. M26-04 is next
to plan separately; this closure activates none and does not complete CAP-M26.
M25 unfamiliar-consumer acceptance remains UNPERFORMED. Physical CUDA/XDMA/HIL,
RT1/RT2, controlled performance, Unreal, signing/release and deployment remain
separate. Sample MemoryPlan bounds do not establish whole-process/OS bounds;
artifact hashes do not authenticate physical execution.

Control closure full local validation and exact-head hosted disposition are
recorded in its PR. The standing control-only completed failure with steps=[]
exception remains available only after full local validation passes.

Retained [final integration logs and baseline fixture finding](evidence/M26-03-closure-2026-09-29/README.md).

## Historical M26-03 planning and prior completion

# M26-03 reactivation after simulator timing repair

M26-03R target [PR278](https://github.com/tranquilWorks/cpp-rt-car/pull/278)
merged at `c78075e2b30efba48db4f0ca8136110b1399baf5` after all32 exact-head gates on `ecd200b30d7651552d4cc58ff3d98b70e6e11c3d`;
fetched tree equals tested `2a8e96e63e40323a4eb236628954e1beac3ccd32`. Local full72+76, focused/sanitizers60,
allocation, static, relocated SDK, ABI and default-byte checks passed. Retain
all initial failures and the final repair evidence. No functional gate was waived.

Reactivate [M26-03](batches/M26-03.yaml) only after this canonical amendment is
merged. Reconcile preserved feature PR277 with repaired main. Only its owned
simulator selects the finite five-second host watchdog; logical budgets, native
CUDA, Runtime and all prior/repair tests remain protected. Finish every CUDA
feature acceptance item, fresh local and all32 hosted gates before closure.
M26-04..06 remain inactive. Human, physical/RT, Unreal, controlled performance,
signing/release/deployment remain separate. Standing scoped authorization persists.

## Historical checkpoint

M26-03R scope correction: current implementation hashes in the retained CUDA
matrix must track the approved Runtime/header changes. Refresh only product_sources;
preserve all historical gate/source/evidence bindings, rows, denominators and
native capabilities. This is required by the existing release-contract gate,
not new capability evidence. Canonical amendment precedes that target edit.

# M26-03R simulator timing approved

Owner answered go03 to the explicit timing-policy proposal. Merge the bounded
[M26-03R plan](batches/M26-03R.yaml), implement from merged M26-02 main, and
integrate only after all32 exact-head target gates. Preserve blocked feature
PR277 at494a7cd and its repeated ordinary timeouts; never waive that evidence.
The opt-in separates logical completion from a finite simulator host watchdog;
default/native behavior and frozen scenario stay unchanged. After repair merge,
canonically reactivate M26-03 and finish its existing draft. M26-04..06 inactive.
Standing scoped publication/merge authority and the control-only completed
zero-step exception persist; no target/local functional exception.

## Prior M26-03 planning checkpoint

# M26-03 CUDA physics selected

The owner requested the next batch after M26-02 closure. Merge the bounded
[M26-03 plan](batches/M26-03.yaml) before target activation from
PR276 main dbbab7a433a01459ed737cbb19d3b1a64a3ea1bf. Replace only physics with
actual Runtime CUDA kernel/Graph commands and preserve the frozen scenario,
controls/rates/channels, independent oracles, CPU fallback and public-SDK use.
The native backend declares deterministic_mock=0: portable replay requires a
separately identified simulator-only forwarding adapter over the actual CUDA
backend and an owned deterministic driver. Native/physical replay stays unsupported.
No production or frozen-contract change, artifact identity rewrite, prior test
weakening, or physical claim is authorized. Require all32 exact-head target gates.
M26-04 through M26-06 remain inactive. Standing scoped integration authority and
the control-only completed zero-step exception persist; no target gate exception.

## Previous M26-02 completion

# M26-02 complete; four software batches remain

Portable multi-entity CIL [target PR276](https://github.com/tranquilWorks/cpp-rt-car/pull/276)
merged at `dbbab7a433a01459ed737cbb19d3b1a64a3ea1bf`, exact tested head `e0780b2b4e11ebe8fdfc9c67de50b9814f231972`,
fetched/tested tree `227608ba7b434c07b6e19253664fa797aecc102b`. All 32 exact-head records passed with
M26-01's exact names/multiplicity, including both scaling-smoke records.
Hosted runs: 36513520224, 36513522833, 36513522843, 36513522861, 36513522867, 36513523001. Expected-head/base, clean-worktree,
review-thread and fetched-tree equality guards passed; no target gate was waived.

The installed public-SDK source kit implements eight actual CPU callbacks, five
active rates and five cross-rate channels over fixed-capacity 256-entity three-axis integer
SoA state. Native workers and independent host jobs execute nested work; independent
C++ and Python oracles verify complete state, tails, counts, ages and controls.
Actual typed controls, originating-owner M21/trusted M22 replay, cross-owner active
rejection and fresh-owner paired-checkpoint recovery are covered. The separate
vector shared-memory controller runs in an actual second process with bounded
mapping/peer ownership, corruption/stale/replay/death/reconnect tests and checked stop.

Owned overload, stale-input, rejected/replaced-control and missing-peer campaigns
pass in native/host CLI modes; applicable external campaigns also pass. Overload
records the actual tick 6 deadline failure, resumes inspected checkpoint stream
positions without pretending historical action bytes were copied, and verifies
zero gaps and exact action counts. Runtime/source/SDK/ABI, M26-01 immutable JSON
and all previous kits/evidence remain unchanged. No CUDA/XDMA variant or benchmark
showcase is included in this closure.

Validation: 25 Python contract/config tests, complete contract, explicit quick 71/71,
full portable 71/71 and strict 75/75 PASS (verify-full-20260929T024117Z.log); focused ASan/UBSan/leaks 5/5,
process-local TSan 5/5, no-allocation/concurrency/provider-retention tests and Clang
static analysis PASS. Actual relocated CPack with removed original prefix/custom
paths/spaces, all prior SDK consumers, source embedding, one-command external run
and negative controls PASS. Existing hosted compiler, sanitizer, determinism,
package/archive/manual consumer, ABI/release/assurance gates all passed. Exact
commands, identities, failure/retry evidence and risk review are in target
`docs/evidence/M26-02-2026-09-29.md` and PR276.

Retained findings: initial domain-budget allocation failed admission and was
corrected to preserve exact per-domain envelopes; old-owner checkpoint/trusted
pairing was rejected and corrected through public restore/write; lossless history
negative initially checked the wrong dropped/overwritten counter; source changes
during an early TSan run correctly invalidated provenance. Process-local setarch
addresses an initial TSan startup mapping failure without changing machine settings.
First-head Windows World C4324/C4805 compilation failures were corrected with
explicit unchanged-layout padding and uint64 boolean comparisons, without warning
suppression. A later Windows standalone test exposed psapi.h before windows.h;
the new helper now preserves prerequisite header order. Its C4430/C2146 failure
and paired matrix cancellation are retained. Remaining jobs on the superseded
failing head were cancelled after the corrected head was pushed; all32 final-head
checks passed. First fresh-owner action drain exposed missing historical bytes;
the corrected path drains the old prefix and bounds inspected new cursor positions.
No assertion, test timeout, source identity or required gate was weakened.

Canonical plan [PR546](https://github.com/tranquilWorks/portfolio-control/pull/546)
merged at e7b8b39e7979b4e555567eccd169f5cf05690ee2. Replay ownership amendment
[PR548](https://github.com/tranquilWorks/portfolio-control/pull/548) merged at
ab889ba70d768b73eb9c209d6aaa57f8febe92b0, canonical blob
98cdb422eefd68a9560626c2506277eeb1c2ed74. Both full local control profiles passed.
Hosted plan 36506471890/job109208909601 and amendment 36507635209/job109212547178
completed failure with steps=[] and remain UNPERFORMED under the standing
control-only exception. Local functional and target gates are never waived.

Remaining software scopes, to plan separately: M26-03 CUDA physics; M26-04 XDMA
HAL loopback; M26-05 benchmark/fault/control showcase; M26-06 living documentation
and feature-completion audit. This closure activates none and does not complete
CAP-M26. M25 independent unfamiliar-consumer acceptance remains UNPERFORMED.
Physical CUDA/XDMA/HIL, RT1/RT2, controlled performance, Unreal, signing/release
and deployment remain separate. Payload/MemoryPlan bounds do not claim process
RSS/OS-stack bounds; CIL checksum is corruption detection, not authentication.

Control closure full local validation and exact-head hosted disposition are
recorded in its PR. Standing scoped publication/integration authority and the
control-only completed zero-step exception persist; no target gate exception.

## Historical M26-02 planning and prior completion

# M26-02 replay ownership clarification

Source inspection after plan PR546 found that `Runtime::replay_active()` explicitly
binds its artifact to the originating `observability.runtime_id` (target
`rt/src/host_runtime.cpp:14415`), while checkpoint restore rebases control handles
and reconstructs CPU cross-rate stores in a fresh compatible Runtime. Amend only
M26-02 acceptance to require same-owner active/trusted replay, explicit cross-owner
replay rejection and fresh-owner paired-checkpoint recovery. M26-01 already
requires fresh-owner recovery, not cross-owner active replay, so its frozen JSON
and all Runtime/SDK semantics remain unchanged. No production repair or artifact
identity rewriting is authorized. Merge this clarification before dependent replay
implementation; independent model/codec work remains within the approved scope.

## Previous M26-02 selection

# M26-02 portable CIL implementation selected

The owner requested M26-02. Merge [the bounded plan](batches/M26-02.yaml) before
target activation from PR275 main11fce253dc601824eeadbce519b8135bc778815c.
Implement the frozen CPU golden scenario, actual native/host Runtime rates,
controls/checkpoint/replay, owned faults and optional separate-process vector CIL.
Preserve the M26-01 contract/hash, production/SDK/ABI and all previous kits/evidence.
Require full local and all32 exact-head target gates. Standing scoped integration
authority and control-only completed zero-step exception persist. M26-03 through
M26-06 remain inactive; M25 human and physical/RT/Unreal/release gates remain open.

## Previous completion record

# M26-01 complete; five implementation/audit batches remain

Golden scenario/lever contract [target PR275](https://github.com/tranquilWorks/cpp-rt-car/pull/275)
merged at `11fce253dc601824eeadbce519b8135bc778815c`, exact tested head `9dd5f2bd28da1e0522e573eb0feafc7e04982dc1`,
fetched/tested tree `27f1d8e38f527819b9338862fb3deabad09529c0`. All32 exact-head records passed with
M25-06's exact names/multiplicity, including both scaling-smoke records.
Hosted runs: 36500582563, 36500586225, 36500586280, 36500586320, 36500586328, 36500586395. Expected-head/base, clean-worktree,
review-thread and fetched-tree equality guards passed; no target gate was waived.

M26-01 freezes a sample-owned three-axis integer SoA scenario: capacity256,
default16 entities, CPU/CUDA zero-tolerance piecewise oracle, explicit phase/
resource DAG and host staging, five rate domains, sampled channels, exact
controls/rollback/checkpoint identities, bounded host ownership and recovery.
Eleven planned faults, thirteen tuning levers, fifteen M23 benchmark cases,
six artifact families and portable/physical/Unreal variant boundaries are bound.
Canonical JSON SHA256 is9c93b5d5970caa5dc4570a4d0c43c9ca21ab7aa5a7211c02ce946cf8ffa62771.

The standard-library validator and22 unittest methods reject missing/unknown
fields, wrong types, duplicate/dangling/cyclic identities, unordered resource
access, invalid rates/counts, unsafe integer/channel/control bounds, incomplete
coverage, source-link drift and false execution/qualification claims. Independent
checks derive27 reference records,108 default phase calls, position/velocity
bounds2165760/4160 and771 nested tasks. These are offline design checks; the
Runtime golden scenario is not implemented and no performance result is claimed.

Validation: focused22 PASS, complete contract PASS, explicit quick66/66 PASS,
full portable66/66 and strict70/70 PASS (verify-full-20260929T000536Z.log). Existing hosted compilers,
sanitisers, determinism, package/archive/manual consumers, ABI, release and
portable-assurance gates passed. Only16 scoped specification/tooling/governance
files changed; production/C++/SDK/ABI/install behavior, previous samples and
all earlier evidence are preserved. The first full run passed portable66 but
strict69/70 after the unchanged simcore_all hit its300s timeout at the eight-thread
SimCore determinism case. That exact case reran1/1 in3.104s, then the complete
full profiles passed without source/assertion/timeout changes. Original logs
cpp-m26-01-full-timeout.log and cpp-m26-01-strict-timeout-ctest.log are retained;
a passing rerun establishes no timeout root cause. No gate was waived.
See target `docs/evidence/M26-01-2026-09-28.md` and PR275 for exact commands,
results, remaining implementation risks and rollback.

Canonical plan [PR544](https://github.com/tranquilWorks/portfolio-control/pull/544)
merged at3850342958f8daa9607c9ba2e5f82e49efbe40d6, batch blob
acd6b1b1589de95a638f91fe41866125243c4d40. Initial plan validation required the
quick command to be named explicitly; corrected full local control validation
passed. Plan run36499584958/job109187000823 completed failure with steps=[] and
was recorded UNPERFORMED under the standing control-only exception. The original
local failure is retained; neither local functional nor target gates are waived.

Remaining software scopes, to plan separately: M26-02 portable multi-entity CIL
implementation; M26-03 CUDA physics; M26-04 XDMA HAL loopback; M26-05 benchmark/
fault/control showcase; M26-06 living documentation and feature-completion audit.
This closure activates none of them and does not claim CAP-M26 completion.
M25 independent unfamiliar-consumer acceptance remains UNPERFORMED. Physical
CUDA/XDMA/HIL, RT1/RT2, controlled performance, Unreal and signing/release/
deployment remain separate gates. Actual scenario finalization, memory accounting,
zero allocation, package execution and fault/replay evidence belong to later batches.

Control closure full local validation and exact-head hosted disposition are
recorded in its PR. Standing scoped publication/integration authority and the
control-only completed zero-step exception persist; no target gate exception.

## Historical M26-01 planning and M25 completion

# M26-01 golden scenario contract selected

The owner requested M26-01. Merge [the bounded plan](batches/M26-01.yaml)
before target activation from M25-06 main62e61474c2d2efa6d673a9db31c45e2f35974ada.
Freeze a checked scenario/lever contract only; M26-02 through M26-06 remain
unactivated. M25 software is complete and its independent human acceptance
remains UNPERFORMED. Preserve all32 exact-head target gates and prior evidence.
Standing scoped integration authority and the control-only completed zero-step
infrastructure exception persist, with full local control validation required.

## Previous completion record

# M25 software delivery complete; human acceptance remains open

M25-06 target [PR274](https://github.com/tranquilWorks/cpp-rt-car/pull/274) merged at
`62e61474c2d2efa6d673a9db31c45e2f35974ada`. Exact tested head `fc7eb1053b415c48adf8669698dbba80a32869a8` and
fetched merged tree `8cf60032bb9be84850438854300f84ad065b3fb8` match. All32 exact-head
hosted records passed with the predecessor's exact names/multiplicity, including
both scaling-smoke records. Main CI36495513386 and docs36495513387 passed.
Expected-head/base, clean-worktree, review-thread and fetched-tree guards passed.
No target gate was waived.

The installed offline manual contains55 reproducible files: source-linked API
reference for all20 default and three explicitly optional headers, selected
entry-point declarations with exact line anchors, complete source/comments,
authoritative guides and executable recipe commands. Ordinary SDK builds require
no documentation generator. Local files/fragments and exact archive bytes are
checked; repository-only HTTPS links and conditional hardware instructions remain
explicit. Private/detail declarations visible in headers are not new public API.

Recipes reuse unchanged public C/C++/profile/mixed-rate/sampled-I/O/live-control/
replay/device-boundary/benchmark consumer and support sources. The default suite
has10 checks; optional benchmarks add one. CUDA/XDMA boundary recipes only execute
version checks and compile guarded driver surfaces; actual portable workloads
remain in the unchanged earlier kits. No production/header/export/ABI, earlier
source/oracle or evidence binding changed.

Validation: portable66/66 and strict experimental/RapidCheck70/70 passed
(verify-full-20260928T230659Z.log). Actual default CPack archive passed recipes10/SDK36/embedding10;
optional benchmark archive passed11/41/11. Original prefixes were removed, custom
include/data paths and spaces exercised, and exact inventory/bytes/local links
verified. Four archive negative controls detected missing manual/support files,
false expected counts and missing support during a real build. Seven generator/
link/transcript negatives, contract, compiled ABI and unchanged CUDA matrix passed.
Existing CUDA relocated11/embedded11 consumers and four artifact validations also
passed. ABI remains v8/SONAME8/70exports/fingerprint0xd0e7a5a14bf35f97/device v1;
CUDA matrix remains40/44 portable,37/37critical and four physical NOT RUN.

Canonical plan [PR541](https://github.com/tranquilWorks/portfolio-control/pull/541)
merged atd385731eb44762e73596e830d4f99a8534bc5bf5, batch blob
ac12e901ec4c12d945d83beda7535d5e84defc22. Evidence is
`docs/evidence/M25-06-2026-09-28.md`; final results/head/check identities are in
PR274 and this closure. Plan full local validation passed; hosted plan
run36493640155/job109167986563 completed failure with steps=[] and was recorded
UNPERFORMED under the standing control-only infrastructure exception.

Retained verifier failures: forcing ZIP on Linux and using shutil extraction
flattened library symlinks, failing three of36 C SDK checks. The verifier now
uses the configured platform CPack format and existing release extractor. The
next run passed default10/36/10 and optional11/41 but reused a default embedding
build directory for a different extracted source path; CMake correctly rejected
that configure. Separate clean embedding directories fixed the verifier. Both
raw logs are retained; all final archive suites passed without changing library,
consumer oracle or cache guards. Superseded initial hosted runs were cancelled
to free runners for the final head. Explicit UTF-8 generation avoids locale drift.

All six M25 software batches are delivered. The unfamiliar-consumer first-use
walkthrough remains **UNPERFORMED**, so overall human acceptance remains open;
the roadmap retains that distinction. No M25 software batch remains. The next
software scope to plan separately is M26-01 golden scenario/lever contract,
followed by five further M26 full-system composition/audit batches. This closure
does not activate M26. Physical CUDA/XDMA/HIL, RT1/RT2, controlled performance,
Unreal and signing/release/deployment remain separate.

Control closure full local validation and hosted disposition are recorded in its
PR. The standing control-only zero-executed-step exception never waives local
validation or any target gate. Standing scoped integration authority persists.

## Historical M25-06 planning and M25-05 completion

# M25-06 installed documentation selected

The owner requested M25-06. Merge [its bounded plan](batches/M25-06.yaml) before
target activation from M25-05 main98ecca5a6572dd83d59e26063716f6d76b7a5d4f.
Deliver generated source-linked API reference, offline guides and executable
installed/embedded public-SDK recipes in actual release archives. Preserve
production, SDK/ABI and prior evidence. All32 target gates remain required.
Standing scoped publication/integration and control-only zero-step exception
persist, with full local control validation. Close M25 software only; unfamiliar
human first-use acceptance remains UNPERFORMED. Do not activate M26.

## Previous completion record

# M25-05 complete; M25-06 next to plan

Target [PR273](https://github.com/tranquilWorks/cpp-rt-car/pull/273) merged at
`98ecca5a6572dd83d59e26063716f6d76b7a5d4f`. Exact tested head: `d134d828823a700bb7f9ba5701027c7e08075a3f`;
tested and fetched merged tree: `34d5a23796849187f361084ccab7f43990387d55`. All32
exact-head hosted records passed with the predecessor's exact name/multiplicity,
including both scaling-smoke records. Main CI36484855632 and docs36484855493
passed. Review/expected-base/head guards, expected-head squash merge and fetched
tree equality passed. No target gate was waived.

The optional six-file installed source kit demonstrates an independent headless
host: fixed32-slot copied jobs, two host workers plus frame-thread cooperative
help, three fixed memory regions per instance with actual startup OS residency
observation, a monotonic host clock/frame loop, two public Runtime instances,
bounded telemetry and checked stop/detach. Native and host-adapter modes run the
same nested graph with independent per-element/frame oracles, exact checksums
2176/6528 and balanced ownership. No compiled production, SDK header/target,
ABI, prior source-kit or capability/evidence binding is changed.

Final local portable56/56 and strict experimental/RapidCheck60/60 passed
(verify-full-20260928T211516Z.log). Corrected-source standalone2/2, full SDK26/26,
embedding2/2, examples-ON coexistence, exact inventory/bytes/path isolation and
four package negative controls passed. Focused ASan/UBSan/leaks3/3, TSan3/3,
Clang14 analysis, allocation/concurrency/lifecycle/telemetry tests, compiled ABI,
contract and unchanged CUDA capability checks passed. Existing CUDA consumers
11+11 and four artifact validations passed again on corrected source. ABI remains
v8/SONAME8/70exports/fingerprint0xd0e7a5a14bf35f97, device ABIv1; matrix coverage
remains40/44 portable,37/37critical and four physical NOT RUN.

Canonical plan: control [PR535](https://github.com/tranquilWorks/portfolio-control/pull/535),
revision `2808734c34b7189aef41630ab9fcf6f0b79d958a`, blob
`957f0e507493768ef17ab26d90bf48b5f13cd9ea`. Target evidence:
`docs/evidence/M25-05-2026-09-28.md`, with final results and retained failure in
PR273. Final contract log:verify-contract-20260928T211514Z.log.

Retained failure: initial head79daf05c46a49121772e8531ad07aa47bf603c57 failed
MSVC benchmark SDK run36481744946/job109128795844 with C4324 implicit alignment
padding treated as an error. Explicit tail padding plus size/alignment assertions
preserve the exact69632-byte slot stride and4096 alignment; no warning, assertion
or production policy was weakened. The failed job log is retained. Superseded
initial CI/docs runs were cancelled after this failure was captured, freeing
runners for the corrected head; only corrected-head all32 records count. The
preliminary local full run passed but overlapped the edit, so the final full and
package suites were freshly rerun on unchanged corrected source.

Retained intermediate-head failures: TSan run36482471278/job109131204999
selected three new host tests without building their binaries; the other37
selected entries passed and no race diagnostic was reported. Test-only CMake
dependencies now build both new executables through the existing targeted
rtfw_host_adapter_tests build, verified in a fresh TSan build with all4 host tests
passing. The same run's Windows RelWithDebInfo job109131204562 observed0 elapsed
in unchanged BenchmarkRunner.RealClockIsCharacterizationOnly (expected>0).
Its host tests passed. Both raw failed logs are retained; no benchmark assertion,
main workflow, production source or test-selection rule changed. The full final
Windows and TSan jobs passed as part of the exact-head32 check inventory.

Next: **M25-06 installed API reference, docs and recipes**, separately planned
and canonically integrated before implementation. M25 has5/6 software batches
complete; this closure activates no later batch. Six M26 full-system reference/
audit batches remain. Independent novice review, physical CUDA/XDMA/HIL, RT1/RT2,
controlled performance, Unreal and signing/release/deployment remain separate.
Residency readback is a snapshot, not locking/RT qualification. The provider
covers three resident regions, not all Runtime/host allocations. Failed cleanup
retains borrowed owners for explicit retry; arbitrary nonreturning host callbacks
cannot be made safe by forced release. Standing scoped integration authority persists.

Control closure full local validation and hosted disposition are recorded in its
PR. The standing control-only completed-failure-with-zero-steps exception never
waives target gates or local control validation.

## Historical M25-05 planning and M25-04 completion

# M25-05 independent host selected

The owner requested lets do 05. Merge [M25-05](batches/M25-05.yaml) before
target activation from merged M25-04 main2c431a40f450aba06b721dd0929f467fd12652b4.
Deliver the optional source-only headless host with fixed jobs and memory provider,
monotonic clock, explicit frame loop, multiple Runtime instances, telemetry and
checked stop/detach. Exercise native and host-adapter modes using public artifacts.
Preserve production/SDK/ABI and all earlier source/evidence bindings. All32 target
checks remain required. Standing scoped publication/integration and the control-
only zero-step infrastructure exception persist, with full local control validation.
Do not activate M25-06; Unreal and qualification/release gates stay separate.

## Previous completion record

# M25-04 complete; M25-05 next to plan

Target [PR272](https://github.com/tranquilWorks/cpp-rt-car/pull/272) merged at
`2c431a40f450aba06b721dd0929f467fd12652b4`. Exact tested head: `69c07aebd5b5f2c3e37e502162ed15fd4163c9ba`;
tested and fetched merged tree: `281104170c3ae76da03f3d8b424f0184e0d0f1f1`. All32
exact-head check records passed with the predecessor's exact name/multiplicity
inventory, including both scaling-smoke records. Main CI36459935963 and
docs36459935906 passed. Review/expected-base guards, expected-head squash merge
and fetched-tree equality passed. No target gate waiver.

The optional source-only kit connects actual separate controller and public
Runtime plant processes. It defines an exact96-byte wire and4096-byte region,
bounded one-record SPSC channels, host-issued timestamps/expiry, exact sequence/
correlation/generation checks, hold/no-apply failure policy and checked mapping
ownership/shutdown. Reconnect uses a fresh name/map/generation; old mapped peers
cannot access the new session. Eight feedback commands independently produce
positions128,192,224,240,248,252,254,255. The self-contained source kit and guide
install without changing mandatory Runtime/SDK targets, public headers or ABI.

Local portable53/53 and strict experimental/RapidCheck57/57 passed on the final
unchanged-source full rerun (verify-full-20260928T174326Z.log). Relocated testsOFF
SDK24/24, standalone1/1 and embedding1/1, examples-ON coexistence, exact inventory/
bytes/path isolation and four package negative controls passed. Focused ASan/
UBSan/leaks2/2, same-process TSan1/1, Clang14 analysis, allocation guards, concurrent
payload conservation, fake-clock Runtime negatives and actual process fault/
reconnect/isolation tests passed. Existing CUDA consumers11+11 and four artifact
validations passed. Compiled ABI v8/SONAME8/70exports/fingerprint0xd0e7a5a14bf35f97,
device ABIv1 and all prior sources/evidence remain unchanged. Capability coverage
remains40/44 portable,37/37critical and four physical NOT RUN.

Canonical plan: control [PR530](https://github.com/tranquilWorks/portfolio-control/pull/530),
revision `6927945598352edb25ec27759f6fd633a3b6f4de`, blob
`e0e7d67c81ca110f18762425402899273311403a`. Target evidence:
`docs/evidence/M25-04-2026-09-28.md`; final results and retained failures are also
recorded in target PR272. Contract log:verify-contract-20260928T174019Z.log.

Retained failures: initial invalid default callback-context construction was
replaced with actual Runtime execution; initial TSan selector ran zero tests,
then the exact-name --no-tests=error run passed. The first strict run failed
unchanged experimental BinaryTrace chunk-marker and PredictiveAdaptive timing
assertions while package builds were concurrent (medians148vs136/net143vs132).
The full unchanged-source rerun after those builds ended passed, including both
actual assertions. Cause is not established; no production/test assertion was
changed and the failures remain in PR272/local logs. No target gate was waived.

Next: **M25-05 independent host adapter**, separately planned and canonically
integrated before implementation. This closure activates no later batch. M25 has
4/6 software batches complete; M25-05 and M25-06 installed API/docs/recipes remain.
M26 has six full-system reference/audit batches. Independent novice first use,
physical HIL/CUDA/XDMA, RT1/RT2, controlled performance, Unreal and signing/release/
deployment remain separate. Trusted local peers only; no authentication, universal
network/safety/RT claim. TSan does not prove cross-process race freedom. A killed
Linux creator may leave an exact-session orphan name; no crash daemon is provided.
Standing scoped publication/integration authority persists.

Control closure full local validation and hosted disposition are recorded in its
PR. The standing control-only completed-failure-with-zero-steps exception never
waives target gates or local control validation.

## Historical M25-04 planning and M25-03 completion

# M25-04 external CIL selected

The owner requested 04 lets go. Merge [M25-04](batches/M25-04.yaml) before
target activation from merged M25-03 main315b04b25dd41acbd3a21313a093cf90b19c95ac.
Deliver the optional source-only shared-memory transport and actual separate
controller/Runtime plant, with fixed wire/storage, timestamps, expiry, generation,
reconnect and checked shutdown. Preserve all production, SDK inventory and prior
source/evidence bindings. All32 target checks remain required. Standing scoped
publication/integration and the control-only zero-step infrastructure exception
persist, with full local control validation mandatory. Do not activate M25-05.

## Previous completion record

# M25-03 complete; M25-04 next to plan

Target [PR271](https://github.com/tranquilWorks/cpp-rt-car/pull/271) merged at
`315b04b25dd41acbd3a21313a093cf90b19c95ac`. Exact tested head: `99a526cf6f18d5d891dea9a776f3eec53e5369ff`;
tested and fetched merged tree: `9ef0cee658daf2d56b8c17500debaa80a26ccaa9`. All32
exact-head check records passed with the predecessor's full name/multiplicity
inventory, including both scaling-smoke records. Main CI36446957516 and
docs36446957520 passed. No unresolved review threads; expected-head squash merge
and exact fetched-tree equality verified. No target gate waiver.

M25-03 ships a source-only fixed-storage HAL-v2 core copy backend, reusable
framework-free bounded conformance with caller-owned storage and explicit cleanup
retry, native-v2 plus adapted-device-ABI-v1 Runtime integration, and a complete
installed authoring guide. The source kit installs in the data examples directory;
public SDK headers/targets, compiled Runtime/backends, raw/typed/CUDA sources,
ABI v8/SONAME8/70exports/fingerprint0xd0e7a5a14bf35f97 and device ABIv1 remain unchanged.

Final local portable51/51, strict experimental/RapidCheck55/55, SDK23/23,
standalone1+embedded1, examples-on coexistence and four package negative controls
passed. Focused ASan/UBSan/leaks2 tests repeated10 times, TSan2, Clang14, compiled
ABI, contract and unchanged capability matrix passed. Tests include ten independent
malformed-backend controls, bounded registry/queue validation,10,000 concurrent
completions,128 cancel/poll races, full256-byte copy boundary, stale generations,
zero steady-state allocation, actual Runtime failure/stop retry and instance
isolation. Existing CUDA source kits11+11 and four artifact validations passed.
Capability coverage remains40/44(90.91percent) and37/37critical, with four physical
M18 rows NOT RUN. All previous source/evidence/matrix bindings remain unchanged.

Canonical plan: control [PR527](https://github.com/tranquilWorks/portfolio-control/pull/527),
revision `7585342836adf7d5e90cd62acb8d4237dc802f22`, blob
`d65ec3071611b480748f3a92eca937160a5ea8d7`.
Target evidence: `docs/evidence/M25-03-2026-09-28.md`; final local full log
`verify-full-20260928T154944Z.log`, contract `verify-contract-20260928T155230Z.log`.
Retained failures: initial missing two-backend capacity in the example; initial
ASan fixture completion-count failure without a memory diagnostic; temporary
negative-control wrong-library link. A delayed-producer old-schedule control
reproduced finite polling-budget exhaustion. Yielding on empty/full fixture polls
preserves10,000 commands, exact oracles and finite budget; final sanitizers passed.
The original schedule remains unknown. Review also corrected cleanup token
retention and unexpected extra-registration ownership before publication.

Next: **M25-04 external CIL shared-memory reference**, separately planned and
canonically integrated before implementation. This closure activates no later
batch. M25 remains active with3/6software batches complete and three remaining:
external shared-memory CIL, independent host adapter, and full installed API/docs/
recipes. M26 has six full-system reference/audit batches. Independent novice
review, physical/RT qualification, controlled performance, Unreal and signing/
release/deployment remain separate. Standing scoped publication/integration
authorization persists.

Control closure full local validation and hosted disposition are recorded in its
scoped PR. The control-only zero-executed-step infrastructure exception retains
hosted failure as UNPERFORMED and requires full local control validation; it never
waives functional failures or any target check. The roadmap's active-batch cursor
now names the latest completed M25-03 contract; M25-04 is only the next-to-plan item.

## Historical selection and previous completion records

# M25-03 backend authoring selected

The owner requested 03 now. Integrate [M25-03](batches/M25-03.yaml) before
target activation from M25-02 main e562ab164162b67d009171b5c8f53e9b04866285.
Deliver the source-only fixed-storage HAL-v2 template, reusable bounded conformance,
actual Runtime consumer and installed authoring guide. Preserve all production,
public SDK inventory and predecessor evidence/matrix bindings. All32 target checks
remain required. Standing scoped publication/integration and the control-only
zero-step infrastructure exception persist; full local control validation remains
mandatory. Do not activate M25-04.

## Previous completion record

# M25-02 complete; M25-03 next to plan

Target [PR270](https://github.com/tranquilWorks/cpp-rt-car/pull/270) merged at
`e562ab164162b67d009171b5c8f53e9b04866285`. Exact tested head:
`e3dcc7e6132aed805a7a810ee7b7ae74bb8d44fa`; tested and fetched merged tree:
`e2dc960d402881623a8369099f71a22c440cc226`. All32 exact-head check records
passed with the predecessor's full name/multiplicity inventory, including both
scaling-smoke checks. Main CI36437896423 and docs36437896116 passed. No unresolved
review threads; expected-head squash merge and exact fetched-tree equality verified.

M25-02 adds optional public `rt/sdk.hpp`: noexcept typed free/member callbacks,
raw-validated config/graph builders, checked partial storage arithmetic,
non-owning checked-stop guards with explicit retry and fail-closed destructor,
and fixed-buffer actionable diagnostics. Typed source/CMake/output kit and guide
ship in the SDK. Existing raw APIs, raw hello, compiled production/backends,
ABI v8/SONAME8/70exports/fingerprint0xd0e7a5a14bf35f97 and device ABIv1 are unchanged.

Local portable49/49, strict experimental/RapidCheck53/53, SDK22/22, typed source
consumers1+1, examples-on embedding and seven negative controls passed. ASan/UBSan
with leak detection3/3, TSan3/3, Clang14, compiled ABI and final contract passed.
Tests cover all82 MemoryPlan fields, raw/helper failure statuses, graph and
capacity errors, overflow, every diagnostic truncation size, actual cleanup
failure/retry, isolated destructor termination, zero steady-state allocations
and concurrent independent Runtime instances. Existing CUDA source kits11+11
and four artifact validations passed. Capability coverage remains40/44(90.91%)
and37/37critical; four physical M18 rows remain NOT RUN. The matrix adds the new
header/package binding and fresh revalidation while preserving all prior
product-source/evidence hashes, rows, gates, checker and historical evidence.

Canonical plan: control [PR524](https://github.com/tranquilWorks/portfolio-control/pull/524)
at `ad159304c00151e248ffe2b7f5699c341a8b5361`,
blob `d598ea817902036ebdf85cb1407e6cb78043ca08`.
Target evidence: `docs/evidence/M25-02-2026-09-28.md` and
`docs/evidence/M25-02-cuda-revalidation.md`.
Retained failures include incorrect private raw-status/message expectations,
initial stale sanitizer CMake targets, and GCC12 sanitized constexpr member-
pointer comparison. All were corrected and reverified without weakening gates.
Initial Git push received a remote Internal Server Error; an ordinary retry
published the unchanged final commit. No functional or target CI waiver.

Next: **M25-03 backend authoring kit and conformance**, separately planned and
canonically integrated before implementation. This closure activates no later
batch. M25 remains active with2/6software batches complete and four remaining:
backend kit, external shared-memory CIL, independent host adapter and full
installed API/docs/recipes. M26 has six full-system reference/audit batches.
Independent novice review, physical/RT qualification, controlled performance,
Unreal and signing/release/deployment remain separate. Standing scoped
publication/integration authorization persists.

Control closure full local validation and hosted disposition are recorded in
its scoped PR. The standing control-only exception requires full local checks
and preserves a hosted zero-executed-step infrastructure failure as UNPERFORMED;
it never waives functional failures or any target gate.

## Historical selection and previous completion records

# M25-02 typed SDK selected

Owner requested m252. Merge [M25-02](batches/M25-02.yaml) before target activation
from M25-01 main d3052a0f7f17a0cd68334123aea3869fcae2094a. Deliver optional
typed callbacks, raw-validated builders, checked capacities, fail-closed checked
stop and fixed diagnostics with shipped consumers. Preserve compiled production
implementation and all prior evidence. Revalidate additive SDK inventory and
CUDA capability bindings. All32 target gates remain required. Standing scoped
publication/integration and control-only zero-step infrastructure exception apply;
full local control validation remains mandatory. Do not activate M25-03.

## Previous completion record

# M25-01 complete; M25-02 next to plan

Target [PR269](https://github.com/tranquilWorks/cpp-rt-car/pull/269) merged at
`d3052a0f7f17a0cd68334123aea3869fcae2094a`. Exact tested head:
`3b900b2d03a8437f393866a0bcf228993b7e65a5`; tested and fetched merged tree:
`5e924721217b978c59bd56308feef6c7d5d49291`. All32 exact-head check records
passed with the predecessor's complete name/multiplicity inventory. Main
CI36372921165 succeeded; no unresolved review threads. The expected-head
squash merge and fetched-main tree equality were verified.

M25-01 ships the 57-line raw public hello graph, install/find-package and
add-subdirectory paths, source kit and self-contained first-use guide, exact
commands/output/troubleshooting, relocated consumers and legacy notices.
Quick 46/46, strict full 50/50, SDK 21/21, source consumers1+1 and five negative
controls, ASan/UBSan 3/3 with leaks and TSan 3/3, static, ABI and exact README
transcripts passed. Existing CUDA source consumers 11+11 and four benchmark
artifact checks passed again. The optional examples-on embedding mode builds
both distinct hello targets. All Runtime/backend/ABI/M23/M24 source and
evidence bindings remain unchanged; M24 coverage stays 90.91% overall
and 100% critical, with four physical NOT RUN rows.

Canonical M25-01 plan: control PR520 at
`d1512a06be447fb275c625ca51b7d67a854b4bed`,
blob`462f1f1ab2915ff833905e45be317cb5a484c438`.
Retained target evidence: `docs/evidence/M25-01-2026-09-28.md`.
It includes the corrected relocation-harness location and strict private
failure-fixture warning, plus the original failed runs. One later GitHub status
API request failed; an alternate query recovered, and all final checks were
verified. No test result was waived.

Next software batch: **M25-02 typed builders, RAII and diagnostics**. Plan and
integrate its separate canonical contract before implementation. This closure
does not activate it. M25 remains active with five software batches left:
typed helpers, backend authoring/conformance, external shared-memory CIL,
independent host adapter and full installed API/docs/recipes. M26 has six
full-system reference/audit batches. Independent novice review, physical/RT
qualification, controlled performance, Unreal and signing/release/deployment
remain separate. Standing scoped publication/integration authorization persists.

Control closure's full local validation passed 252 shared tests (one retained
missing-source skip), 6+33+15 product tests and schema/ShellCheck; final metadata
is revalidated before publication. Hosted zero-step failures remain UNPERFORMED
under the existing control-only exception, never a target gate waiver. The
closure PR records its exact hosted result and merge disposition.

## Historical activation and M24 record

# M25-01 consumer onboarding selected

The owner requested M25 batch1. Integrate [M25-01](batches/M25-01.yaml) before
target activation from main facc42d4a09d1dab398d75dc92000a05fb08c396. Implement
only the hello/install/embedding/legacy separation scope, verify all32 exact-head
target gates and integrate under standing authorization. M25-02 is not activated.
Preserve all Runtime, benchmark and M24 evidence/coverage bindings unchanged.
Control hosted zero-step infrastructure failures retain the standing exception:
full local validation is mandatory; hosted validation stays UNPERFORMED.

## Previous M24 completion record

# M24 portable software complete; M25-01 next to plan

Target [PR #268](https://github.com/tranquilWorks/cpp-rt-car/pull/268) merged at
`facc42d4a09d1dab398d75dc92000a05fb08c396`. Exact tested head:
`0debe778c8d693e37afb753fde955779c9615851`; tested and fetched merged tree:
`beaca4687f9ea441bbbb5800f76bf421141dae9c`. All32 check records passed and the
full check-name/multiplicity inventory matched M24-03. CI36360935668 passed;
its final Clang Debug/FMA suite passed63/63. No unresolved review threads;
expected-head squash merge and tree equality were verified. Target worktree clean.

M24-01/02/03, CUDA cleanup repair266 and Runtime ownership race repair267 remain
protected. M24-04 adds20 optional M23 particle cases, fixed host correlations,
installed consumers and the evidence/source-bound capability gate. All207 prior
M23 cases and production Runtime/backend/model source remain unchanged.
Coverage40/44 (90.91percent) and37/37 critical closes portable M24/CAP-M24 only.

Local evidence: quick43/full47, strict portable59, ASan/UBSan11 and TSan11 plus
final capacity checks, matrix10negative controls, source consumers11+11 plus
four bundle validations, default SDK20, ABI/static/real compile/help/stub checks.
See target `docs/evidence/M24-04-2026-09-27.md`, retained measurement bundles and
PR268 for exact commands, identities, original failures and final hosted evidence.
Initial SDK verification used a tests-enabled build and was correctly rejected;
a clean tests-disabled SDK passed. Windows inventory used native separators;
canonical POSIX paths plus an independent regression fixed it. No gate was waived.

The four physical rows stay in the overall denominator as M18 NOT RUN. Actual
NVIDIA correctness/recovery, GPU profiling/controlled performance, thermal and
endurance, RT1/RT2, independent human review and signing/release/deployment remain
unperformed separate gates. Portable host timings do not select a GPU optimization.

Next: plan M25-01 consumer installation and hello Runtime under its own canonical
contract when continuing. M25 has six SDK/consumer batches; M26 has six full-system
reference/audit batches. This closure update activates no M25 implementation.
Standing scoped publication/integration and API-failure continuation authority
persists, without changing the software/physical or functional-gate boundaries.

## Historical M24-04 activation

# M24-04 CUDA benchmark and maturity closure

M24-03 is merged as target #265 at `74e59e8850ccb24d71a0fdbedfe4305971e773df`
with all32 exact-head checks passing. Activate [M24-04](batches/M24-04.yaml) only
after this canonical contract integrates. Preserve all prior providers, Runtime,
CUDA samples and lifetime repairs. Add optional M23 provider/correlation sources,
installed consumers, measured comparison and the all-row capability gate.
Standing scoped publication/integration and API-failure continuation authority
persists. Retain unavailable control jobs as UNPERFORMED under the existing
zero-step infrastructure exception; no functional or target CI gate is waived.
M25/M26 and physical/manual/signing/release gates remain separate.

## Historical M24-03 checkpoint

# M24-03 reactivation after merged Runtime race repair

R2 target #267 merged at `27fcb90b49773196f8773c2edcf97ba746fa7f94`, tree
`59442fa32a4b76ad403f6d5d9937b5947278fcf1`, after all 32 exact-head checks
passed at `c14a7420627cb8f0ef251ab8ba2381abd9ee5686` in CI36351132581.
Local full quick39/experimental43, portable39, sanitizer91+6 each, source5+5,
SDK20, ABI/static pass. Old-source TSan regression reproduces the defect.
Preserved feature0fb7cb1 passes TSan512KiB and ASan/leak/zero-allocation against
this Runtime. Original CUDA cleanup #266 stays protected.

Integrate this canonical reactivation, reconcile feature #265 with the merged
repair and finish fresh combined gates. Configure concurrent fixtures on the
control thread, observe both accepted workloads and isolate injected loss;
retain512KiB CLI bound and every original failure/publication/cleanup oracle.
Do not alter Runtime, backends, original tests or repair evidence. Then report
remaining M24-04, M25/M26 and manual/hardware work. Standing scoped publication/
integration and API-failure continuation authority persists.

## Historical R2 planning checkpoint

# M24-03R2 active retirement race repair

Feature #265 at042bb7c passed focused3/3 and ASan/leak9/9, but TSan fails
both executable lifetime gates: host release_rate_batch writes rate_owned while
service_loop reads it during active submit failure. Preserve the draft and log
`/tmp/cpp-m24-03-final-tsan.log`. Plan/verify/integrate the private bounded
[M24-03R2 repair](batches/M24-03R2.yaml) separately on #266 main, then canonically
reactivate M24-03. No sanitizer suppression, test removal or timeout relaxation.
Standing scoped publication/integration authority persists; physical/manual gates
remain unperformed. Earlier checkpoints below are historical.

# M24-03 reactivation after combined repair

Combined repair #266 merged at `ff47a64883e73cd9c2984616249b302e413566dc`,
tree `a39e10cd27e95075641afd9ef27b17a26183d023`, after all32 exact-head checks
passed at `b290fa55415ce92f7a7844c869d389813883183a` in CI36348539120.
Fresh local focused63/63, quick39/full43, portable39, ASan/leak and TSan63+6,
source5+5/SDK20, ABI/static pass. Integrate this canonical amendment before
activation. Preserve feature #265 at `dede9ea` and all prior failures.

Reconcile the feature with both CUDA cleanup fixes, then finish every M24-03
criterion. Ordinary stop returns cancellation; active noncancelable work retains
ownership to its unchanged finite completion budget and reports timeout. Stale
completion is a terminal protocol error. Keep strict no-publication, resource,
allocation and leak oracles. All prior tests, repair source/evidence, Runtime,
ABIs and benchmark inventories remain protected. Complete local/hosted gates,
merge the bounded feature, then report remaining M24-04 and wider M25/M26/manual
work. Standing publication/merge and API-failure continuation authority persists.

## Historical repair amendment

# M24-03R registration rollback amendment

Preserved feature #265 linked against target repair #266 at `20bc90e` now passes
pending cleanup, then exposes native staged-registration rollback failure:
Runtime marks ownership uncertain before registration; a failed callback leaves
zero token, but CUDA unregister rejects it. No registered host spans remain in
the observed simple failure, yet two events stay owned and stop cannot finish.
`/tmp/cpp-m24-03r-preserved-state.log` retains GDB evidence. This is a second
concrete production defect, not a relaxed test.

Amend the same separately scoped CUDA implementation/test repair to validate
and clean an exact descriptor with zero token, preserve any residual resource
on failure, and acknowledge no surviving registration. Nonzero-token mismatch,
malformed descriptors and unrelated buffers must still reject/remain intact.
No Runtime manager or public ABI changes. Integrate this amendment before
editing repair source; preserve all earlier tests and exact-head results.
Then verify the final combined repair, integrate #266, reactivate #265 and
complete the requested M24-03. M24-04 and physical/manual gates remain separate.

## Historical stopped-retirement activation

# M24-03R repair checkpoint

M24-03 feature draft `dede9ea` reproduces a production CUDA ownership cycle:
a canceled Runtime step leaves CUDA slots pending; unregister rejects live
references; Runtime skips shutdown while buffers remain; subsequent stop retries
cannot retire them. Retained target log `/tmp/cpp-m24-03-pending.log` reports
invalid_state, no synchronization and live resources. No assertion is waived.

Integrate [M24-03R](batches/M24-03R.yaml) and repair only the CUDA implementation
plus regressions against target M24-02 main. Explicit command stop permits checked
host-side retirement before unregister, with exact retention/retry on failed sync.
Then integrate, amend/reactivate M24-03 against the new baseline and finish its
preserved draft. Standing scoped repair/publication authorization persists.
M24-04, physical/manual gates, M25/M26 remain separate; report remaining work to
owner after the requested next feature batch is actually complete.

## Historical M24-03 activation

# Codex handoff — M24-03 CUDA lifetime conformance

M24-02 merged as target PR #264 at `5c82703d0c2840d13e18770d2d1b3083a96e29c0`,
tree `dd6b80567308ab4285313d5e0bf02a9fc6469f53`, with all 32 hosted checks passing
at `098f04a8065ded657b2de0ac0cc3faf8f8581be1` (CI 36329436486). Local quick 39/39,
full 43/43, both sanitizers, source/SDK consumers and actual CUDA compile pass.
Physical CUDA remains NOT RUN; preserve earlier timeout and stack evidence.

The owner explicitly requested the next batch, then an update on remaining work.
Integrate [M24-03](batches/M24-03.yaml) before target activation. Add a finite
installed conformance runner proving failure, stale completion, quarantine/reset,
permanent loss, cleanup retry and isolated instances through the actual Runtime
pipeline. CUDA cancellation is unsupported and lost contexts cannot reset in
place: test these boundaries explicitly. Integer correctness remains exact;
nonzero floating-point tolerance is inapplicable to this unchanged integer model.
Keep all previous tests and production source protected; plan any repair separately.
M24-04 and CAP-M24 coverage closure remain separate. Standing scoped publication/
integration and API-failure continuation authorization persist. No hardware,
Unreal, cybersecurity, Daybreak, signing, release or deployment scope is added.

## Historical M24-02 planning handoff

# Codex handoff — M24-02 CUDA pipeline

M24-01 merged as [target PR #263](https://github.com/tranquilWorks/cpp-rt-car/pull/263)
at `c64d0672f1478acd863c68865663550d7fe22f8c`, tree
`203745628086435d656fdd9dcba9178bf0f4ac39`. All 32 hosted check records passed
at `e5b0daa9e65850e6ff3ec69f78bed8ff7713cfb3`, CI run `36293297075`.
Local portable 36/36, focused sanitizer, installed consumer and ABI checks
passed. The experimental local suite finished 39/40 with the unchanged
simcore_all eight-thread timeout; preserve this and the unqualified embedded
512 KiB Debug/TSan stack diagnostic. Physical CUDA remains NOT RUN.

The owner requested continuing into M24. The next bounded scope is
[batches/M24-02.yaml](batches/M24-02.yaml): two-stream caller-owned staging,
H2D/D2D/kernel-or-Graph/D2H, independent oracle parity, ordinary and actual
active-rate Runtime dispatch, installed portable/optional-real entry points.
Integrate this canonical planning contract before target activation. Runtime,
backends, original M24-01 model/entry points/tests and earlier evidence remain
protected. Use the installed public APIs, retain real failures and plan any
production repair separately. M24-03/04 and physical/maturity claims remain open.

Standing scoped publication/integration authorization persists. Work around
API failures; the existing unavailable-control-hosted-job exception requires
retained zero-step evidence and never waives functional failures. Do not ask
for repeated permission. The old dirty M20 worktree remains untouched.

## Historical M24-01 planning handoff

# Codex handoff — M24-01 Runtime CUDA particle reference

2026-09-27 continuation: control validation repair PR #501 merged at
`1713665398b4d570611e7e8e19195d25fb8b7b38`. The planning branch now includes
that main revision; the 36-error inventory below is historical. The owner
explicitly requested continued work around/ignoring API failures. Retain failed
API attempts as unavailable publication evidence, without treating them as
functional failures or stopping unblocked local work. Full control validation
passed: 252 control tests (one source-submodule skip), 54 product tests,
portfolio/schema checks and ShellCheck. Control PR #502 retains the hosted
job's pre-execution infrastructure failure (zero executed steps) separately.
The existing unavailable-control-job exception applies; no local functional
failure is waived. Activate the exact integrated canonical revision in target.

Audit date: 2026-09-26. Current target main is
`7e9fb883049df486f04a1d6730d36890cadc3853`, tree
`94568803fa38c85265bd09a1a3dd1fe57449a349`.
[M23-05 PR #261](https://github.com/tranquilWorks/cpp-rt-car/pull/261)
merged on 2026-09-25 after all 32 hosted checks passed on
`c70940445956e4fd493bbd88f26be1c89d0a880a` in
[CI run 36098191074](https://github.com/tranquilWorks/cpp-rt-car/actions/runs/36098191074).
The PR's final record supplies full local, installed/relocated package,
sanitizer and ABI results; earlier pending prose in target documents is
historical. Both Windows analysis entries passed with the unchanged 120-second
bound. Preserve all prior failures. M23 portable software is complete;
CAP-M23's controlled-host baseline/threshold review and physical characterization
remain unperformed.

The next software contract is [M24-01](batches/M24-01.yaml), planned against
that exact target. Read the [planning audit](evidence/M24-01-planning-2026-09-26.md).
This is a planning change until its canonical control PR is integrated. Bind
the integrated revision/blob when activating the target; its current M23-05
allowlist does not authorize particle implementation.

Planning validation: M24-01 schema/dependency/frontier checks pass. Full control
validation currently fails on existing contracts; a baseline comparison proves
the same 36 failures across all 604 pre-existing batches, with zero introduced
by this draft. See the retained inventory in the planning audit. Keep this
contract draft until the control validation/integration gate is resolved; no
target activation or software implementation pass has been claimed.
Separate control unit verification passed 249 tests with one skip (250 total),
and ShellCheck/diff checks passed. GitHub API became unreachable during final
publication preparation; inspect `agent/cpp-m24-01-plan` and remote state before
retrying publication. Do not mistake this local planning checkpoint for an
integrated canonical contract.
Planning commit `9597ba99cbe59c4d3434d5bde0b16a686cb6581e` is pushed to
`origin/agent/cpp-m24-01-plan`; draft PR creation failed with an API connection
error and is unconfirmed. Check for an existing PR by that exact head before
retrying. The prepared PR description is `/tmp/cpp-m24-plan-pr.md`.

Implement a fixed-capacity three-axis integer constant-acceleration particle
model, using the normal Runtime H2D/kernel/D2H graph and actual CUDA backend.
Validate each completed frame with an independent int64 closed-form CPU
oracle. Portable injected-driver and optional real-session hosts share the
graph, and the installed-source consumer must work after archive relocation.
Bounds, units, seed semantics, CLI exit codes, cleanup, negative controls and
all validation requirements are explicit in the contract. Preserve Runtime,
backend, ABI, original samples and all 207 benchmark cases. M24-02 through
M24-04 and all capability-maturity claims remain separate.

Continuation recovery: an older local worktree was still on `agent/m20-pre-01`
at `c846cc427c93018175a69c7372c130f00c0b713b`, with unpublished changes and
a full-suite timeout. The owner expressly said to ignore that timeout and
continue. Preserve those changes/results; do not publish that obsolete batch
over the already-merged M20-M23 source or use its test results for M24. A fresh
target worktree `cpp-rt-car-m24` on `agent/m24-01-continuation` was created from
current main; no target implementation has been changed during planning.
This exception is not a passing test result or a waiver of new functional gates.

Standing scoped software publication/integration authorization is recorded in
`automation.json` and the target's current `AGENTS.md`; do not ask the owner to
repeat it. Continue only exact-head eligible software work with required gates.
No cybersecurity, Daybreak or Unreal work, support promotion, signing, release
or deployment. Missing actual CUDA hardware stays NOT RUN.

## Historical M23-03 planning handoff

Audit date: 2026-09-07.

Target main is `795a56cabb78dd2c6ccf51796f54c4f6eff84f9f`, merged
[PR #253](https://github.com/tranquilWorks/cpp-rt-car/pull/253).
Its exact head `bcf4c1ab40061620763c74ef82af3e672bf76ce2` passed
[CI run 34086591685](https://github.com/tranquilWorks/cpp-rt-car/actions/runs/34086591685)
(27/27 jobs) and all four companion workflows. Local correction verification
passed 39/39 benchmark CTest and 37/37 official full-profile gates.
No unresolved review thread was present at integration; this is not a
separate human-review record.

M23-02 provider source merged as PR #252. Its old CLI discovery assertion
failed nine matrix jobs even though the repaired Windows SDK and artifact
exchange passed. Control #366 authorized that test path and #253 corrected
the exact self-plus-51-CPU inventory. Preserve those failures and the original
M23-02 evidence. M23-01/M23-02 are the merged portable benchmark foundation.
**M23/CAP-M23 remain incomplete.**

The next canonical software scope is [M23-03](batches/M23-03.yaml). This is a
planning contract until this control PR passes its gates and is integrated.
Then activate the exact canonical revision/blob in an isolated target branch.
Do not implement it using the target's M23-02 allowlist.

Read the complete YAML and [planning audit](evidence/M23-03-planning-2026-09-07.md).
The provider is `rtfw.runtime`: public Runtime CPU/device rates, cross-rate
selection, optional shedding, live-control publish/reject/rollback, checkpoint
and ordinary/active/live-control replay, Runtime watchdog/degradation, telemetry
emission/read/export, and complete-frame composition. Cases name representative,
full configured occupancy, and absolute validation boundaries separately.

The unchanged ProviderV1 times a complete invocation. Disclose included
reset/setup/drain/inspection cost. Injected Runtime clocks are synthetic logical
inputs, independent of fake/steady measurement clocks. Never infer isolated
physical latency or controlled thresholds. Use the installed loopback backend
and supported Runtime watchdog; private helpers and experimental governors
are forbidden. All borrowed state must survive accepted work and checked stop.

Both existing inventory assertions are in scope so discovery stays the exact
self/CPU/runtime union. Keep CPU provider/catalog and both prior package
wrappers unchanged; a new wrapper runs their complete checks before adding the
new installed-source/relocation/embedding coverage. Runtime, runner API,
schemas/validator, ABI, support matrices and previous evidence are forbidden.
Retain a reproducer and separate repair contract if a real Runtime defect blocks
the required public-API workload.

Standing software publication/integration authorization is already recorded
in `automation.json`; do not ask the owner to repeat it. Run focused and full
local checks, mandatory hosted CI and risk review before exact-head integration.
Do not waive failing checks or manufacture absent human/physical review.

After M23-03 closes, plan M23-04 HAL/CUDA/XDMA providers, then M23-05 comparison
and extension policy from exact new baselines. M24 CUDA maturity, M25 SDK and
M26 golden system follow. Physical/HIL/RT, Unreal, controlled-host thresholds,
signing, release and deployment remain independent gates.
