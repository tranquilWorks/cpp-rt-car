from pathlib import Path
import subprocess,json,gzip,hashlib,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');base='b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e';previous='e9f2862318801cfc60f48652d71ad88a4e7b99bc'
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert run('git','rev-parse','HEAD')==previous
assert 'UnicodeDecodeError' in Path('/tmp/cpp-m28-05-encoding-baseline.log').read_text()
assert 'Ran 25 tests' in Path('/tmp/cpp-m28-05-tests03.log').read_text() and Path('/tmp/cpp-m28-05-tests03.log').read_text().endswith('OK\n')
assert 'completed=' in Path('/tmp/cpp-m28-05-contract02.log').read_text()
assert not run('git','diff',base,'--','rt','core','include','src','bench','.github','abi','configs','profiles','qualification','CMakeLists.txt','tests/golden_audit')
assert (r/'samples/golden_audit/catalog.py').read_text()==run('git','show',previous+':samples/golden_audit/catalog.py').replace('candidate.read_text()',"candidate.read_text(encoding='utf-8')")+'\n'
e=r/'docs/evidence/M28-05-checkpoint';manifest=json.loads((e/'retained-manifest.json').read_text())
for pattern in ['cpp-m28-05-first-head-*','cpp-m28-05-windows-*','cpp-m28-05-superseded-*','cpp-m28-05-encoding-*','cpp-m28-05-tests03.log','cpp-m28-05-original-audit-tests02.log','cpp-m28-05-contract02.log','cpp-m28-05-hashes02.log','cpp-m28-05-repair-publish.py']:
 for p in sorted(Path('/tmp').glob(pattern)):
  if not p.is_file():continue
  name='correction-'+p.name.removeprefix('cpp-m28-05-')+'.gz';raw=p.read_bytes();(e/name).write_bytes(gzip.compress(raw,mtime=0));manifest.append(dict(source=str(p),retained=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(e/'retained-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths=set(run('git','diff','--name-only',base).splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());batch=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
for p in paths:
 assert any(fnmatch.fnmatch(p,q) for q in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(q) if q.endswith('/') else fnmatch.fnmatch(p,q) for q in batch['scope']['forbidden_paths']),p
(e/'reviewed-sources.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths) if not p.startswith('docs/evidence/')},indent=2)+'\n')
run('git','diff','--check');run('git','add','--',*sorted(paths),str(e.relative_to(r)));run('git','diff','--cached','--check');print(run('git','commit','-m','fix: decode offline audit fragments as UTF-8 on Windows'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m28-05-final-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','origin','agent/m28-05-ledger'),flush=True)
p=Path('/tmp/cpp-m28-05-pr.md');body=p.read_text()+f'''\nThe first candidate exposed an actual Windows portability failure: job111234232923 failed original/new audit tests (187/189 CTests passed) because the existing HTML-fragment reader used locale-default CP1252 for UTF-8 evidence. Retain that failure and the cancelled superseded jobs. A new complete-bundle Windows-default-decoder control fails the unchanged candidate with the same UnicodeDecodeError. Explicit UTF-8 fixes the reader; all25 new controls and all23 original catalog tests now pass, as does contract validation. No assertion, source evidence byte or qualification claim was weakened.\n\nCorrected head `{head}`, tree `{tree}`. Fresh full local, actual installed package and all32 hosted records are required again; previous-head passes are not final acceptance.\n''';p.write_text(body);q=Path('/tmp/cpp-m28-05-repair-pr-body.json');q.write_text(json.dumps({'body':body}));run('gh','api','--method','PATCH','repos/tranquilWorks/cpp-rt-car/pulls/298','--input',str(q));print('Corrected PR298',head,tree,flush=True)
