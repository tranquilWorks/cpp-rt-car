from pathlib import Path
import subprocess,json,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24');p=r/'products/cpp-rt-car'
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
assert not run('git','status','--porcelain');assert run('git','rev-parse','origin/main')=='83f442269ea7a823097e171ab969264ca8d0c96c'
run('git','switch','-c','agent/cpp-m28-05-plan','origin/main')
b=yaml.safe_load((p/'batches/M28-05.yaml').read_text())
b['sources'].update(baseline_commit='b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e', activation='owner_selected', owner_scope='Owner selected M28-05 after target297/control616 completed M28-04. Standing scoped publication and guarded integration continues. M28-06 and final owner stage remain inactive.')
b['sources']['requirements']=['products/cpp-rt-car/acceptance.yaml#CAP-M'+str(i) for i in range(15,27)]
b['scope']['forbidden_paths']+=['rt/src/','rt/include/','core/','src/','bench/','CMakeLists.txt']
b['acceptance'][5]='Activate only M28-05 at exact target main b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e and bind merged canonical revision/blob before implementation. Add a source-linked reconciliation ledger, offline standard-library validation and additive tests; integrate the overlay with the existing golden audit and actual installed bundle. Preserve original canonical requirements, frozen scenario and existing tests/assertions. Update living summaries and mechanically generated/digest-bound documents only. No runtime repair, new qualification card, excluded campaign or M28-06 activation.'
(p/'batches/M28-05.yaml').write_text(yaml.safe_dump(b,sort_keys=False,width=100))
note="""# M28-05 selected: acceptance and remaining-work reconciliation

Owner selected M28-05 after M28-04 target297/control616 completed. Target main
is `b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e`. Only M28-05 is active.

Reconcile all112 canonical requirements and the living golden audit against all
M27 deliveries and M28-01..04 evidence. Each requirement and retained obligation
needs source evidence, disposition, dependency and next action. Separate causal
repairs, unresolved software findings, instrumentation limits, owner exclusions
and final external acceptance. Open software defects block software-complete claims.

Use existing owner-stage cards/procedures for physical/RT/endurance, real Unreal,
controlled performance, unfamiliar-consumer review and production signing/release.
Original M27-05 campaigns/scanner expansion and M27-06 signature fixtures remain
excluded/unperformed; unsigned rebuilds are not authenticated provenance.

Add offline ledger validation and negative tests, integrate its current overlay
with the existing audit and verify the actual installed bundle. Runtime, ABI,
defaults, original tests/deadlines, frozen requirements/scenario and historical
evidence stay unchanged. All local/full and original32 exact-head hosted gates,
applicable package/static/no-allocation/ABI checks, risk review and guarded closure
remain required. M28-06 and all final owner-stage activity remain inactive.
"""
for f in ['README.md','CODEX_HANDOFF.md','milestones/M28.md']:
 q=p/f;q.write_text(note+'\n## Historical checkpoints\n\n'+q.read_text())
a=json.loads((p/'automation.json').read_text())
for x in a['batches']:
 if x['id']=='M28-05':x.update(mode='software',reason='Owner-selected M28-05 only: full acceptance reconciliation and existing owner-stage handoff. No unresolved defect or excluded/external obligation is waived; M28-06 inactive.')
(p/'automation.json').write_text(json.dumps(a,indent=2)+'\n')
a=yaml.safe_load((p/'roadmap.yaml').read_text())
for x in a['milestones']:
 if x['id']=='M28':x['planning_note']='M28-01..04 delivered; owner selected M28-05 only from target297 main. Reconcile all112 requirements, retained findings and existing owner-stage obligations; no software-complete or qualification claim while defects remain. M28-06 inactive.'
(p/'roadmap.yaml').write_text(yaml.safe_dump(a,sort_keys=False,width=100))
for phase in ['publish','pipeline','merge']:
 s=Path('/tmp/cpp-m28-04-plan-'+phase+'.py').read_text().replace('m28-04','m28-05').replace('M28-04','M28-05').replace('instrumented simulated-driver deadline investigation','acceptance and remaining-work reconciliation');Path('/tmp/cpp-m28-05-plan-'+phase+'.py').write_text(s)
print('M28-05 canonical activation prepared')
