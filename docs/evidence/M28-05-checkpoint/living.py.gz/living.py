from pathlib import Path
import json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');p=r/'docs/golden_audit/capabilities.json';a=json.loads(p.read_text());l=json.loads((r/'docs/closeout/ledger.json').read_text());find={f['id']:f for f in l['findings']}
for row in a['remaining_actions']:
 deps=l['remaining_actions'][row['id']]
 row['next_action']='M28-05 ledger tracks '+', '.join(deps)+'. '+ ' '.join(find[d]['next_action'] for d in deps)
 for d in deps:
  for ref in find[d]['evidence']:
   if ref not in row['evidence']:row['evidence'].append(ref)
updates={
'CAP-M20/outcome/1':'CAP-M20 remains incomplete. M27-04 delivers optional non-RT exporters, M27-06 records two matching unsigned local builds, and M27-08 delivers current-platform/migration and bounded portable soak coverage. Controlled performance, excluded original campaign/signature expansion, authenticated provenance, human soak/release review and deployment remain open; no promotion follows.',
'CAP-M20/scenario/1':'The complete M23 benchmark inventory and M28-02 provider-accounting correction supply portable evidence. CAP-M23 manual baseline/threshold review and M20-01 actual controlled-host performance gates remain unperformed. Portable structural passes are not controlled timing acceptance.',
'CAP-M20/scenario/2':'M27-06 independently rebuilt and consumed two matching default packages on one recorded host. These are unsigned local observations, not authenticated provenance or a reproducible-release guarantee. Original signature-fixture expansion and production identity/signing acceptance remain unperformed.',
'CAP-M20/scenario/4':'M27-08 verifies current supported tuples, modern/legacy target parity, actual relocated package discovery and fixed portable lifecycle repetition. No new supported tuple or historical binary package is qualified. Tuple expansion and controlled migration/soak/release review remain separate.',
'CAP-M20/automated/1':'Existing mandatory gates and M27 fixed C++ regressions, unsigned rebuilds, installed documentation and portable soak checks are retained. Original M27-05 generated-input/continuous/scanner expansion and M27-06 signature-fixture expansion remain excluded/unperformed. These scoped deliveries do not complete the original continuous acceptance.',
'CAP-M20/manual/1':'No agent or automated run supplies key custody, controlled runner review, independent soak review or release approval. Existing M20 signing/performance/platform-release identities remain owner-stage obligations with no inferred waiver.',
}
for row in a['requirements']:
 if row['id'] in updates:row['assessment']=updates[row['id']]
 if '/outcome/' in row['id'] and not row['id'].startswith('CAP-M20/'):
  row['assessment']+=' Current M28-05 reconciliation retains all related findings and external obligations in closeout.json; this source-level assessment is not an unqualified software-complete claim.'
for row,new in zip(l['requirements'],a['requirements']):
 row['assessment']=new['assessment'];row['evidence']=new['evidence'];row['sources']=new['sources'];row['tests']=new['tests']
p.write_text(json.dumps(a,sort_keys=True,indent=2)+'\n');(r/'docs/closeout/ledger.json').write_text(json.dumps(l,sort_keys=True,indent=2)+'\n')
(r/'docs/closeout/README.md').write_text('''# Acceptance and remaining-work reconciliation

[M28-05 ledger](../golden_audit/generated/closeout.html) covers all 112 canonical
requirements, all 100 original scenario-map entries through the original audit,
12 predecessor deliveries, 30 retained findings/obligations and seven original
remaining-action groups. [JSON source](ledger.json) is the editable inventory.
The installed entry is `share/rtfw/golden_audit/closeout.html` (also linked from
its original audit index). Every requirement keeps its original text, source,
test and evidence links plus current disposition, dependencies and next action.

Software-complete and CAP-M20-complete claims are false. Two demonstrated software
findings remain open: broader direct loopback cancel/submit storage ownership and
the optional full-SimCore SDK missing HAL header. Startup and historical benchmark/
Windows overlap observations, broader replay transactionality and experimental
policy limits remain explicit. Native full-frame TSan still fails its500us budget;
M28-04 classifies traced instrumentation timing without claiming a repair or pass.

The finding statuses distinguish demonstrated repairs, unresolved software,
unresolved observations, instrumentation limitations, unproven boundaries, claim
limits, owner exclusions and external acceptance. Dependencies include conservative
capability-level context, not a claim that each implemented subcriterion failed.
Original audit implementation labels remain distinct from final acceptance.

## Owner final-stage handoff

Reuse the pinned original identities in `existing_cards`, with procedures linked
from each obligation. This creates no new qualification cards or thresholds.

- M18-02 NVIDIA,03 XDMA,04 combined and05 RT/endurance: predeclare exact tuples,
  workload, policy and thresholds using the existing qualification plan/record/
  review process. M27-07 prepares the native host; it does not complete a physical
  golden run. The existing combined promotion-tool restriction remains explicit.
- M19-02 engine adapter,03 world/multiple-instance/unload and04 complete sample:
  use the existing approved M19-02 batch and roadmap identities with exact licensed
  engine/UBT/UAT/toolchain and actual editor plus packaged evidence.
- CAP-M23/manual/1 and M20-01: retain controlled baseline/threshold review before
  performance gates. Portable CI remains characterization only.
- CAP-M25/manual/1 and M25-06: an unfamiliar consumer follows the existing installed
  recipes and records findings; automated consumption does not replace that review.
- M20-02 and04: production identity/key custody, authenticated signing/provenance,
  supported-tuple/soak review, release publication and deployment decisions remain
  separate. Original M27-05 campaign/scanner and M27-06 signature-fixture expansion
  are excluded and unperformed; unsigned matching builds do not close them.

None of these actions is executed or approved by this ledger. M28-06 remains a
separately selected portable closure batch; it cannot erase unresolved defects.

## Reproduce and validate

From the checkout run `python3 tools/generate_golden_audit.py --check`,
`python3 tools/check_golden_audit.py`, and
`python3 tests/closeout_audit/test_closeout.py`. The same catalog validates the
actual installed offline bundle using `verify_bundle(Path(bundle_directory))`.
It rejects omitted/duplicate IDs, missing evidence/anchors, broken dependencies,
removed owner/excluded obligations, invented completion and altered rendered
claims even when output hashes are recomputed. Existing audit tests are preserved.

This is an offline source/evidence reconciliation. It starts no device, endpoint,
new campaign, signing operation or workflow. Snapshot hashes bind bundled bytes;
they do not authenticate an external author, reviewer or production identity.
''')
for file in ['docs/CURRENT_STATE.md','docs/HANDOFF.md','docs/roadmap.md','docs/migration.md']:
 p=r/file;p.write_text('''## M28-05 acceptance reconciliation

The [current ledger](closeout/README.md) reconciles all112 canonical requirements,
12 predecessor deliveries and30 retained findings/obligations. The original golden
audit and installed offline bundle link its complete source/evidence inventory.
Causal repairs stay distinct from unresolved loopback/optional-SDK defects,
historical startup/benchmark/Windows observations and the failed native-frame TSan
result. Software-complete and CAP-M20 completion are not claimed. Existing final
bench/RT/Unreal/performance/human/signing/release identities are reused; original
M27-05/06 exclusions remain unperformed. M28-06 remains inactive.

Exact-head full/local, original32 hosted checks, actual installed bundle validation
and guarded target/canonical closure are required before completion. Their final
receipts are recorded in this batch's PR and canonical closure.

## Historical checkpoints

'''+p.read_text())
