from pathlib import Path
import json,subprocess,gzip,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');c=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24');e=r/'docs/evidence/M28-05-checkpoint';e.mkdir(exist_ok=True)
manifest=[]
def retain(raw,name,source):
 p=e/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(raw,mtime=0));manifest.append(dict(source=source,retained=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
for path in ['products/cpp-rt-car/acceptance.yaml','products/cpp-rt-car/roadmap.yaml','products/cpp-rt-car/CODEX_HANDOFF.md','products/cpp-rt-car/batches/M19-02.yaml']:
 rev='83f442269ea7a823097e171ab969264ca8d0c96c';raw=subprocess.check_output(['git','show',rev+':'+path],cwd=c);retain(raw,'canonical-'+Path(path).name+'.gz',rev+':'+path)
for name in ['complete.json','known-failures.json','checks.json','offline-warning-review.json','final-full-result.json','merge.json','close-merge.json']:
 p=Path('/tmp/cpp-m28-04-'+name)
 if p.exists():retain(p.read_bytes(),'predecessor04-'+name+'.gz',str(p))
for p in sorted(Path('/tmp').glob('cpp-m28-05-*')):
 if p.is_file() and p.suffix in ['.log','.json','.txt','.py']:retain(p.read_bytes(),p.name.removeprefix('cpp-m28-05-')+'.gz',str(p))
(e/'retained-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(r/'docs/evidence/M28-05-2026-10-03.md').write_text('''# M28-05 acceptance and remaining-work reconciliation

Baseline target297 b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e; canonical
activation617 merged7cae639252f16bb921a22839f738fb72dc91ae3b after full
local and actual hosted control validation. The exact canonical blob/revision
is bound in contracts/active-batch.yaml before implementation.

## Acceptance mapping

The editable docs/closeout/ledger.json and installed closeout.html reconcile all
112 original canonical requirement rows,12 M27/M28 predecessor deliveries,30
findings/obligations,13 existing acceptance/card identities and all seven original
action groups. The original100 scenario-map entries and all frozen requirement
bytes stay unchanged; current canonical acceptance.yaml is byte-identical to the
bound original YAML. Every requirement preserves its original text/status/source/
tests/evidence and carries current disposition, dependencies and next action.
Capability-level dependencies are conservative context, not invented failures of
all subcriteria. Living CAP-M20 assessments now distinguish exporter delivery,
unsigned local rebuilds and portable migration/soak from still-open acceptance.

The ledger separates seven causal repairs, two unresolved software defects,
four unresolved observations, three instrumentation limits, two unproven
boundaries, one application claim boundary, two owner exclusions and nine
external acceptance obligations. The broader loopback backend race and optional
full-SimCore absent hal.hpp prevent an unqualified software-complete claim.
Original startup/benchmark/Windows failures and the native-frame initialized-TSan
failure remain recorded. M28-04 unchanged hosted retries do not repair those
findings. Original05 generated-input/continuous/scanner and06 signature-fixture
expansion remain excluded/unperformed; CAP-M20 is not promoted.

Existing M18 NVIDIA/XDMA/combined/RT/endurance, M19 engine/world/sample, CAP-M23
controlled-performance, M25 unfamiliar-consumer and M20 signing/platform/release
identities are pinned to canonical paths/revisions/blobs. Existing procedures are
linked; no new qualification card or threshold is created. The combined promotion
tool still refuses non-synthetic proposals under its original prerequisite rule.
Native host preparation is not physical golden completion. Matching unsigned
local packages do not establish authenticated provenance or release approval.

## Consumer and checks

The existing standard-library catalog validates ledger identity, complete unique
requirement/finding/delivery/action inventories, original text/evidence, exact
retained status policy, canonical owner-card bindings, dependency references and
cycles, concrete actions, safe local evidence paths and unique anchors. Structured
software/CAP-M20/physical/RT/engine/human/performance/provenance/release/deployment
claims cannot be promoted. Generated closeout HTML must reproduce exactly even
when an edited bundle is rehashed. All source snapshots remain offline and linked.
The existing SDK installation automatically includes generated ledger HTML/JSON;
no installed header, compiled target, component or CMake root changes.

Twenty-four new negative/positive tests and all23 original catalog tests pass.
Complete contract validation, generated audit321-file reproducibility, SDK manual
reproducibility and release hash/ABI8/70-export/fingerprint checks pass. These are
precommit checks; final clean exact-head full local, all32 original hosted records
with exact names/multiplicity, actual CPack/relocated installed-bundle consumption
and guarded target/canonical integration remain mandatory. Final PR and canonical
closure retain those receipts; this checkpoint does not invent their outcomes.

Runtime/native/experimental C++, existing tests/assertions/deadlines/workflows,
frozen inputs, qualification files, ABI/defaults and previous evidence remain
byte-identical. tests/CMakeLists.txt only appends the new offline audit CTest.
No new C++ behavior needs a separate diagnostic sanitizer build; original full
and hosted sanitizer/static/no-allocation/default/ABI/package gates stay required.
This batch validates offline Python/documentation behavior and claims no repair,
physical testing, engine execution, independent human review, production identity,
signing, release or deployment. M28-06 remains inactive.

Exact commands/logs, current canonical predecessor snapshots, prior closure
receipts and source review are retained with SHA-256 in M28-05-checkpoint.
Rollback removes this additive overlay and wiring and reverts its living summaries,
catalog and reviewed digest changes; preserve all historical evidence.
''')
# Counts are independently derived to keep the evidence precise.
l=json.loads((r/'docs/closeout/ledger.json').read_text());from collections import Counter
print(Counter(f['status'] for f in l['findings']))
(r/'docs/evidence/M28-05-risk-review.md').write_text('''# M28-05 source and claim review

Moderate-risk offline documentation/acceptance tooling only. No runtime/native/
experimental code, old test, threshold, default, ABI, workflow, qualification tuple
or public SDK target/header changes. Seven corrected mechanisms retain original
causal evidence; two remaining software defects keep software-complete false.
Investigation and retry success are not repair or human risk acceptance.

The verifier compares exact ordered original IDs/text/status/evidence against the
frozen canonical audit. Finding statuses, original action groups and existing
owner-card bindings are separately reviewed policy, preventing completion through
inventory omission or a newly rehashed claim. Dependencies resolve to retained
findings and cycle checks run. All local references use existing safe nonsymlink
path and exactly-one-line anchor checks; HTML prose is escaped. Bundle inventories
hash actual bytes and recompute rendered closeout claims. Hashes are integrity
observations, not authenticated authorship or provenance.

Tests exercise missing/duplicate IDs, dropped predecessor/action/exclusion/owner
records, altered original requirements/evidence, empty actions, missing/escaped
references, bad anchors, dependency omission/cycles, invented global/finding passes,
rehashed false HTML/JSON and actual complete offline bundles. Original23 catalog
tests pass unchanged. Human semantic review is still needed when future facts or
policy change; this bounded ledger is not an automatic discovery/qualification tool.

Current canonical acceptance bytes equal the frozen inventory. Complete M27 and
M28-01..04 evidence and canonical predecessor snapshots were reviewed, including
original fixture failures, scoped repairs, unsigned/protocol-only limits and
M28-04 final retry/warning records. Final original32 hosted checks, full local,
actual relocated installed bundle/public consumers and guarded head/base/review/
merge-tree equality remain integration gates. No new external campaign or test
fixture expansion is performed. Final-stage owner procedures and M28-06 remain
separately selected work; no obligation is waived.
''')
