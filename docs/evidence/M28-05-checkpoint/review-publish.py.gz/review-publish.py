from pathlib import Path
import subprocess,json,hashlib,fnmatch,yaml,ast
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');base='b37c124d6fd7c6ea7dd2b4dffcfc5531b0eb3c8e'
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert run('git','branch','--show-current')=='agent/m28-05-ledger' and run('git','rev-parse','HEAD')==base
assert not run('git','diff',base,'--','rt','core','include','src','bench','.github','abi','configs','profiles','qualification','CMakeLists.txt')
assert run('git','diff','--name-only',base,'--','tests')=='tests/CMakeLists.txt'
old=run('git','show',base+':tests/CMakeLists.txt');new=(r/'tests/CMakeLists.txt').read_text();assert new.startswith(old) and new[len(old):].strip()=='add_subdirectory(closeout_audit)'
assert run('git','diff','--name-only',base,'--','samples')=='samples/golden_audit/catalog.py'
assert not run('git','diff',base,'--','docs/golden_audit/requirements.yaml','docs/golden_audit/requirements.json','docs/golden_audit/requirements-binding.json','docs/golden_audit/source-map.json')
assert 'completed=' in Path('/tmp/cpp-m28-05-contract01.log').read_text()
assert 'Ran 24 tests' in Path('/tmp/cpp-m28-05-tests02.log').read_text() and Path('/tmp/cpp-m28-05-tests02.log').read_text().endswith('OK\n')
assert 'Ran 23 tests' in Path('/tmp/cpp-m28-05-original-audit-tests.log').read_text() and Path('/tmp/cpp-m28-05-original-audit-tests.log').read_text().endswith('OK\n')
old=json.loads(run('git','show',base+':release/rtfw-release-contract.json'));new=json.loads((r/'release/rtfw-release-contract.json').read_text());oh=old.pop('contract_sha256');nh=new.pop('contract_sha256');assert old==new
assert set(nh)-set(oh)=={'docs/closeout/README.md','docs/closeout/ledger.json','tests/closeout_audit/CMakeLists.txt','tests/closeout_audit/test_closeout.py'}
changed={p for p in nh if p not in oh or nh[p]!=oh[p]};assert changed==set(nh)-set(oh)|{'docs/migration.md','docs/roadmap.md','docs/golden_audit/capabilities.json','samples/golden_audit/catalog.py','tests/CMakeLists.txt','tools/check_release_contract.py'}
assert all(nh[p]==hashlib.sha256((r/p).read_bytes()).hexdigest() for p in nh)
for p in ['samples/golden_audit/catalog.py','tests/closeout_audit/test_closeout.py','tools/check_release_contract.py']:ast.parse((r/p).read_text())
paths=set(run('git','diff','--name-only',base).splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());batch=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
for p in paths:
 assert any(fnmatch.fnmatch(p,q) for q in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(q) if q.endswith('/') else fnmatch.fnmatch(p,q) for q in batch['scope']['forbidden_paths']),p
bindings={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths) if not p.startswith('docs/evidence/')}
e=r/'docs/evidence/M28-05-checkpoint';(e/'reviewed-sources.json').write_text(json.dumps(bindings,indent=2)+'\n');(e/'source-identity.json').write_text(json.dumps(dict(baseline=base,baseline_tree=run('git','rev-parse',base+'^{tree}'),production_changed=False,old_tests_changed=False,test_wiring_append_only=True,frozen_inventory_changed=False,release_identity_changed=False,changed_contract_hashes=sorted(changed)),indent=2)+'\n')
run('git','diff','--check');print('PASS reviewed scope/original-tests/production/frozen-inventory/release/AST checks',flush=True)
run('git','add','--',*sorted(paths),str(e.relative_to(r)));run('git','diff','--cached','--check');print(run('git','commit','-m','docs: reconcile acceptance and retained closeout obligations (M28-05)'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m28-05-final-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/m28-05-ledger'),flush=True)
body='''The original audit did not reconcile later repairs, retained failures and deferred acceptance in one current inventory. Add an offline source-linked ledger covering all112 canonical requirements,12 predecessor deliveries,30 findings/obligations and13 existing acceptance/card identities. The installed golden audit now links the ledger and its evidence snapshots.

Seven demonstrated repairs stay separate from two open software defects, historical observations, instrumentation limitations, owner exclusions and final external acceptance. Software-complete and CAP-M20-complete claims remain false. Reuse existing owner-stage procedures; original M27-05 campaign/scanner and M27-06 signature expansion remain unperformed. No production, original test/assertion/deadline, frozen requirement, ABI/default, workflow or qualification change.

24 new positive/negative ledger tests, all23 original catalog tests, complete contract/ABI checks, generated documentation and scope/risk review pass. The verifier rejects missing/duplicate IDs, absent evidence, invalid dependencies and invented acceptance, including rehashed HTML/JSON claims. Final clean-head full local, all32 exact original hosted names/multiplicity and actual relocated SDK consumption remain required before guarded integration. Canonical activation617; M28-06 and owner-stage activity stay inactive.
'''+f'\nReviewed head `{head}`, tree `{tree}`, baseline `{base}`.\n'
Path('/tmp/cpp-m28-05-pr.md').write_text(body);payload=Path('/tmp/cpp-m28-05-create.json');payload.write_text(json.dumps(dict(title='docs: acceptance and remaining-work reconciliation (M28-05)',head='agent/m28-05-ledger',base='main',draft=True,body=body)))
raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(payload));Path('/tmp/cpp-m28-05-create-result.json').write_text(raw+'\n');pr=json.loads(raw)['number'];Path('/tmp/cpp-m28-05-pr-number.txt').write_text(str(pr)+'\n');print('PR',pr,flush=True)
