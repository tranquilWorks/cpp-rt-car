from pathlib import Path
import subprocess
base='677fae6976f8eddd6ed7e060f222c3535a9e7ae2'
p=Path('rt/src/device_manager.hpp');s=subprocess.check_output(['git','show',base+':'+str(p)],text=True)
s=s.replace('        std::atomic_flag admission = ATOMIC_FLAG_INIT;','''        std::atomic_flag admission = ATOMIC_FLAG_INIT;
        // Retain an otherwise unclaimed callback/count failure without
        // disabling polling needed to reap retired native work. On supported
        // 64-bit targets this occupies the former alignment padding.
        std::atomic<Status> poll_failure{Status::ok};''')
s=s.replace('    void fail_backend_batches(std::size_t backend_index, Status status) noexcept;','    bool fail_backend_batches(std::size_t backend_index, Status status) noexcept;');p.write_text(s)
p=Path('rt/src/device_manager.cpp');s=subprocess.check_output(['git','show',base+':'+str(p)],text=True)
a=s.index('void DeviceManager::fail_backend_batches(');b=s.index('\nvoid DeviceManager::submission_loop',a);f=s[a:b]
f=f.replace('void DeviceManager::fail_backend_batches(', 'bool DeviceManager::fail_backend_batches(',1).replace('        return;','        return false;',1)
f=f.replace('    auto& control = batch_backends_[backend_index];','    bool delivered = false;\n    auto& control = batch_backends_[backend_index];',1)
f=f.replace('                continue;\n            }\n            state = expected;', '                delivered = true;\n                continue;\n            }\n            state = expected;',1)
f=f.replace('                finish_batch_slot(slot, status, false);','                finish_batch_slot(slot, status, false);\n                delivered = true;',1)
pos=f.rfind('\n}');f=f[:pos]+'\n    return delivered;'+f[pos:];s=s[:a]+f+s[b:]
a=s.index('void DeviceManager::poll_batch_completions(');b=s.index('\nvoid DeviceManager::service_loop()',a);f=s[a:b]
needle='''    const auto poll_capacity = native_per_backend_ ? std::min('''
f=f.replace(needle,'''    auto& pending_failure = batch_backends_[backend_index].poll_failure;
    auto pending = pending_failure.load(std::memory_order_acquire);
    if (pending != Status::ok && fail_backend_batches(backend_index, pending)) {
        (void)pending_failure.compare_exchange_strong(
            pending, Status::ok, std::memory_order_acq_rel,
            std::memory_order_relaxed);
        return;
    }
    // Keep polling even without a published Runtime slot: a timed-out
    // non-rate batch may still have a native completion that must be reaped.
'''+needle,1)
needle='''        fail_backend_batches(
            backend_index, callback_runtime_status == Status::ok
                               ? Status::device_error
                               : callback_runtime_status);'''
assert needle in f
f=f.replace(needle,'''        const auto failure = callback_runtime_status == Status::ok
            ? Status::device_error : callback_runtime_status;
        auto first = Status::ok;
        (void)pending_failure.compare_exchange_strong(
            first, failure, std::memory_order_acq_rel,
            std::memory_order_relaxed);
        // Preserve the first unclaimed error across the interval between
        // outstanding-count publication and a batch becoming visible.
        auto retained = first == Status::ok ? failure : first;
        if (fail_backend_batches(backend_index, retained)) {
            (void)pending_failure.compare_exchange_strong(
                retained, Status::ok, std::memory_order_acq_rel,
                std::memory_order_relaxed);
        }''',1)
s=s[:a]+f+s[b:]
needle='''            initialized_backends_[backend_index] =
                kBackendOwnershipNone;''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
            batch_backends_[backend_index].poll_failure.store(
                Status::ok, std::memory_order_release);''',1)
needle='''        resets_.fetch_add(1, std::memory_order_relaxed);''';assert s.count(needle)==1
s=s.replace(needle,'''        batch_backends_[backend_index].poll_failure.store(
            Status::ok, std::memory_order_release);
'''+needle,1);p.write_text(s)
p=Path('tests/startup_poll_reliability/main.cpp');s=p.read_text()
s=s.replace('static rt::CallbackResult call(void* p, const rt::DeviceCallbackContext&,','static rt::CallbackResult call(void* p, const rt::DeviceCallbackContext& context,')
s=s.replace('        out.signals[0].value = 1;', '        out.signals[0].value = context.frame.frame_index + 1;')
s=s.replace('    rt::Runtime runtime;','    rt::Runtime runtime;\n    std::array<rt::DeviceBackendHandle, 2> devices;')
s=s.replace('            rt::DeviceBackendHandle device;','            auto& device = devices[i];')
s=s.replace('''        const auto status = runtime.step({0, std::chrono::milliseconds(1)});
        const auto stopped''','''        const auto status = runtime.step({0, std::chrono::milliseconds(1)});
        if (status != Status::ok) {
            check(runtime.reset_device(devices[0]));
            check(runtime.reset_device(devices[1]));
            check(runtime.step({1, std::chrono::milliseconds(1)}));
        }
        const auto stopped''')
s=s.replace('''    require(fixture.backends[0].consumed && !fixture.backends[0].idle_consumed,
            "poll fault consumed without a published owner");''','''    require(fixture.backends[0].consumed &&
            fixture.backends[0].idle_consumed.load() == !active,
            "controlled fault delivery ordering changed");''')
p.write_text(s)
