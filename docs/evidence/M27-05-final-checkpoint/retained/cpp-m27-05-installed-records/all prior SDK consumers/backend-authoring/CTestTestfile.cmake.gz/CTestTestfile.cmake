# CMake generated Testfile for 
# Source directory: /tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring
# Build directory: /tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/backend-authoring
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[backend_authoring_output]=] "/usr/bin/cmake" "-DBACKEND_EXECUTABLE=/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/backend-authoring/backend_authoring" "-P" "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/check_output.cmake")
set_tests_properties([=[backend_authoring_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/CMakeLists.txt;19;add_test;/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/CMakeLists.txt;0;")
