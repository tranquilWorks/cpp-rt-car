# CMake generated Testfile for 
# Source directory: /tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/golden_showcase
# Build directory: /tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/golden-showcase
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[golden_showcase_kit]=] "/home/kbianco/.local/bin/python3.12" "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/golden_showcase/test.py" "--build" "/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/golden-showcase" "--provenance" "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/golden_showcase/provenance.json" "--config" "Release")
set_tests_properties([=[golden_showcase_kit]=] PROPERTIES  TIMEOUT "300" _BACKTRACE_TRIPLES "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/golden_showcase/CMakeLists.txt;49;add_test;/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/golden_showcase/CMakeLists.txt;0;")
