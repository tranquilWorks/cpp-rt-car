# CMake generated Testfile for 
# Source directory: /tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime
# Build directory: /tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/hello-runtime
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[hello_runtime_output]=] "/usr/bin/cmake" "-DHELLO_EXECUTABLE=/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/hello-runtime/hello_runtime" "-P" "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime/check_output.cmake")
set_tests_properties([=[hello_runtime_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime/CMakeLists.txt;19;add_test;/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime/CMakeLists.txt;0;")
