# CMake generated Testfile for 
# Source directory: /home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/pure_c
# Build directory: /tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/pure_c
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[pure_c_shared]=] "/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/pure_c/rtfw_pure_c_shared")
set_tests_properties([=[pure_c_shared]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/pure_c/CMakeLists.txt;15;add_test;/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/pure_c/CMakeLists.txt;0;")
add_test([=[pure_c_static]=] "/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/pure_c/rtfw_pure_c_static")
set_tests_properties([=[pure_c_static]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/pure_c/CMakeLists.txt;16;add_test;/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/pure_c/CMakeLists.txt;0;")
