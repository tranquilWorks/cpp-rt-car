# CMake generated Testfile for 
# Source directory: /tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter
# Build directory: /tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/host-adapter
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[host_adapter_native]=] "/usr/bin/cmake" "-DHOST_EXECUTABLE=/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/host-adapter/host_adapter" "-DHOST_MODE=native" "-P" "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/check_output.cmake")
set_tests_properties([=[host_adapter_native]=] PROPERTIES  TIMEOUT "40" _BACKTRACE_TRIPLES "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;22;add_test;/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;0;")
add_test([=[host_adapter_host]=] "/usr/bin/cmake" "-DHOST_EXECUTABLE=/tmp/runtime regression relocated 8jvkicxm/all prior SDK consumers/host-adapter/host_adapter" "-DHOST_MODE=host" "-P" "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/check_output.cmake")
set_tests_properties([=[host_adapter_host]=] PROPERTIES  TIMEOUT "40" _BACKTRACE_TRIPLES "/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;22;add_test;/tmp/runtime regression relocated 8jvkicxm/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;0;")
