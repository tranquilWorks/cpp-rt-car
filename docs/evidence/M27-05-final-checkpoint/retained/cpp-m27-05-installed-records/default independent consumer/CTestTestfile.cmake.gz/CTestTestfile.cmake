# CMake generated Testfile for 
# Source directory: /tmp/runtime regression relocated 8jvkicxm/independent tests/runtime_robustness
# Build directory: /tmp/runtime regression relocated 8jvkicxm/default independent consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[runtime_robustness]=] "/tmp/runtime regression relocated 8jvkicxm/default independent consumer/rtfw_runtime_robustness")
set_tests_properties([=[runtime_robustness]=] PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/tmp/runtime regression relocated 8jvkicxm/independent tests/runtime_robustness/CMakeLists.txt;17;add_test;/tmp/runtime regression relocated 8jvkicxm/independent tests/runtime_robustness/CMakeLists.txt;0;")
