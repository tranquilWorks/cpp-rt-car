from pathlib import Path
import subprocess,os,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m29-02-baseline');w.mkdir(exist_ok=True)
cmd=['g++','-std=c++20','-O1','-g','-pthread','-DRT_NUMERICS_FORCE_FMA','-fsanitize=thread','-fno-pie','-no-pie','-I'+str(r/'rt/include'),'/tmp/cpp-m29-02-fma-baseline.cpp','-o',str(w/'fma')]
p=subprocess.run(cmd,capture_output=True,text=True);(w/'compile.log').write_text(p.stdout+p.stderr);assert p.returncode==0
for i in range(1,101):
 p=subprocess.run([str(w/'fma')],capture_output=True,text=True,env=dict(os.environ,TSAN_OPTIONS='halt_on_error=1'),timeout=30);log=p.stdout+p.stderr;(w/f'run-{i}.log').write_text(log)
 if 'unexpected memory mapping' in log or (p.returncode==-11 and not log.strip()): continue
 result=dict(command=cmd,attempt=i,exit=p.returncode,race='WARNING: ThreadSanitizer: data race' in log);(w/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result);assert result['race'];break
else:raise RuntimeError('no initialized run')
