from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m29-02-instrument');records=[]
for name in ['fma','startup','replay']:
 cmd=['clang++-14','--analyze','-std=c++20','-pthread','-DRT_NUMERICS_FORCE_FMA=1','-Irt/include','-Iinclude','-Icore/include','-Itests/retained_findings','-I'+str(w/'observed'),'tests/retained_findings/'+name+'.cpp','-o',str(w/(name+'.plist'))]
 p=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=180);(w/(name+'-static.log')).write_text(p.stdout+p.stderr);records.append(dict(command=cmd,exit=p.returncode));assert p.returncode==0 and not p.stderr,p.stderr
(w/'static.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS Clang14 analysis')
