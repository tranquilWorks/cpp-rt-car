#include <rt/numerics.hpp>
#include <atomic>
#include <thread>
#include <cstdio>
int main() {
  std::atomic<bool> ready{false};
  std::thread a([&] { while(!ready.load()) {} for(int i=0;i<200000;++i) rt::set_use_fma((i&1)!=0); });
  std::thread b([&] { ready=true; for(int i=0;i<200000;++i) { rt::set_use_fma(false); if(rt::use_fma()) std::atomic_signal_fence(std::memory_order_seq_cst); } });
  a.join(); b.join(); std::puts("completed forced-FMA policy access");
}
