from pathlib import Path
import sys,json,hashlib,shutil
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');sys.path.insert(0,str(r/'tools'));import qualification as q
w=Path('/tmp/cpp-m29-02-proposal-baseline');w.mkdir(exist_ok=True)
values=[json.loads((r/('tests/qualification_fixtures/valid-combined-'+n+'.json')).read_text()) for n in ['campaign-plan','qualification-record','promotion-review']]
paths=[w/(n+'.json') for n in ['plan','record','review']]
for v in values:v['evidence_class']='qualification_campaign'
def write(i):paths[i].write_bytes(q._canonical_bytes(values[i]));return hashlib.sha256(paths[i].read_bytes()).hexdigest()
p=write(0);values[1]['plan_sha256']=p;d=write(1);values[2]['plan_sha256']=p;values[2]['record_sha256']=d;write(2)
try:q.validate_set(*paths,r/'tests/qualification_fixtures/artifacts');raise AssertionError('unexpected baseline pass')
except q.ValidationFailure as e:
 (w/'result.json').write_text(json.dumps({'errors':e.errors,'classification':'local parser fixture only; not physical evidence'},indent=2)+'\n');print(e.errors);assert list(e.errors)==['combined qualification is blocked until the M17-05 native path prerequisite is repaired']
