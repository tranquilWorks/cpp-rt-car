from pathlib import Path
import subprocess,json,os
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m29-02-instrument');records=[]
def run(label,cmd,env=None):
 print(label,flush=True)
 with (w/(label+'.log')).open('w') as f:p=subprocess.run(list(map(str,cmd)),cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=240)
 records.append(dict(label=label,command=list(map(str,cmd)),exit=p.returncode));(w/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return p
observed=w/'observed';assert run('prepare',['python3',r/'tests/retained_findings/prepare.py',r,observed]).returncode==0
for kind,san in [('asan','address,undefined'),('tsan','thread')]:
 for name,sources,defs,library in [('fma',['tests/retained_findings/fma.cpp','tests/golden_cuda/allocation.cpp'],['-DRT_NUMERICS_FORCE_FMA=1'],False),('replay',['tests/retained_findings/replay.cpp','tests/golden_cuda/allocation.cpp'],[],True),('startup',['tests/retained_findings/startup.cpp','rt/src/xdma_backend.cpp'],[],True)]:
  exe=w/(kind+'-'+name);cmd=['g++','-std=c++20','-O1','-g1','-pthread','-fno-omit-frame-pointer','-fno-pie','-no-pie','-fsanitize='+san,'-Irt/include','-Iinclude','-Icore/include','-Itests/retained_findings','-I'+str(observed),*defs,*sources,*([w/(kind+'-runtime.a')] if library else []),'-o',exe]
  assert run(kind+'-'+name+'-compile',cmd).returncode==0
  for mode in (['mock','native','gate'] if name=='startup' else ['run']):
   for attempt in range(1,101):
    label=f'{kind}-{name}-{mode}-{attempt:02}';p=run(label,[exe,mode],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:verbosity=1'));log=(w/(label+'.log')).read_text()
    if p.returncode==0:break
    if kind=='tsan' and ('unexpected memory mapping' in log or (p.returncode==-11 and not log.strip())):continue
    raise RuntimeError((label,p.returncode,log[-1500:]))
   else:raise RuntimeError('no initialized result')
(w/'result.json').write_text(json.dumps(dict(status='pass',records=records),indent=2)+'\n');print('PASS complete applicable instrumentation')
