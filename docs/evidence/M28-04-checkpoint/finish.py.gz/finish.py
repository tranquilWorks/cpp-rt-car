from pathlib import Path
import subprocess,json,datetime,collections
t=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');c=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(root,*args):return subprocess.check_output(args,cwd=root,text=True).strip()
result={}
for label,root,prefix in [('target',t,'cpp-m28-04'),('control',c,'cpp-m28-04-close')]:
 suffix='final-identity.txt' if label=='target' else 'identity.txt'
 head,tree=Path('/tmp/'+prefix+'-'+suffix).read_text().splitlines()
 merge=json.loads(Path('/tmp/'+prefix+'-merge.json').read_text());assert merge['merged']
 assert run(root,'git','rev-parse','HEAD')==head and not run(root,'git','status','--porcelain')
 assert run(root,'git','rev-parse',merge['sha']+'^{tree}')==tree
 result[label]={'head':head,'tree':tree,'merge':merge['sha'],'pr':int(Path('/tmp/'+prefix+'-pr-number.txt').read_text())}
checks=json.loads(Path('/tmp/cpp-m28-04-checks.json').read_text())['check_runs'];old=json.loads(Path('/tmp/m26-feature-r4-checks.json').read_text())['check_runs']
assert len(checks)==32 and all(x['head_sha']==result['target']['head'] and x['conclusion']=='success' for x in checks)
assert collections.Counter(x['name'] for x in checks)==collections.Counter(x['name'] for x in old)
assert json.loads(Path('/tmp/cpp-m28-04-final-full-result.json').read_text())['exit_code']==0
assert 'Control plane validation passed.' in Path('/tmp/cpp-m28-04-close-control.log').read_text()
result.update(investigation_only=True,production_changed=False,installed_package_tests=16,completed=datetime.datetime.now(datetime.timezone.utc).isoformat(),portable=181,strict=169,hosted=32,next_batch='M28-04',retained_findings=['Broader loopback backend cancel/submit race remains unresolved beyond provider-local correction.','Optional experimental full-SimCore SDK lacks hal.hpp.','Historical sampled startup assertions and Windows2024ms cause remain unresolved after M28-04 investigation; native-frame timing is next in M28-04.','Original hosted Windows GPUStub.Overlap negative overlap remains unresolved; unchanged retry does not erase it.'])
Path('/tmp/cpp-m28-04-complete.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
