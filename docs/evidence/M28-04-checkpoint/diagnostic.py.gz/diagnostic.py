from pathlib import Path
import subprocess,json,os
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m28-04-diagnostic');w.mkdir(exist_ok=True);records=[]
def run(name,cmd,env=None):
 with (w/(name+'.log')).open('w') as f:
  f.write(json.dumps(cmd)+'\n');f.flush();p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=240)
 records.append(dict(name=name,command=cmd,exit=p.returncode));(w/'results.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,(w/(name+'.log')).read_text()
for mode in ['ordinary','asan','tsan']:
 binary=w/mode
 flags=['-std=c++20','-O1','-g1','-fno-pie','-no-pie','-pthread','-fno-omit-frame-pointer','-Irt/include','-Iinclude','-Icore/include','-Irt/src','-Itests/closeout_deadline']
 if mode!='ordinary':flags+=['-fsanitize='+('address,undefined' if mode=='asan' else 'thread')]
 lib= 'build/agent-full/librtfw_runtime.a' if mode=='ordinary' else '/tmp/cpp-m28-02-focused/'+mode+'-runtime.a'
 cmd=['g++',*flags,'tests/closeout_deadline/main.cpp','tests/golden_cuda/allocation.cpp','/tmp/cpp-m28-04-diagnostic-source02/device_manager.cpp','rt/src/xdma_backend.cpp',lib,'-o',str(binary)]
 code,log=run(mode+'-build',cmd);assert code==0,log
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1',TSAN_OPTIONS='halt_on_error=1:verbosity=1')
 for probe,arg in [('frame','--frame'),('delay','--delay-submit')]:
  for n in range(1,101 if mode=='tsan' else 2):
   code,log=run(mode+'-'+probe+f'-{n:02}',[str(binary),arg],env)
   if mode=='tsan':
    if 'WARNING: ThreadSanitizer' in log:raise RuntimeError(log)
    body='\n'.join(log.splitlines()[1:]).strip()
    if 'unexpected memory mapping' in log or (code==-11 and not body):continue
    assert 'Running under ThreadSanitizer' in log,log
   assert code in [0,1] and 'overflow=0' in log,log
   if probe=='delay':assert code==1 and 'step status=-18 allocations=0' in log,log
   print(mode,probe,code,' '.join(x for x in log.splitlines() if 'PASS' in x or 'FAIL' in x or 'step status=' in x or 'TRACE count' in x),flush=True)
   break
  else:raise RuntimeError('No initialized TSan result')
print('All diagnostic observations retained; no timeout promoted to PASS',flush=True)
