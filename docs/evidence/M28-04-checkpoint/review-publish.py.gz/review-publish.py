from pathlib import Path
import subprocess,json,gzip,hashlib,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');base='526c13065475650f6c86de0ea8fc760d699a07a3'
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert run('git','branch','--show-current')=='agent/m28-04-deadline' and run('git','rev-parse','HEAD')==base
assert not run('git','diff',base,'--','rt','core','include','src','bench','.github','abi','configs','profiles','samples','tests/CMakeLists.txt')
assert not run('git','diff',base,'--','tests')
assert 'completed=' in Path('/tmp/cpp-m28-04-contract01.log').read_text()
assert not Path('/tmp/cpp-m28-04-static.log').read_text()
assert 'All diagnostic observations retained' in Path('/tmp/cpp-m28-04-diagnostic03.log').read_text()
assert 'PASS refused' in Path('/tmp/cpp-m28-04-tool-controls.log').read_text()
old=json.loads(run('git','show',base+':release/rtfw-release-contract.json'));new=json.loads((r/'release/rtfw-release-contract.json').read_text())
for p in ['docs/migration.md','docs/roadmap.md']:
 assert new['contract_sha256'][p]==hashlib.sha256((r/p).read_bytes()).hexdigest();old['contract_sha256'][p]=new['contract_sha256'][p]
assert old==new
binding=json.loads(Path('/tmp/cpp-m28-04-diagnostic-source03/source-binding.json').read_text());assert binding['hook_sha256']==hashlib.sha256((r/'tests/closeout_deadline/trace.hpp').read_bytes()).hexdigest()
assert binding['source_sha256']==hashlib.sha256((r/'rt/src/device_manager.cpp').read_bytes()).hexdigest()
checkpoint=r/'docs/evidence/M28-04-checkpoint';manifest=[]
def retain(p,dest):
 raw=p.read_bytes();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));manifest.append(dict(source=str(p),retained=str(dest.relative_to(checkpoint)),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
for p in sorted(Path('/tmp').glob('cpp-m28-04-*')):
 if p.is_file() and p.suffix in ['.log','.json','.cpp','.txt','.py','.plist']:retain(p,checkpoint/(p.name.removeprefix('cpp-m28-04-')+'.gz'))
for folder in ['baseline','diagnostic','diagnostic03','diagnostic-source02','diagnostic-source03']:
 for p in (Path('/tmp')/('cpp-m28-04-'+folder)).iterdir():
  if p.suffix in ['.log','.json','.plist','.cpp','.patch']:retain(p,checkpoint/(folder+'-'+p.name+'.gz'))
(checkpoint/'retained-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
history=[p for p in (r/'docs/evidence/M27-07-final-checkpoint/retained').rglob('*') if p.name in ['cpp-m27-07-frame04.log.gz','asan-02.log.gz','tsan-13-02.log.gz']]
(checkpoint/'historical-manifest.json').write_text(json.dumps({str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in history},indent=2)+'\n')
paths=set(run('git','diff','--name-only',base).splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());batch=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
for p in paths:
 assert any(fnmatch.fnmatch(p,q) for q in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(q) if q.endswith('/') else fnmatch.fnmatch(p,q) for q in batch['scope']['forbidden_paths']),p
bindings={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(paths) if not p.startswith('docs/evidence/')}
(checkpoint/'reviewed-sources.json').write_text(json.dumps(bindings,indent=2)+'\n')
(checkpoint/'source-identity.json').write_text(json.dumps({'baseline':base,'baseline_tree':run('git','rev-parse',base+'^{tree}'),'production_changed':False,'old_tests_changed':False,'existing_test_wiring_changed':False,'diagnostic_shipped':False},indent=2)+'\n')
run('git','diff','--check');print('PASS scope/source/old-tests/ABI/hash/risk review;',len(manifest),'raw artifacts retained',flush=True)
run('git','add','--','AGENTS.md','contracts/active-batch.yaml','docs/CURRENT_STATE.md','docs/HANDOFF.md','docs/roadmap.md','docs/migration.md','release/rtfw-release-contract.json','tests/closeout_deadline','docs/evidence/M28-04-2026-10-03.md','docs/evidence/M28-04-risk-review.md','docs/evidence/M28-04-checkpoint')
run('git','diff','--cached','--check');print(run('git','commit','-m','test: trace native frame deadline and quarantine ownership (M28-04)'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m28-04-final-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','-u','origin','agent/m28-04-deadline'),flush=True)
body='''The unchanged native full-frame probe still exceeds its 500us deadline under initialized TSan. Retain that failed result and add offline, source-bound timestamp diagnostics showing submission, expiry, quarantine, late completion and checked shutdown. An explicit2ms submission delay reproduces the timeout/ownership path in ordinary, ASan and TSan execution.

Production, original tests/assertions/deadlines and CMake/package targets remain unchanged. The original ordinary and ASan/UBSan/leak full-frame probes pass; original mandatory preparation/protocol passes all three modes. No race report or independently demonstrated production defect was found. This is a timing-limitation disposition, not a repair, full-frame TSan success or controlled timing qualification.

Clang14 analysis, diagnostic artifact refusal controls, zero-allocation assertions, contract and source/scope/hash review pass. Final-head full local, original32 hosted checks, actual relocated CPack consumers and guarded integration remain mandatory. Raw failures, instrumented source bindings, exact diagnostic patches, traces and initial draft mistakes are retained in docs/evidence/M28-04-checkpoint. Canonical activation615; M28-05..06 and final owner stage inactive. Broader backend race, SDK gap and historical software findings remain open.
'''+f'\nReviewed head `{head}`, tree `{tree}`, base `{base}`.\n'
Path('/tmp/cpp-m28-04-pr.md').write_text(body)
payload=Path('/tmp/cpp-m28-04-create.json');payload.write_text(json.dumps({'title':'test: native frame deadline investigation (M28-04)','head':'agent/m28-04-deadline','base':'main','draft':True,'body':body}))
raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(payload));Path('/tmp/cpp-m28-04-create-result.json').write_text(raw+'\n');pr=json.loads(raw)['number'];Path('/tmp/cpp-m28-04-pr-number.txt').write_text(str(pr)+'\n');print('PR',pr,flush=True)
