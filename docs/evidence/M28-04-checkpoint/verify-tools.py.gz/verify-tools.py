from pathlib import Path
import subprocess,json,tempfile,importlib.util
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');records=[]
for label,out in [('in-tree',str(r/'tests/closeout_deadline/REFUSED')),('existing','/tmp/cpp-m28-04-diagnostic-source03')]:
 p=subprocess.run(['python3','tests/closeout_deadline/instrument.py','--output',out],cwd=r,capture_output=True,text=True);assert p.returncode!=0;records.append({'case':label,'exit':p.returncode,'output':p.stdout+p.stderr})
with tempfile.TemporaryDirectory(prefix='cpp-m28-04-invalid-source-') as d:
 root=Path(d);(root/'rt/src').mkdir(parents=True);(root/'rt/src/device_manager.cpp').write_text('unreviewed\n')
 p=subprocess.run(['python3','tests/closeout_deadline/instrument.py','--root',d,'--output',d+'/rejected'],cwd=r,capture_output=True,text=True);assert p.returncode!=0 and not (root/'rejected').exists();records.append({'case':'unreviewed-source','exit':p.returncode,'output':p.stdout+p.stderr})
spec=importlib.util.spec_from_file_location('summarize',r/'tests/closeout_deadline/analyze.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
raw=Path('/tmp/cpp-m28-04-diagnostic03/ordinary-delay-01.log').read_text()
with tempfile.TemporaryDirectory(prefix='cpp-m28-04-invalid-log-') as d:
 for label,text in [('overflow',raw.replace('overflow=0','overflow=1')),('missing-exit',raw.replace('ORIGINAL_EXIT 1','')),('sanitizer-report',raw+'\nWARNING: ThreadSanitizer: data race\n'),('lost-release',raw.replace('shutdown_release','not_released'))]:
  p=Path(d)/label;p.write_text(text)
  try:m.summarize(p)
  except (ValueError,KeyError) as e:records.append({'case':label,'rejected':str(e)})
  else:raise AssertionError(label)
Path('/tmp/cpp-m28-04-tool-controls.json').write_text(json.dumps(records,indent=2)+'\n');print('PASS refused in-tree/existing/unreviewed output and incomplete/overflow/sanitizer/missing-retirement traces')
