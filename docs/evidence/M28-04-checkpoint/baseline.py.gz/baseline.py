from pathlib import Path
import subprocess,json,os,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m28-04-baseline');w.mkdir(exist_ok=True);records=[]
def run(name,cmd,env=None):
 with (w/(name+'.log')).open('w') as f:
  f.write(json.dumps(cmd)+'\n');f.flush();p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=240)
 records.append(dict(name=name,command=cmd,exit=p.returncode));(w/'results.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,(w/(name+'.log')).read_text()
a=Path('/home/kbianco/.local/share/portfolio-control/evidence-archives/cpp-m27-05-sanitizer-builds.tar.gz');m=json.loads(a.with_suffix('.manifest.json').read_text());assert hashlib.sha256(a.read_bytes()).hexdigest()==m['archive_sha256'];assert not subprocess.check_output(['git','diff','b8d54b3aced4083dfd91d34c65e871eab7e2e3c0','--','rt','core'],cwd=r,text=True)
bindings={}
for mode in ['ordinary','asan','tsan']:
 binary=w/mode
 if mode=='ordinary':cmd=['g++','-std=c++20','-O1','-g1','-pthread','-Irt/include','-Iinclude','-Icore/include','tests/golden_xdma_native/test_native.cpp','tests/golden_cuda/allocation.cpp','build/agent-full/librtfw_runtime.a','build/agent-full/librtfw_xdma_backend.a','-o',str(binary)]
 else:
  lib=Path('/tmp/cpp-m28-02-focused')/(mode+'-runtime.a');h=hashlib.sha256(lib.read_bytes()).hexdigest();assert h==m['manifest'][('0' if mode=='asan' else '1')+'/librtfw_runtime.a']['sha256'];bindings[str(lib)]=h
  cmd=['g++','-std=c++20','-O1','-g1','-fno-pie','-no-pie','-pthread','-fno-omit-frame-pointer','-Irt/include','-Iinclude','-Icore/include','-fsanitize='+('address,undefined' if mode=='asan' else 'thread'),'tests/golden_xdma_native/test_native.cpp','tests/golden_cuda/allocation.cpp','rt/src/xdma_backend.cpp',str(lib),'-o',str(binary)]
 code,log=run(mode+'-build',cmd);assert code==0,log
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1',TSAN_OPTIONS='halt_on_error=1:verbosity=1')
 for probe,args in [('frame',['--frame']),('mandatory',[])]:
  for n in range(1,101 if mode=='tsan' else 2):
   code,log=run(mode+'-'+probe+f'-{n:02}',[str(binary),*args],env)
   if mode=='tsan':
    if 'WARNING: ThreadSanitizer' in log:raise RuntimeError(log)
    body='\n'.join(log.splitlines()[1:]).strip()
    if 'unexpected memory mapping' in log or (code==-11 and not body):continue
    assert 'Running under ThreadSanitizer' in log,log
   print(mode,probe,code,' '.join(x for x in log.splitlines() if 'PASS' in x or 'FAIL' in x or 'step status=' in x),flush=True)
   if probe=='mandatory':assert code==0,log
   break
  else:raise RuntimeError('No initialized result')
(w/'source-binding.json').write_text(json.dumps({'archive_sha256':m['archive_sha256'],'rt_core_equivalent_to':'b8d54b3aced4083dfd91d34c65e871eab7e2e3c0','libraries':bindings,'sources':{str(p):hashlib.sha256((r/p).read_bytes()).hexdigest() for p in ['tests/golden_xdma_native/test_native.cpp','tests/golden_cuda/allocation.cpp','rt/src/device_manager.cpp','rt/src/xdma_backend.cpp']}},indent=2)+'\n')
