from pathlib import Path
import subprocess,json,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24');p=r/'products/cpp-rt-car'
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
assert not run('git','status','--porcelain');assert run('git','rev-parse','origin/main')=='aaa6d0373252729b1a35e9d0c58bc78808d580e6'
run('git','switch','-c','agent/cpp-m28-04-plan','origin/main')
b=yaml.safe_load((p/'batches/M28-04.yaml').read_text());b['sources'].update(baseline_commit='526c13065475650f6c86de0ea8fc760d699a07a3',activation='owner_selected',owner_scope='Owner selected the next batch after target296/control614 completed M28-03. Activate only M28-04 deadline investigation with injected drivers and unchanged full-frame probe. Standing scoped publication and guarded integration continues; M28-05..06 and final owner stage remain inactive.')
b['scope']['allowed_paths']=[x for x in b['scope']['allowed_paths'] if not x.startswith('rt/')]
b['scope']['forbidden_paths']+=['rt/src/','rt/include/','core/','src/','bench/','samples/golden_xdma/','samples/golden_xdma_native/','tests/golden_xdma_native/']
b['acceptance'][3]='Activate M28-04 from exact target main 526c13065475650f6c86de0ea8fc760d699a07a3 and bind merged canonical revision/blob before implementation. Initial cause-specific scope is additive test-owned offline diagnostics, controlled scheduling/ownership observations and evidence; production remains unchanged. An offline tool may generate an explicitly marked diagnostic copy of private DeviceManager source with fixed-storage timestamp hooks, source hashes and exact patch retention, never linked into shipped Runtime. No changed deadline, assertion, capability or sanitizer suppression. A demonstrated production defect requires a bounded canonical amendment before production edits. An unresolved full-frame timing result may receive a truthful limitation disposition; retry success closes no finding.'
(p/'batches/M28-04.yaml').write_text(yaml.safe_dump(b,sort_keys=False,width=100))
note='''# M28-04 selected: instrumented simulated-driver deadline investigation

Owner selected the next batch after M28-03 target296/control614 completed. Target
main is `526c13065475650f6c86de0ea8fc760d699a07a3`. Only M28-04 is active;
M28-05..06 and all final owner-stage activity remain inactive.

Retain the unchanged original native `--frame` probe in ordinary, ASan/UBSan and
initialized TSan execution. Its 500us native submission bound and all original
oracle/refusal assertions remain intact. Separate pre-main sanitizer failures
from initialized functional outcomes. Trace scheduling and ownership in explicitly
marked offline diagnostic builds using test-owned fixed-storage hooks. Diagnostic
copies never enter the shipped Runtime or replace the original failing result.

Initial scope adds diagnostics and evidence only. No private defect has yet been
independently demonstrated. Production changes require a precise causal finding
and bounded canonical amendment before editing. All local and original32 hosted
gates, appropriate instrumentation/static/no-allocation/ABI/default/package checks,
risk review and guarded target/control integration remain required.

This software investigation cannot establish physical or controlled timing.
Existing startup findings, broader loopback race, optional SDK missing hal.hpp,
original05/06 exclusions and owner-stage bench/engine/human/release work stay open.
'''
for f in ['README.md','CODEX_HANDOFF.md','milestones/M28.md']:
 q=p/f;q.write_text(note+'\n## Historical checkpoints\n\n'+q.read_text())
a=json.loads((p/'automation.json').read_text())
for x in a['batches']:
 if x['id']=='M28-04':x.update(mode='software',reason='Owner-selected M28-04 only; retain unchanged full-frame failure and classify scheduling/ownership with offline diagnostics. Fresh baseline bound at activation; later batches and final owner stage inactive.')
(p/'automation.json').write_text(json.dumps(a,indent=2)+'\n')
a=yaml.safe_load((p/'roadmap.yaml').read_text())
for x in a['milestones']:
 if x['id']=='M28':x['planning_note']='M28-01..03 delivered; owner selected M28-04 only from target296 main. Trace unchanged 500us native frame deadline with offline diagnostics; no production repair inferred and no old assertion relaxed. M28-05..06 and final owner stage inactive.'
(p/'roadmap.yaml').write_text(yaml.safe_dump(a,sort_keys=False,width=100))
for phase in ['publish','pipeline','merge']:
 s=Path('/tmp/cpp-m28-03-plan-'+phase+'.py').read_text().replace('m28-03','m28-04').replace('M28-03','M28-04').replace('sampled startup and cleanup timing investigation','instrumented simulated-driver deadline investigation');Path('/tmp/cpp-m28-04-plan-'+phase+'.py').write_text(s)
print('M28-04 canonical activation prepared')
