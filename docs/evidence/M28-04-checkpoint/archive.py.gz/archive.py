from pathlib import Path
import tarfile,hashlib,json,shutil,os,subprocess
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
assert Path('/tmp/cpp-m28-03-complete.json').exists()
roots=[Path('/tmp/cpp-m28-03-package'),Path('/tmp/cpp-m28-03-focused'),Path('/tmp/cpp-m28-03-probe'),Path('/tmp/cpp-m28-03-current')]
dest=Path('/home/kbianco/.local/share/portfolio-control/evidence-archives/cpp-m28-04-completed-03-copies.tar.gz');assert not dest.exists();manifest={}
for idx,root in enumerate(roots):
 assert root.exists()
 if str(root).startswith(str(r)):assert subprocess.run(['git','check-ignore','-q',str(root)],cwd=r).returncode==0
 for p in [root,*sorted(root.rglob('*'))] if root.is_dir() else [root]:
  name=str(idx)+('/'+p.relative_to(root).as_posix() if p!=root else '')
  m={'source':str(p),'mode':p.lstat().st_mode&0o7777}
  if p.is_symlink():m.update(kind='symlink',target=os.readlink(p))
  elif p.is_dir():m['kind']='directory'
  elif p.is_file():m.update(kind='file',sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
  else:raise RuntimeError(str(p))
  manifest[name]=m
with tarfile.open(dest,'w:gz',dereference=False) as t:
 for idx,root in enumerate(roots):t.add(root,arcname=str(idx),recursive=True)
with tarfile.open(dest,'r:gz') as t:
 assert set(t.getnames())==set(manifest)
 for m in t.getmembers():
  x=manifest[m.name];assert m.mode==x['mode']
  if x['kind']=='file':
   data=t.extractfile(m).read();assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256']
  elif x['kind']=='symlink':assert m.issym() and m.linkname==x['target']
  else:assert m.isdir()
record={'roots':[str(p) for p in roots],'archive':str(dest),'archive_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'manifest':manifest}
dest.with_suffix('.manifest.json').write_text(json.dumps(record,indent=2)+'\n')
Path('/tmp/cpp-m28-04-completed-03-copies-archive.json').write_text(json.dumps({k:v for k,v in record.items() if k!='manifest'},indent=2)+'\n')
for root in roots:
 if root.is_dir():shutil.rmtree(root)
 else:root.unlink()
print('Archived and verified',len(manifest),'entries before removing completed owned build copies;',dest.stat().st_size,'bytes',flush=True)
