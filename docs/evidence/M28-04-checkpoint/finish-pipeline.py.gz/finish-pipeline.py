from pathlib import Path
import subprocess,json,time
w=Path('/tmp')
head=(w/'cpp-m28-04-final-identity.txt').read_text().splitlines()[0]
for _ in range(800):
 full=w/'cpp-m28-04-final-full-result.json'
 if full.exists():
  result=json.loads(full.read_text());assert result['head']==head
  if result['exit_code']!=0:raise RuntimeError('Actual full verification failure; inspect retained log')
 progress=w/'cpp-m28-04-final-checks-progress.json'
 if (w/'cpp-m28-04-passing-full.txt').exists() and progress.exists():
  checks=json.loads(progress.read_text())['check_runs']
  if len(checks)==32 and all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in checks):break
 time.sleep(15)
else:raise RuntimeError('Waiting window elapsed; reconcile ongoing CI rather than waive it')
for phase in ['merge','close','close-pipeline']:
 with (w/('cpp-m28-04-'+phase+'-execution.log')).open('w') as f:
  p=subprocess.run(['python3',str(w/('cpp-m28-04-'+phase+'.py'))],stdout=f,stderr=subprocess.STDOUT)
 print(phase,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('PASS M28-04 target and canonical closure integrated',flush=True)
