#include <cstdio>
#include "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/samples/golden_xdma/runner.hpp"
int main(int argc,char** argv) { std::fputs("golden XDMA CLI entered\n",stderr); return golden::xdma::portable_main(argc,argv); }
