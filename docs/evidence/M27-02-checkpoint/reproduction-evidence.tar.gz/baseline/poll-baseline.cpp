#define RTFW_DEVICE_CAPACITY_NO_MAIN
#include "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/device_capacity_consumer.cpp"
#include <cstdio>
struct Gate { std::atomic<bool> open{false}; };
struct Backend : device_capacity::Backend {
 Gate* gate{}; unsigned index{}; rt::HalV2CommandTimelineExtension original{};
 rt::HalV2CommandTimelineExtension wrapped() {
  original=commands(); auto c=original;
  c.poll=[](void* p,rt::HalV2BatchCompletion* out,std::uint64_t cap,std::uint64_t* n) {
   auto& s=*static_cast<Backend*>(static_cast<device_capacity::Backend*>(p));
   auto z=s.original.poll(p,out,cap,n);
   if(s.index==1 && *n) s.gate->open=true;
   return z;
  }; return c;
 }
};
struct Provider {
 Gate* gate; unsigned index; rt::DeviceCommandBatch batch{};
 static rt::CallbackResult call(void* p,const rt::DeviceCallbackContext&,rt::DeviceCommandBatch& b) {
  auto& s=*static_cast<Provider*>(p);
  auto end=std::chrono::steady_clock::now()+std::chrono::seconds(5);
  while(s.index==0 && !s.gate->open) {
   if(std::chrono::steady_clock::now()>end)return rt::CallbackResult::error;
   std::this_thread::yield();
  }
  b=s.batch;b.timeout_ns=5'000'000'000;b.signals[0].value=1;return rt::CallbackResult::ok;
 }
};
int main() {
 Gate gate;std::array<Backend,2> backends;std::array<Provider,2> providers{{{&gate,0,{}},{&gate,1,{}}}};
 rt::Runtime r;rt::RuntimeConfig cfg;cfg.worker_count=2;cfg.callback_capacity=2;cfg.device_backend_capacity=2;cfg.device_outstanding_capacity=2;cfg.device_completion_batch=2;
 auto check=[](rt::Status z){if(z!=rt::Status::ok){std::fprintf(stderr,"setup %d\n",int(z));std::exit(2);}};
 check(r.configure(cfg));check(r.set_device_capacity_policy(rt::DeviceCapacityPolicy::native_per_backend));
 for(unsigned i=0;i<2;++i){
  auto& backend=backends[i];backend.gate=&gate;backend.index=i;
  auto m=backend.memory();auto c=backend.wrapped();rt::DeviceBackendHandle d;const char* name=i?"second":"first";
  check(r.register_device_backend({name,backend.core(),&m,&c},d));rt::DeviceTimelineHandle tl;check(r.register_device_timeline({name,d,0},tl));
  auto& b=providers[i].batch;b.command_count=b.signal_count=1;b.commands[0].kind=static_cast<std::uint32_t>(rt::HalV2CommandKind::dispatch);b.commands[0].opcode=2642;b.signals[0].timeline_handle=tl.value;
  rt::PhaseHandle phase;check(r.register_device_batch_phase({name,d,Provider::call,&providers[i],b},phase));
 }
 check(r.finalize());check(r.start());backends[0].excessive_completion=true;
 auto z=r.step({0,std::chrono::milliseconds(1)});auto stop=r.stop();
 std::printf("fault=%d step=%d stop=%d first_submitted=%u first_polled=%u second_submitted=%u\n",!backends[0].excessive_completion,int(z),int(stop),backends[0].submitted.load(),backends[0].polled.load(),backends[1].submitted.load());
 return z==rt::Status::device_error && stop==rt::Status::ok?0:1;
}
