#define RTFW_SAMPLED_SIMULATION_NO_MAIN
#include "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/tests/package_consumer/sampled_io_simulation_consumer.cpp"
int main() {
 sampled_simulation::Fixture f; f.simulation.reset();f.backend.deterministic=false;
 auto api=f.backend.card.api();
 api.request_stop=[](void*) noexcept {return rt::XdmaDriverResult::success;};
 rt::XdmaBackendConfig c;c.queue_capacity=4;c.buffer_capacity=1;c.worker_count=1;c.h2c_channel_count=c.c2h_channel_count=1;c.max_buffer_bytes=4096;c.max_transfer_bytes=128;c.transfer_alignment=1;c.control_aperture_bytes=4;c.user_event_count=1;
 f.backend.native=std::make_unique<rt::XdmaDeviceBackend>(api,c);
 if(f.configure()!=rt::Status::ok || f.runtime.finalize()!=rt::Status::ok)return 2;
 f.backend.card.hold=true;
 auto start=f.runtime.start();rt::SampledIoChannelStatus info;bool found=f.runtime.sampled_io_channel_status(f.output,info);
 auto pending=f.runtime.stop();bool live=f.backend.card.live;
 f.backend.card.hold=false;
 auto end=std::chrono::steady_clock::now()+std::chrono::seconds(2);unsigned retries=0;rt::Status stop;
 do {stop=f.runtime.stop();++retries;if(stop==rt::Status::ok)break;std::this_thread::yield();}while(std::chrono::steady_clock::now()<end);
 std::printf("start=%d channel_failure=%d pending_stop=%d retained_live=%d final_stop=%d live=%d entered=%d timeout=%llu retries=%u\n",int(start),int(info.last_status),int(pending),live,int(stop),f.backend.card.live.load(),f.backend.card.entered.load(),static_cast<unsigned long long>(f.backend.card.event_timeout.load()),retries);
 return found && start==rt::Status::invalid_state && info.last_status==rt::Status::device_timeout && pending==rt::Status::invalid_state && live && stop==rt::Status::ok && !f.backend.card.live?0:1;
}
