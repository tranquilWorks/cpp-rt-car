from pathlib import Path
import json,subprocess,collections,gzip
b=Path('products/cpp-rt-car');m=json.loads(Path('/tmp/m26-feature-r4-merge.json').read_text());assert m['merged'];sha=m['sha']
head,tree=Path('/tmp/m26-feature-r4-final-identity.txt').read_text().splitlines();checks=json.loads(Path('/tmp/m26-feature-r4-checks.json').read_text())['check_runs'];old=json.loads(Path('/tmp/cpp-m26-03-checks.json').read_text())['check_runs']
assert len(checks)==32 and all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in checks)
assert collections.Counter(c['name'] for c in checks)==collections.Counter(c['name'] for c in old)
full=Path('/tmp/m26-feature-r4-final-full.log').read_text();assert f'head={head}' in full and 'completed=' in full and all(f'100% tests passed, 0 tests failed out of {n}' in full for n in [148,152])
assert 'PASS complete resumed feature local gates' in Path('/tmp/m26-feature-r4-gates-progress.log').read_text()
target=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');assert subprocess.check_output(['git','rev-parse',sha+'^{tree}'],cwd=target,text=True).strip()==tree
intro=f'''# M26-04 complete; two software batches remain

The golden XDMA sampled loopback [target PR279](https://github.com/tranquilWorks/cpp-rt-car/pull/279)
merged at `{sha}` after all32 exact-head checks passed at `{head}`.
Fetched/tested tree `{tree}` matches. Clean/head/base/no-unresolved-review
and fetched-tree guards passed; no target or local functional gate was waived.

The complete installed public-SDK kit executes the frozen sensor/actuator loop
through actual Runtime sampled channels and native XDMA worker batches using
an owned simulated driver. CPU and combined CUDA kernel/Graph physics run with
native workers, independent host jobs or an actual external CIL controller.
Exact full-state parity, sampled safety/sequence/age, operation/resource counts,
originating-owner trusted replay and paired fresh-owner checkpoint recovery pass.
Transport faults, missing/duplicate/stale samples, native queue/cancel, partial
lifecycle failures, retained ownership, checked retry and independent owners are
covered. Only the owned simulator enables mock replay and host timing policy.

Repairs280/281/282/283 were separately integrated and canonically reactivated
before completion. Preserve ring4, native CUDA1/XDMA2 with aggregate3 admission,
safe8ms logical/backend deadlines, finite5s simulator watchdog, all public/ABI/
schema/default identities, prior kits/tests/evidence and native backend sources.
The feature adds no further Runtime or native driver changes.

Validation: contract, full portable148/strict152, focused37, ASan/UBSan/leaks25,
TSan25, zero ordinary/aligned allocations with positive controls, Clang static,
actual relocated CPack after removed original prefix with custom paths/spaces,
all56 prior SDK consumers plus9 XDMA variants=65, source embedding and negatives.
The native43/host31/external11 process suites and independent artifact checks
include invalid inputs, missing peers, foreign variants and checksum-repaired
corruptions. Reviewed source identities and all failed attempts remain retained.

New complete1024-tick sanitizer cases initially exceeded their new120-second
process harness; an unchanged O1 kernel run completed in121.09s. Only these new
cases receive300s under sanitizers. The full workload, owner replay, every
assertion/instrumentation check, ordinary/prior test timeouts and Runtime safety
deadlines remain unchanged. O2 experiments were not adopted. Prior Windows
scheduler-sensitive fixture failures and API errors remain documented separately;
complete final-head hosted jobs passed. No performance claim follows.

Remaining software batches are M26-05 benchmark/fault/control showcase and
M26-06 living documentation/feature-completion audit. Both remain inactive;
M26-05 is next to plan, and CAP-M26 remains incomplete. M25 unfamiliar-consumer
review is UNPERFORMED. Physical CUDA/XDMA/combined/HIL, RT1/RT2, controlled
performance, independent human review, Unreal, signing/release and deployment
remain separate. Artifact hashes do not authenticate physical execution.

Full local control validation and hosted control disposition are recorded in
this closure PR. The standing completed zero-step infrastructure exception is
control-only and never substitutes for a target/local functional gate.

## Historical checkpoints

'''
for name in ['CODEX_HANDOFF.md','README.md']:
 p=b/name;p.write_text(intro+p.read_text())
p=b/'roadmap.yaml';s=p.read_text();start=s.index('  - id: M26\n');prefix,tail=s[:start],s[start:]
assert '    next_batch: M26-04-xdma-hal-hil-loopback-variant' in tail
tail=tail.replace('M26-03-cuda-physics-variant]', 'M26-03-cuda-physics-variant, M26-04-xdma-hal-hil-loopback-variant]',1).replace('    next_batch: M26-04-xdma-hal-hil-loopback-variant','    next_batch: M26-05-benchmark-fault-and-control-showcase',1)
lines=tail.splitlines();index=next(i for i,line in enumerate(lines) if line.startswith('    planning_note: '));lines[index]=f'    planning_note: M26-04 target279 merged at {sha}, exact head {head}/tree {tree}; all32 and full148+152/focused37/sanitizer25+25/static/relocated CPack65 SDK and embedding gates passed. Owned simulated native-driver protocol evidence only. Two software batches remain inactive; M26-05 showcase is next to plan and M26-06 documentation/audit follows. CAP-M26, human/physical/RT/controlled-performance/Unreal/release gates remain incomplete/separate.'
p.write_text(prefix+'\n'.join(lines)+'\n')
e=b/'evidence/M26-04-closure-2026-09-30';e.mkdir(parents=True,exist_ok=False)
for name in ['checks.json','pre-guard.json','guard.json','merge.json','final-identity.txt','final-full.log','final-contract.log','gates-progress.log','gate-results.json','sanitize.log','sanitizer-results.json']:
 p=Path('/tmp/m26-feature-r4-'+name)
 if p.exists():(e/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for name in ['acceptance.md','commands.md','reviewed-sources.json']:(e/name).write_bytes((target/'docs/evidence/M26-04-final-verification'/name).read_bytes())
(e/'closure.md').write_text(intro.split('## Historical checkpoints')[0].rstrip()+'\n')
Path('/tmp/m26-feature-r4-close-base.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
