from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
assert 'Control plane validation passed.' in Path('/tmp/m26-feature-r4-close-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m26-04-close'
paths=['products/cpp-rt-car/CODEX_HANDOFF.md','products/cpp-rt-car/README.md','products/cpp-rt-car/roadmap.yaml','products/cpp-rt-car/evidence/M26-04-closure-2026-09-30']
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','cpp-rt-car: close M26-04 golden XDMA sampled loopback'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/m26-feature-r4-close-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','--set-upstream','origin','agent/cpp-m26-04-close'),flush=True)
body=(r/'products/cpp-rt-car/evidence/M26-04-closure-2026-09-30/closure.md').read_text()+f'\nFull local control validation PASSED. Exact control head `{head}`, tree `{tree}`. Hosted disposition and guarded merge remain required.\n';Path('/tmp/m26-feature-r4-close-pr.md').write_text(body)
existing=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m26-04-close&base=main'));assert len(existing)<=1
if existing:number=existing[0]['number']
else:
 p=Path('/tmp/m26-feature-r4-close-create.json');p.write_text(json.dumps({'title':'cpp-rt-car: close M26-04 golden XDMA sampled loopback','head':'agent/cpp-m26-04-close','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/m26-feature-r4-close-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/m26-feature-r4-close-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
