from pathlib import Path
import subprocess,json
records=[]
def gate(label,args):
 with open('/tmp/m26-feature-r4-'+label+'.log','w') as f:
  f.write('COMMAND '+json.dumps(args)+'\n');f.flush();p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 records.append({'label':label,'command':args,'exit':p.returncode});Path('/tmp/m26-feature-r4-gate-results.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
gate('full01',['./scripts/agent-verify.sh','full'])
gate('focused',['ctest','--test-dir','build/agent-quick','-R','host_adapter_golden_xdma','--output-on-failure'])
gate('sanitize',['python3','/tmp/m26-feature-r4-sanitize.py'])
gate('static',['clang++-14','--analyze','-Xanalyzer','-analyzer-output=text','-std=c++20','-Wall','-Wextra','-Werror','-Irt/include','-Icore/include','-Iinclude','samples/golden_xdma/main.cpp','tests/golden_xdma/test_xdma.cpp'])
gate('package',['python3','tests/golden_xdma/verify_package.py','--work-directory','build/m26-04-package'])
print('PASS complete resumed feature local gates',flush=True)
