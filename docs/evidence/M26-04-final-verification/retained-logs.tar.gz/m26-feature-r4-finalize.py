from pathlib import Path
import subprocess,json,gzip,hashlib,fnmatch,yaml,tarfile,io
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
assert run('git','branch','--show-current')=='agent/m26-04-xdma'
assert 'PASS complete resumed feature local gates' in Path('/tmp/m26-feature-r4-gates-progress.log').read_text()
full=Path('/tmp/m26-feature-r4-full01.log').read_text();assert 'completed=' in full and all(f'100% tests passed, 0 tests failed out of {n}' in full for n in [148,152])
assert '100% tests passed, 0 tests failed out of 37' in Path('/tmp/m26-feature-r4-focused.log').read_text()
san=Path('/tmp/m26-feature-r4-sanitize.log').read_text();assert 'PASS asan 25 cases' in san and 'PASS tsan 25 cases' in san
pkg=Path('/tmp/m26-feature-r4-package.log').read_text();assert '100% tests passed, 0 tests failed out of 65' in pkg and 'PASS CPack relocation, one-command execution, full SDK, embedding and negative controls' in pkg
static=Path('/tmp/m26-feature-r4-static.log').read_text();assert static.startswith('COMMAND ') and not '\n'.join(static.splitlines()[1:]).strip()
repair=json.loads(Path('/tmp/cpp-m26-04r4-merge.json').read_text())['sha']
d=yaml.safe_load((r/'contracts/active-batch.yaml').read_text());assert d['batch']['id']=='M26-04' and d['sources']['baseline_commit']==repair
paths=set(run('git','diff','--name-only',repair).splitlines())
def match(p,q):return p.startswith(q) if q.endswith('/') else fnmatch.fnmatchcase(p,q)
for p in paths:
 assert any(match(p,q) for q in d['scope']['allowed_paths']),p
 assert not any(match(p,q) for q in d['scope']['forbidden_paths']),p
assert not run('git','diff','--name-only',repair,'--','rt','samples/golden_system','samples/golden_cuda','.github/workflows/ci.yml','docs/cuda_capabilities.json')
e=r/'docs/evidence/M26-04-final-verification';e.mkdir(exist_ok=True)
bundle=io.BytesIO();artifacts={}
with tarfile.open(fileobj=bundle,mode='w') as archive:
 for p in sorted(Path('/tmp').glob('m26-feature-r4-*')):
  if not p.is_file() or p.suffix not in ['.log','.json','.py']:continue
  data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mtime=0;info.mode=0o644
  archive.addfile(info,io.BytesIO(data));artifacts[p.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(e/'retained-logs.tar.gz').write_bytes(gzip.compress(bundle.getvalue(),mtime=0))
(e/'retained-artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
review=sorted(set(run('git','ls-files','samples/golden_xdma','samples/golden_system','samples/golden_cuda','tests/golden_xdma').splitlines())|{'CMakeLists.txt','samples/CMakeLists.txt','tests/CMakeLists.txt','tests/package_consumer/CMakeLists.txt','.github/workflows/docs-contract.yml','tools/check_docs_contract.py'})
(e/'reviewed-sources.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in review},indent=2)+'\n')
(e/'acceptance.md').write_text('''# M26-04 local acceptance and remaining integration gates

All feature-local functional gates pass against integrated repair283. Evidence
is portable injected-driver protocol execution, not physical XDMA/CUDA or RT.

| Acceptance | Implementation and verification |
| --- | --- |
| Frozen scenario and prior sources | Golden contract/config/Python checks; scope guard preserves all Runtime/native/ABI and CPU/CUDA sources. |
| Actual native XDMA and combined execution | Owner/session/Io forwards real HAL-v2 batches; native/host/external CPU/kernel/Graph matrix and exact operation/resource counts. |
| Sampled channels and safe output | Four real ring4 sampled descriptors, distinct 120-byte codecs, terminal ACK counters; startup/failure/stop and underflow/overrun/missing ACK. |
| Full numerical parity | Every active/inactive state field against independent CPU bytes and C++/Python oracle; counts1/odd/default/256, workers1/2/3, grains1/4/16/64 and ticks through1024. |
| Honest simulator boundary | Complete owned-driver forwarding adapter; native capabilities/replay rejection; five-second mock watchdog with unchanged logical/backend safe8ms. |
| Replay and recovery | Complete originating-owner trusted replay, compatible fresh-owner paired checkpoint recovery; foreign/CPU/CUDA/cross-variant and checksum-repaired mutations rejected. |
| Faults and lifetime | 27 transport fault variants, missing/duplicate/stale frames, loss/reset, short/timeout/not-ready, two-slot queue/cancel, partial init/shutdown, retention/retry and concurrent owners. |
| Allocation and concurrency | Ordinary/aligned positive controls1; steady and supported replay0 including actual native workers; ASan/UBSan/leaks25 and TSan25. |
| External processes and truthful artifacts | Native43/host31/external11 process suites, independently checked state/actions/channels/operations/resource/provenance and malformed evidence negatives. |
| Complete public SDK source kit | Actual relocated CPack, custom paths/spaces/removed prefix, one-command run, nine variants plus all56 prior SDK consumers=65; embedding and missing/private/source/config/state/cleanup negatives. |
| Static/full compatibility | Clang analysis of new CLI and full fixture; contract/full148+152 and focused37; frozen ABI/export/schema/default and protected workflow checks. |
| Retained diagnostics and risk | Prior repairs/failures remain unchanged; new sanitizer harness note retains120s timeouts and unchanged121.09s full-run proof. No Runtime deadline relaxed. |
| Final integration | Exact final-head full/all32 names/multiplicity, clean/head/base/review and fetched-tested-tree guards still required before target merge; canonical closure afterward. |

The sanitizer-only300s harness applies only to new complete1024-tick cases9/18;
other new/earlier timeouts and all workloads/assertions remain intact. This is
functional instrumentation overhead, not a controlled-performance claim.
M26-05/M26-06 remain inactive. Human, physical/HIL/RT, Unreal, controlled
performance, signing/release and deployment remain separate.
''')
(e/'commands.md').write_text('''# Reproduction

    ./scripts/agent-verify.sh full
    ctest --test-dir build/agent-quick -R host_adapter_golden_xdma --output-on-failure
    python3 tests/golden_xdma/verify_package.py --work-directory build/m26-04-package
    clang++-14 --analyze -Xanalyzer -analyzer-output=text -std=c++20 -Wall -Wextra -Werror -Irt/include -Icore/include -Iinclude samples/golden_xdma/main.cpp tests/golden_xdma/test_xdma.cpp

Extract retained-logs.tar.gz to inspect every original log and runner;
retained-artifacts.json binds each uncompressed file by size and SHA256.
To reproduce the library caches, configure CMake with build type Debug,
ENABLE_TESTS=OFF, RTFW_BUILD_EXAMPLES=ON, RTFW_BUILD_EXPERIMENTAL=OFF,
RTFW_BUILD_BENCHMARKS=OFF, RTFW_ENABLE_CUDA=OFF, RTFW_ENABLE_XDMA=OFF and
SIM_WERROR=ON. Set SIM_SANITIZERS to the CMake list address;undefined for
build/m26-04r-asan and thread for build/m26-04r-tsan. The retained build-binding
JSON records exact compiler/configuration, library and fixture binary hashes.
The retained sanitizer runner builds Debug/O0 Runtime/CUDA/XDMA libraries with
ASan+UBSan or TSan and the new inline fixture with matching full instrumentation
and-O1. It executes all25 bounded CTest cases, including full1024 owner replay;
only diagnosed before-main mapping failures retry. Functional failures stop.
Commands, flags, exits and all attempts are retained with reviewed source hashes.
No physical or independent-human acceptance follows from these commands.
''')
p=r/'docs/evidence/M26-04-risk-review.md';p.write_text('''# M26-04 final agent risk review

Local disposition: complete; final-head hosted and guarded integration pending.
This is an agent review, not independent human qualification. Full148+152,
focused37, sanitizer25+25/allocation, static and actual CPack65 SDK/embedding/
negative gates pass. Reviewed source hashes and acceptance map are in
M26-04-final-verification. Native drivers, Runtime, public formats/ABI/defaults,
prior kits/tests and protected CI equal the integrated repair baseline.

Remaining risks: owned simulated drivers do not establish physical safe-state,
latency or RT qualification; a host watchdog bounds simulator scheduling only.
Borrowed resources require successful checked cleanup; failed stops retain them.
Trusted replay is original-owner bound; compatible recovery uses paired artifacts.
Artifact hashes establish consistency, not authenticated physical execution.
Prior scheduler-sensitive baseline Windows/benchmark findings remain separate.

No unresolved scoped source finding remains. Require exact final full/all32 and
clean/head/base/no-unresolved-review/fetched-tree equality before integration,
then record canonical closure. M26-05/M26-06 remain separate inactive scopes.

## Historical draft review

'''+p.read_text())
(r/'docs/evidence/M26-04-2026-09-30.md').write_text(f'''# M26-04 local software acceptance

The retained XDMA/combined feature is reconciled with integrated repair283 at
{repair}. Current source/configuration hashes and every retained attempt are in
[M26-04-final-verification](M26-04-final-verification/acceptance.md).

Contract, quick148/full152, focused37, ASan/UBSan/leaks25, TSan25,
allocation/static and actual relocated CPack65 SDK/embedding/negative gates pass.
The [agent risk review](M26-04-risk-review.md) records scope and residual limits.
The [new sanitizer harness note](M26-04-sanitizer-harness.md) explains the
instrumented full1024-tick process budget without changing Runtime deadlines,
prior tests, workloads, owner replay, or assertions. Earlier dated evidence is
historical; its failed attempts remain retained.

Exact-final-head full/all32 and guarded target integration remain required.
Canonical closure records the final tested/merged identities and check results.
M26-05/M26-06 remain inactive; this is simulated native-driver protocol evidence,
not physical/HIL/RT, human, controlled-performance, Unreal or release qualification.
''')
intro='''# M26-04 software locally verified; integration pending

The installed golden XDMA/combined source kit runs actual Runtime sampled
channels and native backend batches with owned simulated drivers, CPU/kernel/
Graph physics, native/host/external execution, full-state parity, owner replay,
checkpoint recovery, faults, safe acknowledgements and bounded ownership.
Full148+152, focused37, ASan/UBSan/leaks25, TSan25, allocation/static and actual
CPack65 SDK/embedding/negative gates pass. See
[evidence](evidence/M26-04-final-verification/acceptance.md) and PR279.
Exact-final-head full/all32 and guarded integration/canonical closure remain.
M26-05 showcase and M26-06 documentation/audit remain inactive; no physical,
RT/human/Unreal/controlled-performance/release claim. Earlier notes are history.

'''
for name in ['CURRENT_STATE.md','HANDOFF.md','roadmap.md']:
 p=r/'docs'/name;p.write_text(intro+p.read_text())
run('python3','tools/check_release_contract.py','--write-hashes')
changed=set(run('git','diff','--name-only').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines())
for p in changed:
 assert any(match(p,q) for q in d['scope']['allowed_paths']),p
 assert not any(match(p,q) for q in d['scope']['forbidden_paths']),p
run('git','add','--',*sorted(changed));run('git','diff','--cached','--check')
with open('/tmp/m26-feature-r4-final-contract.log','w') as f:subprocess.run(['./scripts/agent-verify.sh','contract'],cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
print(run('git','commit','-m','test(sample): complete golden XDMA verification and risk review'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/m26-feature-r4-final-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','origin','agent/m26-04-xdma'),flush=True)
body=f'''Adds the installed golden XDMA/combined source kit: actual Runtime sampled channels and native XDMA/CUDA batches through owned simulated drivers, native/host/external execution, CPU/kernel/Graph parity, originating-owner replay, paired checkpoint recovery, safe acknowledgements and fault/ownership controls.

Local full148+152, focused37, ASan/UBSan/leaks25, TSan25, allocation/static and actual relocated CPack65 SDK/embedding/negatives pass. Final head {head}, tree {tree}. Exact-final-head full/all32 and clean/head/base/review/fetched-tree guards remain required. Every previous failure is retained. Only new long sanitizer harnesses use300s; actual safe8ms, mock watchdog5s, full1024 workloads and every prior test remain fixed.

Preserves integrated repairs280/281/282/283, native/Runtime/public/ABI/default identities and earlier kits/evidence. M26-05/M26-06 remain inactive. No physical/HIL/RT/human/Unreal/controlled-performance/release claim.
''';Path('/tmp/m26-feature-r4-pr.md').write_text(body);p=Path('/tmp/m26-feature-r4-pr-body.json');p.write_text(json.dumps({'body':body}));run('gh','api','--method','PATCH','repos/tranquilWorks/cpp-rt-car/pulls/279','--input',str(p))
