from pathlib import Path
import subprocess,json,collections,hashlib,yaml,fnmatch
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
head,tree=Path('/tmp/m26-feature-r4-final-identity.txt').read_text().splitlines();base=json.loads(Path('/tmp/cpp-m26-04r4-merge.json').read_text())['sha']
assert run('git','rev-parse','HEAD')==head and run('git','rev-parse','HEAD^{tree}')==tree and not run('git','status','--porcelain')
raw=run('gh','api',f'repos/tranquilWorks/cpp-rt-car/commits/{head}/check-runs?per_page=100');Path('/tmp/m26-feature-r4-checks.json').write_text(raw+'\n');checks=json.loads(raw)['check_runs'];old=json.loads(Path('/tmp/cpp-m26-03-checks.json').read_text())['check_runs']
assert len(checks)==32 and all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in checks)
assert collections.Counter(c['name'] for c in checks)==collections.Counter(c['name'] for c in old)
full=Path('/tmp/m26-feature-r4-final-full.log').read_text();assert f'head={head}' in full and 'completed=' in full and all(f'100% tests passed, 0 tests failed out of {n}' in full for n in [148,152])
assert 'PASS complete resumed feature local gates' in Path('/tmp/m26-feature-r4-gates-progress.log').read_text()
assert '100% tests passed, 0 tests failed out of 37' in Path('/tmp/m26-feature-r4-focused.log').read_text()
san=Path('/tmp/m26-feature-r4-sanitize.log').read_text();assert 'PASS asan 25 cases' in san and 'PASS tsan 25 cases' in san
pkg=Path('/tmp/m26-feature-r4-package.log').read_text();assert '100% tests passed, 0 tests failed out of 65' in pkg and 'PASS CPack relocation, one-command execution, full SDK, embedding and negative controls' in pkg
static=Path('/tmp/m26-feature-r4-static.log').read_text();assert static.startswith('COMMAND ') and not '\n'.join(static.splitlines()[1:]).strip()
for p,sha in json.loads((r/'docs/evidence/M26-04-final-verification/reviewed-sources.json').read_text()).items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==sha,p
d=yaml.safe_load((r/'contracts/active-batch.yaml').read_text());assert d['batch']['id']=='M26-04' and d['sources']['baseline_commit']==base
canonical=json.loads(Path('/tmp/cpp-m26-04r4-reactivate-merge.json').read_text())['sha'];assert d['sources']['canonical_revision']==canonical
paths=run('git','diff','--name-only',base).splitlines()
def match(p,q):return p.startswith(q) if q.endswith('/') else fnmatch.fnmatchcase(p,q)
for p in paths:
 assert any(match(p,q) for q in d['scope']['allowed_paths']),p
 assert not any(match(p,q) for q in d['scope']['forbidden_paths']),p
assert not run('git','diff','--name-only',base,'--','rt','samples/golden_system','samples/golden_cuda','.github/workflows/ci.yml','docs/cuda_capabilities.json')
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base
query='{repository(owner:"tranquilWorks",name:"cpp-rt-car"){pullRequest(number:279){headRefOid baseRefOid isDraft mergeable reviewThreads(first:100){nodes{isResolved} pageInfo{hasNextPage}}}}}'
def guard(name):
 raw=run('gh','api','graphql','-f','query='+query);Path('/tmp/m26-feature-r4-'+name+'.json').write_text(raw+'\n');p=json.loads(raw)['data']['repository']['pullRequest']
 assert p['headRefOid']==head and p['baseRefOid']==base and p['mergeable']=='MERGEABLE'
 assert not p['reviewThreads']['pageInfo']['hasNextPage'] and all(t['isResolved'] for t in p['reviewThreads']['nodes'])
 return p
if guard('pre-guard')['isDraft']:run('gh','pr','ready','279','--repo','tranquilWorks/cpp-rt-car')
assert not guard('guard')['isDraft']
p=Path('/tmp/m26-feature-r4-merge-input.json');p.write_text(json.dumps({'sha':head,'merge_method':'squash','commit_title':'M26-04: golden XDMA sampled loopback and verified source kit (#279)'}))
raw=run('gh','api','--method','PUT','repos/tranquilWorks/cpp-rt-car/pulls/279/merge','--input',str(p));Path('/tmp/m26-feature-r4-merge.json').write_text(raw+'\n');m=json.loads(raw);assert m['merged'],m
run('git','fetch','origin','main');assert run('git','rev-parse',m['sha']+'^{tree}')==tree
p=Path('/tmp/m26-feature-r4-pr.md');s=p.read_text()+f'\nMerged at `{m["sha"]}` after all32 exact-final-head checks and exact-head full148+152 plus clean/head/base/review/fetched-tested-tree guards passed. Tested head `{head}`, tree `{tree}`. Complete canonical M26-04 closure next. M26-05/M26-06 remain inactive.\n';p.write_text(s);body=Path('/tmp/m26-feature-r4-pr-body.json');body.write_text(json.dumps({'body':s}));run('gh','api','--method','PATCH','repos/tranquilWorks/cpp-rt-car/pulls/279','--input',str(body));print('MERGED',m['sha'],'tree',tree)
