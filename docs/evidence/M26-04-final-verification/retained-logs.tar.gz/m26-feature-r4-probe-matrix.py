from pathlib import Path
import subprocess,os,json
records=[];env=os.environ.copy();env['TSAN_OPTIONS']='halt_on_error=1';count=0
for case in range(1,19):
 for dispatch in (['reference','cpu','kernel','graph'] if case in [9,18] else [None]):
  args=['/tmp/m26-feature-r4-probe-tsan','--case',str(case)]
  label=f'case{case:02}'+('-'+dispatch if dispatch else '')
  if dispatch:args+=['--dispatch',dispatch,'--reference',f'/tmp/m26-feature-r4-probe-reference-{case}']
  for attempt in range(1,81):
   p=subprocess.run(args,capture_output=True,text=True,env=env,timeout=120);s=p.stdout+p.stderr
   Path(f'/tmp/m26-feature-r4-probe-{label}-attempt{attempt:02}.log').write_text(s)
   records.append(dict(args=args,attempt=attempt,exit=p.returncode));Path('/tmp/m26-feature-r4-probe-matrix-results.json').write_text(json.dumps(records,indent=2)+'\n')
   if p.returncode==0:break
   if 'FATAL: ThreadSanitizer: unexpected memory mapping' in s or (p.returncode==-11 and not s.strip()):continue
   print(label,attempt,p.returncode,s,flush=True);raise SystemExit(1)
  else:raise SystemExit('Loader retry limit')
  count+=1;print('PASS',label,'attempt',attempt,flush=True)
print('PASS remaining',count,'bounded TSan feature parity/replay cases',flush=True)
