import subprocess,json,time,collections
from pathlib import Path
head=Path('/tmp/cpp-m26-04-r4-resumed-identity.txt').read_text().splitlines()[0]
for i in range(150):
 p=subprocess.run(['gh','api',f'repos/tranquilWorks/cpp-rt-car/commits/{head}/check-runs?per_page=100'],capture_output=True,text=True)
 if p.returncode:
  print('API read unavailable',p.stderr.strip(),flush=True);time.sleep(30);continue
 d=json.loads(p.stdout);Path('/tmp/m26-feature-r4-checkpoint-checks-live.json').write_text(p.stdout)
 c=d['check_runs'];print(time.strftime('%H:%M:%S'),dict(collections.Counter((x['status']+'/'+str(x['conclusion'])) for x in c)),flush=True)
 bad=[x for x in c if x['status']=='completed' and x['conclusion']!='success']
 if bad:
  print([(x['name'],x['id'],x['details_url'],x['conclusion']) for x in bad],flush=True);raise SystemExit(1)
 if len(c)==32 and all(x['status']=='completed' and x['conclusion']=='success' for x in c):print('PASS exact32',flush=True);break
 time.sleep(30)
else:raise SystemExit('Still pending')
