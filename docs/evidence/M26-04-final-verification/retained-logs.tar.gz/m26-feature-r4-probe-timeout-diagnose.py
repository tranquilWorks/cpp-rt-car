import subprocess,os,time,json
from pathlib import Path
env=os.environ.copy();env['TSAN_OPTIONS']='halt_on_error=1'
args=['/tmp/m26-feature-r4-probe-tsan','--case','9','--dispatch','cpu','--reference','/tmp/m26-feature-r4-probe-reference-9']
for attempt in range(1,81):
 log=Path(f'/tmp/m26-feature-r4-probe-timeout-repro{attempt:02}.log')
 with log.open('w') as f:
  p=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,env=env)
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:
   print('Live after15sec',p.pid,flush=True)
   with open('/tmp/m26-feature-r4-probe-timeout-backtrace.log','w') as stack:
    subprocess.run(['gdb','-batch','-p',str(p.pid),'-ex','set pagination off','-ex','thread apply all bt 15'],stdout=stack,stderr=subprocess.STDOUT,timeout=20)
   try:p.wait(timeout=105)
   except subprocess.TimeoutExpired:p.kill();p.wait();print('TIMEOUT retained; killed at original120s plus debugger time',flush=True)
 s=log.read_text();print(attempt,p.returncode,s,flush=True)
 if 'FATAL: ThreadSanitizer: unexpected memory mapping' in s or (p.returncode==-11 and not s.strip()):continue
 break
