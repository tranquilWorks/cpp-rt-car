from pathlib import Path
import subprocess,os,json,time
r=Path.cwd()
records=[]
def execute(name,args,env=None,timeout=900):
 p=Path('/tmp/m26-feature-r4-'+name+'.log')
 with p.open('w') as f:
  f.write('COMMAND '+json.dumps([str(a) for a in args])+'\n');f.flush()
  result=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT,env=env,timeout=timeout)
 records.append(dict(name=name,command=list(map(str,args)),exit=result.returncode))
 Path('/tmp/m26-feature-r4-sanitizer-results.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,'exit',result.returncode,flush=True)
 return result.returncode,p.read_text()
for kind,flags in [('asan','address,undefined'),('tsan','thread')]:
 build=r/('build/m26-04r-'+kind)
 code,_=execute(kind+'-libs',['cmake','--build',build,'--target','rtfw_runtime','rtfw_cuda_backend','rtfw_xdma_backend','--parallel','2'])
 if code:raise SystemExit(code)
 executable=Path('/tmp/m26-feature-r4-'+kind)
 code,_=execute(kind+'-compile',['c++','-std=c++20','-g','-O1','-fno-pie','-no-pie','-fsanitize='+flags,'-fno-omit-frame-pointer','-Iinclude','-Irt/include','-Icore/include','tests/golden_xdma/test_xdma.cpp','tests/golden_cuda/allocation.cpp',build/'librtfw_runtime.a',build/'librtfw_cuda_backend.a',build/'librtfw_xdma_backend.a','-pthread','-o',executable])
 if code:raise SystemExit(code)
 env=os.environ.copy();env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1',TSAN_OPTIONS='halt_on_error=1')
 count=0
 for case in range(19):
  for dispatch in (['reference','cpu','kernel','graph'] if case in [9,18] else [None]):
   args=[executable,'--case',case]
   if dispatch:args+=['--dispatch',dispatch,'--reference',f'/tmp/m26-feature-r4-{kind}-reference-{case}']
   label=f'{kind}-case{case:02}'+('-'+dispatch if dispatch else '')
   # Match the repository's bounded CTest case split. Retry only diagnosed
   # loader startup failures, never actual test failures or sanitizer findings.
   for attempt in range(1,81 if kind=='tsan' else 2):
    code,log=execute(f'{label}-attempt{attempt:02}',args,env,timeout=300 if case in [9,18] else 120)
    if code==0:break
    if kind=='tsan' and ('FATAL: ThreadSanitizer: unexpected memory mapping' in log or (code==-11 and len(log.splitlines())==1)):
     continue
    raise SystemExit(code if code>0 else 1)
   else:raise SystemExit('TSan startup retry limit reached')
   count+=1
 print('PASS',kind,count,'cases',flush=True)
print('PASS both complete sanitizer matrices, lifecycle faults and allocation controls',flush=True)
