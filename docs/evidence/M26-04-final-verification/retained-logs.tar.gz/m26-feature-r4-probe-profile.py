import subprocess,os,signal
from pathlib import Path
args=['gdb','-batch','-ex','set pagination off','-ex','set disable-randomization off','-ex','run','-ex','thread apply all bt 12','--args','/tmp/m26-feature-r4-probe-tsan','--case','9','--dispatch','cpu','--reference','/tmp/m26-feature-r4-probe-reference-9']
for attempt in range(1,81):
 with open(f'/tmp/m26-feature-r4-probe-profile{attempt:02}.log','w') as f:
  p=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGINT);p.wait(timeout=20);print('CAPTURED',attempt,flush=True);break
 s=Path(f'/tmp/m26-feature-r4-probe-profile{attempt:02}.log').read_text()
 if 'unexpected memory mapping' in s or '__tsan' in s and 'SIGSEGV' in s:continue
 print('RESULT',attempt,p.returncode,flush=True);break
