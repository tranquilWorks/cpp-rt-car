from pathlib import Path
import subprocess,time
for _ in range(240):
 s=Path('/tmp/m26-feature-r4-gates-progress.log').read_text()
 if 'PASS complete resumed feature local gates' in s:break
 if 'package ' in s and 'package 0' not in s:raise SystemExit('Package failed; inspect retained output')
 time.sleep(10)
else:raise SystemExit('Local feature gates not complete')
for label,args in [('finalize',['python3','/tmp/m26-feature-r4-finalize.py']),('final-full',['./scripts/agent-verify.sh','full'])]:
 with open('/tmp/m26-feature-r4-'+label+'.log','w') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('PASS final feature head full; require exact32 and guarded merge',flush=True)
