#include <cstdio>
extern "C" int __real_main(int,char**);
extern "C" int __wrap_main(int argc,char** argv) { std::fputs("M26_05_MAIN_ENTERED\n",stderr); std::fflush(stderr); return __real_main(argc,argv); }
