from pathlib import Path
import subprocess,time,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
for _ in range(150):
 s=Path('/tmp/cpp-m26-05-plan-control.log').read_text()
 if 'Control plane validation passed.' in s:break
 if '\nFAILED (' in s:raise SystemExit('Control validation failed')
 time.sleep(10)
else:raise SystemExit('Control validation not complete')
with open('/tmp/cpp-m26-05-plan-publish.log','w') as f:p=subprocess.run(['python3','-u','/tmp/cpp-m26-05-plan-publish.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
print('publish',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
head=Path('/tmp/cpp-m26-05-plan-identity.txt').read_text().splitlines()[0]
for _ in range(100):
 p=subprocess.run(['gh','api',f'repos/tranquilWorks/portfolio-control/commits/{head}/check-runs?per_page=100'],capture_output=True,text=True)
 if p.returncode:print('API unavailable; retrying read',flush=True);time.sleep(15);continue
 checks=json.loads(p.stdout)['check_runs']
 if len(checks)==1 and checks[0]['status']=='completed':break
 time.sleep(15)
else:raise SystemExit('Hosted disposition pending')
with open('/tmp/cpp-m26-05-plan-merge-execution.log','w') as f:p=subprocess.run(['python3','/tmp/cpp-m26-05-plan-merge.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
print('merge',p.returncode,flush=True)
raise SystemExit(p.returncode)
