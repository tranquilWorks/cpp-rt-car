from pathlib import Path
import subprocess,json,fnmatch,yaml
root=Path.cwd()
def run(*args):return subprocess.check_output(args,text=True).strip()
assert run('git','branch','--show-current')=='agent/m26-05-showcase'
assert run('git','rev-parse','HEAD')=='6d6dbc98a4f1d6eb438d61cbeecc2a0f1d1ba252'
paths=run('git','ls-files','--modified','--others','--exclude-standard').splitlines();batch=yaml.safe_load(Path('contracts/active-batch.yaml').read_text())
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in batch['scope']['forbidden_paths']),p
run('git','add','--',*paths);run('git','diff','--cached','--check')
print(run('git','commit','-m','feat: add M26-05 golden benchmark fault and control showcase'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m26-05-checkpoint-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','-u','origin','agent/m26-05-showcase'),flush=True)
body='''Add the optional public-SDK golden showcase: fifteen distinct M23 benchmark cases, CPU/simulated CUDA/XDMA/combined execution with native, host and external-controller paths, all thirteen frozen tuning levers and eleven fault campaigns. Independently validate complete state, replay pairing, counters, configuration, source and executable identity before publishing report/fault/coverage artifacts.

The new telemetry-loss campaign measures actual retention pressure, refuses gap/foreign-owner replay before Runtime effects and recovers with a paired fresh owner. Separate task/rate/trace and HAL-copy experiments state their scope; low-capacity failures remain visible. Preserve Runtime/native/prior-kit/test sources, frozen configuration, public ABI/export/schema and default package isolation.

Checkpoint validation: full focused process/13 artifact negatives; ASan/UBSan/leaks2/2; Clang14 static7; actual relocated CPack71 optional SDK consumers, standalone/embedded/steady workflow and missing-input negatives. Full repository profiles and TSan are in progress; all32 exact-final-head hosted checks and guarded target/canonical closure remain required. Retain every failure and correction in docs/evidence/M26-05-2026-09-30.md and its checkpoint logs.

M26-06 remains separate and inactive. No physical, HIL, RT, controlled-performance, human, Unreal or release qualification is added.
'''
Path('/tmp/cpp-m26-05-pr.md').write_text(body)
items=json.loads(run('gh','api','repos/tranquilWorks/cpp-rt-car/pulls?state=open&head=tranquilWorks:agent/m26-05-showcase'));assert len(items)<=1
if items:number=items[0]['number']
else:
 p=Path('/tmp/cpp-m26-05-create.json');p.write_text(json.dumps(dict(title='feat: golden benchmark, fault and control showcase (M26-05)',head='agent/m26-05-showcase',base='main',draft=True,body=body)))
 raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(p));Path('/tmp/cpp-m26-05-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m26-05-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/cpp-rt-car/pull/'+str(number),flush=True)
