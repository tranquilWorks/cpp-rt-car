from pathlib import Path
import subprocess,json,re,time

def call(args):
 for i in range(4):
  p=subprocess.run(args,capture_output=True,text=True,timeout=90)
  if p.returncode==0:return p.stdout
  with open('/tmp/cpp-m26-05-api-errors.log','a') as f:f.write(json.dumps(args)+'\n'+p.stderr+'\n')
  if i<3:time.sleep(5)
 raise RuntimeError(p.stderr)
for label,head in [('first','d196e780d827798709f07890e8cffc117a519967'),('second','745055210668bf20fc8ce2a3bf1d5c912a773cee')]:
 raw=call(['gh','api',f'repos/tranquilWorks/cpp-rt-car/commits/{head}/check-runs?per_page=100']);checks=json.loads(raw);Path('/tmp/cpp-m26-05-'+label+'-superseded-checks.json').write_text(raw)
 for c in checks['check_runs']:
  if c['conclusion']=='failure':
   job=re.search(r'/job/(\d+)',c['details_url'])
   if job:
    out=Path('/tmp/cpp-m26-05-superseded-job-'+job[1]+'.log')
    if not out.exists() or out.stat().st_size<100:out.write_text(call(['gh','api',f'repos/tranquilWorks/cpp-rt-car/actions/jobs/{job[1]}/logs']))
 raw=call(['gh','api',f'repos/tranquilWorks/cpp-rt-car/actions/runs?head_sha={head}&per_page=100']);runs=json.loads(raw);Path('/tmp/cpp-m26-05-'+label+'-superseded-runs.json').write_text(raw)
 for r in runs['workflow_runs']:
  assert r['head_sha']==head and r['head_branch']=='agent/m26-05-showcase'
  if r['status']!='completed':
   # Mutation attempted once; inspect status before any retry.
   p=subprocess.run(['gh','api','--method','POST',f'repos/tranquilWorks/cpp-rt-car/actions/runs/{r["id"]}/cancel'],capture_output=True,text=True,timeout=90)
   print(label,r['id'],r['name'],'cancel exit',p.returncode,p.stdout,p.stderr,flush=True)
