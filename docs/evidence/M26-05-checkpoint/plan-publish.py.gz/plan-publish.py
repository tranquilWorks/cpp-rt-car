from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m26-05-plan-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m26-05-plan'
Path('/tmp/cpp-m26-05-plan-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
run('git','add','--','products/cpp-rt-car/batches/M26-05.yaml','products/cpp-rt-car/README.md','products/cpp-rt-car/CODEX_HANDOFF.md','products/cpp-rt-car/roadmap.yaml');run('git','diff','--cached','--check')
print(run('git','commit','-m','plan(cpp-rt-car): scope M26-05 benchmark fault and control showcase'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m26-05-plan-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m26-05-plan'),flush=True)
body=f'''Scope the owner-requested M26-05 after completed target279/control575. Deliver the fifteen frozen golden M23 benchmark cases, actual finite tuning experiments, fault/control and telemetry-loss evidence, independent machine-readable reporting and an optional installed public-SDK source kit. Preserve all prior source/contracts/ABI/validation; every timing and comparison states its actual scope.

Full local control validation PASS. Exact head `{head}`, tree `{tree}`. Canonical integration precedes target activation. Target full/sanitizer/static/package/all32 exact-head gates and guarded target/canonical closure remain mandatory. Known protected fixture findings are retained separately. M26-06 remains inactive; no physical, human, RT, controlled-performance, Unreal or release qualification is added. Standing scoped publication/merge and control-only completed zero-step infrastructure exception continue.
'''
Path('/tmp/cpp-m26-05-plan-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m26-05-plan'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m26-05-plan-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M26-05 benchmark fault and control showcase','head':'agent/cpp-m26-05-plan','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m26-05-plan-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m26-05-plan-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
