#!/usr/bin/python3
# Local environment control: retry only recorded failures before wrapped main.
import sys,subprocess,os,json,time,hashlib
from pathlib import Path
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
name=Path(sys.argv[0]).name
if name=='test_golden_showcase':exe=root/'build/m26-04r-tsan/tests/golden_showcase'/name
else:exe=root/'build/m26-04r-tsan'/('bench' if name in ('golden_showcase','golden_experiment','golden_telemetry_loss') else 'samples')/('sample_'+name)
marker=b'M26_05_MAIN_ENTERED\n'
for attempt in range(1,101):
 start=time.monotonic();entered=False;output=[]
 proc=subprocess.Popen([str(exe),*sys.argv[1:]],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'TSAN_OPTIONS':'halt_on_error=1'})
 for line in proc.stdout:
  output.append(line)
  if line==marker:entered=True;continue
  if entered:sys.stdout.buffer.write(line);sys.stdout.buffer.flush()
 code=proc.wait();raw=b''.join(output)
 record={'name':name,'args':sys.argv[1:],'attempt':attempt,'entered_main':entered,'exit':code,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'output':raw.decode(errors='replace')}
 with open('/tmp/cpp-m26-05-tsan-attempts.jsonl','a') as f:f.write(json.dumps(record)+'\n')
 if not entered and ((code==66 and b'FATAL: ThreadSanitizer: unexpected memory mapping' in raw) or (code==-11 and not raw)):continue
 if not entered:sys.stdout.buffer.write(raw)
 sys.exit(code if code>=0 else 128-code)
raise SystemExit('TSan pre-main loader retry limit reached')
