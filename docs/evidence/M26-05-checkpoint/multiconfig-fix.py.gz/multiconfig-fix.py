from pathlib import Path
p=Path('samples/golden_showcase/run.py');s=p.read_text().replace('import queue\n','import queue\nimport re\n');start=s.index('def executable(');end=s.index('\ndef peer_benchmark',start)
s=s[:start]+'''def executable(build,name,configuration=None):
    if configuration:a.require(re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',configuration) is not None,'invalid build configuration')
    configs=(configuration,) if configuration else ('Release','Debug','RelWithDebInfo','MinSizeRel')
    found=set()
    for directory,base in ((build,name),(build/'bench','sample_'+name),(build/'samples','sample_'+name)):
        for location in (directory,*(directory/c for c in configs)):
            for suffix in ('','.exe'):
                candidate=location/(base+suffix)
                if candidate.is_file():found.add(candidate.resolve())
    if not found:raise ValueError('missing executable '+name+' for configuration '+str(configuration))
    if len(found)!=1:raise ValueError('ambiguous executable '+name+'; select --config or use a separate build directory')
    return found.pop()
''' +s[end:]
s=s.replace('def execute(build,output,provenance,clock):','def execute(build,output,provenance,clock,configuration=None):').replace('name:executable(build,name) for name in names','name:executable(build,name,configuration) for name in names')
s=s.replace("p.add_argument('--clock',choices=('fake','steady'),default='fake');args=p.parse_args()","p.add_argument('--clock',choices=('fake','steady'),default='fake');p.add_argument('--config');args=p.parse_args()")
s=s.replace("            config=['cmake','-S',HERE,'-B',args.build,'-DCMAKE_BUILD_TYPE=Release']","            args.config=args.config or 'Release'\n            config=['cmake','-S',HERE,'-B',args.build,'-DCMAKE_BUILD_TYPE='+args.config]")
s=s.replace("args.build,'--config','Release','--parallel'","args.build,'--config',args.config,'--parallel'").replace('args.provenance.resolve(),args.clock)','args.provenance.resolve(),args.clock,args.config)');p.write_text(s)
for file in ['samples/golden_showcase/test.py','tests/golden_showcase/process_suite.py']:
 p=Path(file);s=p.read_text().replace('args=p.parse_args()',"p.add_argument('--config');args=p.parse_args()").replace("run.executable(args.build,'golden_showcase')","run.executable(args.build,'golden_showcase',args.config)").replace("args.provenance.resolve(),'fake')","args.provenance.resolve(),'fake',args.config)")
 if 'process_suite' in file:s=s.replace("'--build',args.build],timeout=180)","'--build',args.build]+(['--config',args.config] if args.config else []),timeout=180)")
 p.write_text(s)
for file in ['samples/golden_showcase/report.py','tests/golden_showcase/negative_artifacts.py']:
 p=Path(file);s=p.read_text().replace('args=p.parse_args()',"p.add_argument('--config');args=p.parse_args()").replace('run.executable(args.binaries_build,name)','run.executable(args.binaries_build,name,args.config)').replace('run.executable(args.build,name)','run.executable(args.build,name,args.config)');p.write_text(s)
p=Path('tests/golden_showcase/CMakeLists.txt');s=p.read_text().replace('--provenance "${PROJECT_BINARY_DIR}/golden-showcase-provenance.json")','--provenance "${PROJECT_BINARY_DIR}/golden-showcase-provenance.json" --config "$<CONFIG>")');p.write_text(s)
p=Path('samples/golden_showcase/CMakeLists.txt');s=p.read_text().replace('--provenance "${golden_showcase_provenance}")','--provenance "${golden_showcase_provenance}" --config "$<CONFIG>")');p.write_text(s)
p=Path('tests/golden_showcase/process_suite.py');s=p.read_text();anchor="parent=Path(tempfile.mkdtemp(prefix='showcase acceptance ',dir=args.build));exe="
new="""# Model the actual Windows multi-config layout before launching real binaries.
with tempfile.TemporaryDirectory(prefix='showcase config ') as temporary:
    root=Path(temporary)
    for folder,name in [('Debug','golden_showcase'),('bench/Debug','sample_golden_showcase'),('samples/RelWithDebInfo','sample_golden_controller')]:
        path=root/folder/(name+'.exe');path.parent.mkdir(parents=True,exist_ok=True);path.touch()
        logical='golden_controller' if 'controller' in name else 'golden_showcase'
        a.require(run.executable(root,logical)==path.resolve(),'multi-config executable discovery')
        path.unlink()
    debug=root/'bench/Debug/sample_golden_showcase.exe';debug.touch()
    release=root/'bench/Release/sample_golden_showcase.exe';release.parent.mkdir();release.touch()
    a.require(run.executable(root,'golden_showcase','Debug')==debug.resolve(),'explicit build configuration')
    for selected in (None,'RelWithDebInfo','../Debug'):
        try:run.executable(root,'golden_showcase',selected)
        except ValueError:pass
        else:raise AssertionError('ambiguous/missing/invalid configuration accepted')
parent=Path(tempfile.mkdtemp(prefix='showcase acceptance ',dir=args.build));exe="""
assert anchor in s;s=s.replace(anchor,new);p.write_text(s)
p=Path('samples/golden_showcase/README.md');s=p.read_text()+'''\nUse `--config Debug` or `--config RelWithDebInfo` when selecting an existing\nmulti-configuration build. CTest passes its selected CMake configuration. Without\n`--config`, discovery accepts exactly one matching executable and rejects ambiguous\nbuilds; a requested missing configuration never falls back to another one.\n''';p.write_text(s)
p=Path('docs/golden_showcase.md');s=p.read_text()+'''\nFor multi-configuration generators, `run.py --config Debug` selects the same\nconfiguration for build and all seven executables; `report.py --config Debug`\nselects those exact binaries during revalidation. CTest supplies `$<CONFIG>`.\nWithout an explicit selection, discovery requires a unique matching executable.\nMissing or ambiguous configurations are rejected before benchmark execution.\n''';p.write_text(s)
