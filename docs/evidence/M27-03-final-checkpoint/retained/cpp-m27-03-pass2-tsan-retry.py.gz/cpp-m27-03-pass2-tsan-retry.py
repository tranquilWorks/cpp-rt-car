from pathlib import Path
import subprocess,json,os,time,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');prefix='/tmp/cpp-m27-03-pass2-tsan-retry';bindings=json.loads(Path('/tmp/cpp-m27-03-pass2-gate-source-bindings.json').read_text())
def check():assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
check()
records=[]
for attempt in range(80):
 check();log=Path(prefix+'-%02d.log'%attempt)
 with log.open('w') as f:
  p=subprocess.run(['/tmp/cpp-m27-03-pass2-tsan','--gtest_filter=SimCoreTimingReliability.*:CrossMatrixDeterminism/*FmaOff'],cwd=r,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,TSAN_OPTIONS='halt_on_error=1'),timeout=90)
 records.append(dict(attempt=attempt,exit=p.returncode,log=str(log)));Path(prefix+'-results.json').write_text(json.dumps(records,indent=2)+'\n');check();s=log.read_text()
 if p.returncode==0:
  assert '[  PASSED  ] 8 tests.' in s;print('PASS TSan eight tests; attempts retained',attempt+1,flush=True);break
 if 'FATAL: ThreadSanitizer: unexpected memory mapping' not in s:raise SystemExit('Real failure '+str(log))
else:raise SystemExit('No instrumented run could launch')
