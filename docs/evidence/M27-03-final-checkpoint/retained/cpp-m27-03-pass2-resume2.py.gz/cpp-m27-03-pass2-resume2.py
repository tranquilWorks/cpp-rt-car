from pathlib import Path
import subprocess,json,hashlib,os,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');records=json.loads(Path('/tmp/cpp-m27-03-pass2-gate-results.json').read_text())
inputs=[r/'include/simcore/highres_clock.hpp',r/'rt/include/rt/watchdog.hpp',r/'include/simcore/SimCore.hpp',r/'tests/test_timing_reliability.cpp',r/'tests/test_simcore_determinism.cpp',r/'tests/CMakeLists.txt',*sorted((r/'tests/timing_reliability').glob('*.py')),*sorted((r/'tests/timing_reliability').glob('*.hpp'))]
bindings={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs};assert bindings == json.loads(Path('/tmp/cpp-m27-03-pass2-gate-source-bindings.json').read_text())
def go(label,args,timeout=1800,env=None):
 assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
 log=Path('/tmp/cpp-m27-03-pass2-'+label+'.log');start=time.monotonic()
 with log.open('w') as f:
  f.write('COMMAND '+json.dumps(list(map(str,args)))+'\n');f.flush()
  try:p=subprocess.run(list(map(str,args)),cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=timeout);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 records.append(dict(label=label,command=list(map(str,args)),exit=code,seconds=round(time.monotonic()-start,3),log=str(log)))
 Path('/tmp/cpp-m27-03-pass2-gate-results.json').write_text(json.dumps(records,indent=2)+'\n');print(label,code,flush=True)
 assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
 if code:raise SystemExit(code)
go('contract-refreshed2',['./scripts/agent-verify.sh','contract'])
go('package',['python3','tests/startup_poll_reliability/verify_package.py','--work-directory','build/m27-03-package02'],timeout=7200)
print('PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates',flush=True)
