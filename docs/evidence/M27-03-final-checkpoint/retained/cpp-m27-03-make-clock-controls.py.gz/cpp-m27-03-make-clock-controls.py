from pathlib import Path
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
s='''#!/usr/bin/env python3
"""Actual baseline/current clock and watchdog stop causal controls.

Only temporary copies receive scheduling hooks or private-member visibility.
Clock outlier uses the unmodified public entry point. Exit 49 means the exact
lost-wake diagnostic fired; a generic timeout is never an expected negative.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASELINE = "b60a73b1e9bacd6ace250dfa1d5d51fab862eaa7"
'''
for name,path in [('CLOCK','/tmp/cpp-m27-03-clock-probe.cpp'),('FLOOR','/tmp/cpp-m27-03-clock-floor-baseline/probe.cpp'),('FLOOR_HOOKS','/tmp/cpp-m27-03-clock-floor-baseline/hooks.hpp'),('STOP','/tmp/cpp-m27-03-watchdog-stop-baseline/probe.cpp'),('STOP_HOOKS','/tmp/cpp-m27-03-watchdog-stop-baseline/hooks.hpp')]:s+='\n'+name+' = '+repr(Path(path).read_text())+'\n'
s+='''

def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, required=True)
    parser.add_argument('--compiler', default='c++')
    args = parser.parse_args()
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    records = []
    for kind, source, hooks in [('clock', CLOCK, ''), ('floor', FLOOR, FLOOR_HOOKS), ('stop', STOP, STOP_HOOKS)]:
        path = 'rt/include/rt/watchdog.hpp' if kind == 'stop' else 'include/simcore/highres_clock.hpp'
        baseline = subprocess.check_output(['git', 'show', BASELINE + ':' + path], cwd=ROOT)
        for label, raw in [('baseline', baseline), ('repaired', (ROOT / path).read_bytes())]:
            directory = output / (kind + '-' + label)
            relative = 'rt/watchdog.hpp' if kind == 'stop' else 'simcore/highres_clock.hpp'
            header = directory / relative
            header.parent.mkdir(parents=True)
            text = raw.decode().replace('\\r\\n', '\\n')
            if hooks:
                hook = directory / 'hooks.hpp'
                hook.write_text(hooks)
                text = '#include "' + str(hook) + '"\\n' + text
            if kind == 'floor':
                text = replace_once(text, 'private:', 'public:')
                needle = '        uint64_t last = last_ns_.load();'
                text = replace_once(text, needle, needle + '\\n        floor_probe::after_read(ns);')
            if kind == 'stop':
                text = replace_once(text, 'cv_.wait(lk, [this] { return stop_.load() || armed_; });',
                    'cv_.wait(lk, [this] { const bool value=stop_.load() || armed_; stop_probe::predicate(value); return value; });')
                if label == 'baseline':
                    needle = '        stop_ = true;\\n        cv_.notify_all();'
                    text = replace_once(text, needle, needle + '\\n        stop_probe::notified();')
                else:
                    # Release before acquiring the same predicate mutex. Its
                    # ownership orders stop publication after CV wait registration.
                    needle = '    ~Watchdog() {'
                    text = replace_once(text, needle, needle + '\\n        stop_probe::release=true;')
            header.write_text(text)
            test = directory / 'probe.cpp'
            test.write_text(source)
            exe = directory / 'probe'
            command = [args.compiler, '-std=c++20', '-O1', '-g', '-pthread', '-I' + str(directory), str(test), '-o', str(exe)]
            (directory / 'command.json').write_text(json.dumps(command, indent=2) + '\\n')
            with (directory / 'build.log').open('w') as log:
                subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=60)
            with (directory / 'run.log').open('w') as log:
                result = subprocess.run([str(exe)], stdout=log, stderr=subprocess.STDOUT, timeout=10)
            expected = (49 if kind == 'stop' else 1) if label == 'baseline' else 0
            records.append(dict(kind=kind, label=label, source_path=path, baseline_revision=BASELINE,
                source_sha256=hashlib.sha256(raw).hexdigest(), instrumented_sha256=hashlib.sha256(header.read_bytes()).hexdigest(),
                exit=result.returncode, expected=expected))
            (output / 'results.json').write_text(json.dumps(records, indent=2) + '\\n')
            assert result.returncode == expected, records[-1]
            if kind == 'stop' and label == 'baseline':
                assert 'REPRO: watchdog stop notification lost' in (directory / 'run.log').read_text()
            print(kind, label, result.returncode, flush=True)
    print('PASS clock outlier/publication and watchdog stop causal controls', flush=True)


if __name__ == '__main__':
    main()
'''
(r/'tests/timing_reliability/verify_clock_stop.py').write_text(s)
