#include <gtest/gtest.h>
#include <simcore/SimCore.hpp>

TEST(SimCoreTimingReliability, WatchdogActionsReachTheFinalQuiescentBoundary) {
  SimCore::Settings settings;
  settings.threads = 2;
  settings.hz = 1000;
  settings.maxFrames = 1;
  settings.budgetMonitor = false;
  settings.rateGovernorEnable = false;
  settings.bintraceEnable = true;
  settings.bintraceEventsPerThread = 1024;
  settings.driftLogInterval = 0;
  SimCore sim(settings);
  const auto phase = sim.addPhase("watchdog-handoff");
  sim.addSerialSubsystem(phase, [&](std::int64_t, SimCore::Seconds) {
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
    while (sim.watchdogTrips() == 0 && std::chrono::steady_clock::now() < deadline)
      std::this_thread::yield();
    m27_watchdog::await_callback();
    EXPECT_GT(sim.watchdogTrips(), 0);
    // A trip is immediately visible, but coordinator-owned settings cannot
    // change underneath the active callback. The final boundary must apply it.
    EXPECT_TRUE(sim.limpModeActive());
    EXPECT_TRUE(sim.visualizersEnabled());
    EXPECT_FALSE(sim.broadphaseCoarse());
    EXPECT_EQ(sim.rungActivations(4), 0u);
  });
  sim.run();
  EXPECT_GT(sim.watchdogTrips(), 0);
  EXPECT_FALSE(sim.visualizersEnabled());
  EXPECT_TRUE(sim.broadphaseCoarse());
  EXPECT_EQ(sim.subSteps(), 1);
  for (int rung = 1; rung <= 4; ++rung)
    EXPECT_EQ(sim.rungActivations(rung), 1u);
  std::size_t events = 0;
  for (const auto &event : sim.bintrace().snapshot().events)
    if (event.code == bintrace::EV_WatchdogTrip)
      ++events;
  EXPECT_EQ(events, static_cast<std::size_t>(sim.watchdogTrips()));
}
