#pragma once
#include <atomic>
#include <thread>
namespace m27_watchdog { inline std::atomic<bool> completed{false}; inline void await_callback() {while(!completed.load()) std::this_thread::yield();} }
