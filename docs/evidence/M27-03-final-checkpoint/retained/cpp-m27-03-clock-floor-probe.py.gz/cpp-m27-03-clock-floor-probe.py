from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');d=Path('/tmp/cpp-m27-03-clock-floor-baseline');(d/'simcore').mkdir(parents=True,exist_ok=True)
hooks=d/'hooks.hpp';hooks.write_text('''#pragma once
#include <atomic>
#include <thread>
namespace floor_probe {
inline std::atomic<bool> paused{false}, release{false};
inline void after_read(unsigned long long ns) {
 if(ns==200) {paused=true;while(!release.load()) std::this_thread::yield();}
}
}
''')
s=(r/'include/simcore/highres_clock.hpp').read_text();s='#include "'+str(hooks)+'"\n'+s;s=s.replace('private:','public:');a='        uint64_t last = last_ns_.load();';assert s.count(a)==1;s=s.replace(a,a+'\n        floor_probe::after_read(ns);');(d/'simcore/highres_clock.hpp').write_text(s)
p=d/'probe.cpp';p.write_text('''#include <simcore/highres_clock.hpp>
#include <cstdio>
int main() {
 HighResClock::last_ns_=100;
 unsigned long long delayed=0;
 std::thread older([&] {delayed=HighResClock::ensure_monotonic(200);});
 while(!floor_probe::paused.load()) std::this_thread::yield();
 const auto newer=HighResClock::ensure_monotonic(300);
 floor_probe::release=true;older.join();
 const auto following=HighResClock::ensure_monotonic(250);
 std::printf("delayed=%llu completed=%llu following=%llu\\n",delayed,static_cast<unsigned long long>(newer),static_cast<unsigned long long>(following));
 return following>newer && following>delayed?0:1;
}
''');args=['c++','-std=c++20','-O1','-g','-pthread','-I'+str(d),str(p),'-o',str(d/'probe')];(d/'command.json').write_text(json.dumps(args,indent=2)+'\n');subprocess.run(args,check=True)
with (d/'run.log').open('w') as f:p=subprocess.run([str(d/'probe')],stdout=f,stderr=subprocess.STDOUT,timeout=5)
print('exit',p.returncode);print((d/'run.log').read_text())
