from pathlib import Path
import subprocess
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');d=Path('/tmp/cpp-m27-03-clock-prototype');(d/'simcore').mkdir(parents=True,exist_ok=True)
s=(r/'include/simcore/highres_clock.hpp').read_text();s=s.replace('#include <cstdint>','#include <cstdint>\n#include <cmath>\n#include <limits>')
a=s.index('        if (tsc_ok_.load(std::memory_order_relaxed)) {');b=s.index('        return ensure_monotonic(ns_ref);\n    }',a)
s=s[:a]+'''        if (tsc_ok_.load(std::memory_order_relaxed)) {
            // Never publish an unchecked counter sample into the monotonic floor.
            // An outlier would otherwise keep fallback time artificially ahead.
            if (!tsc_reader_ || !std::isfinite(tsc_freq_) || tsc_freq_ <= 0.0) {
                tsc_ok_.store(false);
                return ensure_monotonic(ns_ref);
            }
            const uint64_t t = tsc_reader_();
            if (t < tsc_start_) {
                tsc_ok_.store(false);
                return ensure_monotonic(ns_ref);
            }
            const double elapsed = static_cast<double>(t - tsc_start_) * 1e9 / tsc_freq_;
            if (!std::isfinite(elapsed) || elapsed >= static_cast<double>(
                    std::numeric_limits<uint64_t>::max() - ref_start_ns_)) {
                tsc_ok_.store(false);
                return ensure_monotonic(ns_ref);
            }
            const uint64_t ns = ref_start_ns_ + static_cast<uint64_t>(elapsed);
            // Preserve the existing 1ms bound, checking before every publication.
            const uint64_t difference = ns > ns_ref ? ns - ns_ref : ns_ref - ns;
            if (difference > 1000000) {
                tsc_ok_.store(false);
                return ensure_monotonic(ns_ref);
            }
            return ensure_monotonic(ns);
        }
'''+s[b:]
a=s.index('        uint64_t last = last_ns_.load();');b=s.index('\n    }',a)
s=s[:a]+'''        uint64_t last = last_ns_.load();
        for (;;) {
            const uint64_t next = ns > last ? ns : last + 1;
            if (last_ns_.compare_exchange_weak(last, next))
                return next;
        }'''+s[b:];s=s.replace('    static inline std::atomic<uint64_t> calls_{0};\n','');(d/'simcore/highres_clock.hpp').write_text(s)
args=['c++','-std=c++20','-O1','-g','-I'+str(d),'/tmp/cpp-m27-03-clock-probe.cpp','-pthread','-o',str(d/'probe')];subprocess.run(args,check=True)
with (d/'run.log').open('w') as f:p=subprocess.run([str(d/'probe')],stdout=f,stderr=subprocess.STDOUT,timeout=5)
print('clock prototype exit',p.returncode);print((d/'run.log').read_text())
# Use the same ordered-publication witness against the proposed header copy.
s=Path('/tmp/cpp-m27-03-clock-floor-probe.py').read_text().replace("d=Path('/tmp/cpp-m27-03-clock-floor-baseline')", "d=Path('/tmp/cpp-m27-03-clock-floor-prototype')").replace("(r/'include/simcore/highres_clock.hpp').read_text()", "Path('/tmp/cpp-m27-03-clock-prototype/simcore/highres_clock.hpp').read_text()")
p=Path('/tmp/cpp-m27-03-clock-floor-prototype.py');p.write_text(s);subprocess.run(['python3',str(p)],check=True)
