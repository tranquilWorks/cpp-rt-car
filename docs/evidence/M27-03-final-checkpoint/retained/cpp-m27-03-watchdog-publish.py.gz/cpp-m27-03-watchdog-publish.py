from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-watchdog-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m27-03-watchdog'
Path('/tmp/cpp-m27-03-watchdog-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
paths=['products/cpp-rt-car/'+x for x in ['README.md','CODEX_HANDOFF.md','batches/M27-03.yaml']]
changed=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed,set(paths))
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','plan(cpp-rt-car): amend M27-03 experimental watchdog handoff'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-03-watchdog-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m27-03-watchdog'),flush=True)
body=f"""Amend active M27-03 after required TSan found the experimental watchdog callback racing frame advancement and degradation settings in the unchanged determinism workload. Permit only coordinator handoff through the existing atomic pending channel and quiescent teardown in the already-allowed SimCore header. Preserve thresholds, original tests, Runtime/benchmark sources, ABI/defaults and qualification boundaries. Require causal baseline negatives and fresh full/sanitizer/static/package/all32 exact-head gates before target integration. Process-global clock/construction limitations remain explicit.

Full local control validation PASS at `{head}`, tree `{tree}`. Standing guarded publication/integration authorization continues; later M27 cards stay inactive.
"""
Path('/tmp/cpp-m27-03-watchdog-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m27-03-watchdog'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m27-03-watchdog-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M27-03 experimental watchdog handoff','head':'agent/cpp-m27-03-watchdog','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m27-03-watchdog-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m27-03-watchdog-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
