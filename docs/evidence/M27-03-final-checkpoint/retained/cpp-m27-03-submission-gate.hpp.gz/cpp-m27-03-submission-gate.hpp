#include <atomic>
#include <cstdio>
#include <thread>
#include <rt/runtime.hpp>
namespace submission_gate {
inline rt::HalV2CommandTimelineExtension original{}, table{};
inline std::atomic<bool> released{false}, completed{false};
inline rt::HalV2BackendRegistration wrap(rt::HalV2BackendRegistration registration) {
  original=*registration.command_timeline;table=original;
  table.submit=[](void* p,const rt::DeviceCommandBatch* batch) {
    while(!released.load()) std::this_thread::yield();
    const auto result=original.submit(p,batch);
    completed=true;
    return result;
  };
  registration.command_timeline=&table;return registration;
}
inline void release() {
  released=true;
  while(!completed.load()) std::this_thread::yield();
}
}
