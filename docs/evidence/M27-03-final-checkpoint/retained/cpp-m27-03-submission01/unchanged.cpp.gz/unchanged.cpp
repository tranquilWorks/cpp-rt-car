#include <cstdio>
#include "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/bench/providers/runtime_cases/device.cpp"
int main() {
  namespace b=rtfw::benchmark::runtime;
  using b::Family;
  constexpr b::Case catalog[]{
#include "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/bench/providers/runtime_cases/catalog.inc"
  };
  for(const auto& c:catalog) if(std::string_view(c.id)=="device-timeout-nonpublication") {
    for(unsigned i=0;i<1000;++i) {
      try {b::detail::DeviceFailure f(c);if(!f.run(i).correct) return 2;}
      catch(const std::exception& e) {std::fprintf(stderr,"iteration=%u %s\n",i,e.what());return 1;}
    }
    std::puts("PASS 1000 original fixture invocations");return 0;
  }
  return 3;
}
