from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-stop-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m27-03-stop'
Path('/tmp/cpp-m27-03-stop-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
paths=['products/cpp-rt-car/'+x for x in ['README.md','CODEX_HANDOFF.md','batches/M27-03.yaml']]
changed=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed,set(paths))
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','plan(cpp-rt-car): amend M27-03 experimental clock and watchdog shutdown'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-03-stop-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m27-03-stop'),flush=True)
body=f"""Repair two demonstrated remaining experimental lifetime/timekeeping causes. Watchdog destruction can lose its stop wake; allow its one non-SDK helper to publish stop under the existing mutex. Debugger-owned unchanged workload runs also stall in cadence sleep after bad clock calibration. A mocked counter proves invalid samples poison the monotonic floor after fallback. Allow only highres_clock.hpp sample validation before publication and proper atomic monotonic publication, retaining the existing1ms drift threshold, calibration and default TSC selection. Concurrent initialization remains separate.

Preserve supported Runtime, all other rt/include files, original tests/deadlines/workloads, ABIs and default SDK isolation. Require independently failing baseline controls, fresh focused/sanitizer/static/package/full and all32 exact-head gates. Earlier failures remain retained; no claim that every historical timeout has one cause. Full local control validation PASS at `{head}`, tree `{tree}`. Standing scoped publication/integration authority persists; M27-04..08 stay inactive.
"""
Path('/tmp/cpp-m27-03-stop-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m27-03-stop'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m27-03-stop-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M27-03 experimental clock and watchdog shutdown','head':'agent/cpp-m27-03-stop','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m27-03-stop-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m27-03-stop-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
