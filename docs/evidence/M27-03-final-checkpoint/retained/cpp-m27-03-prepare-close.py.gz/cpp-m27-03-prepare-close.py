from pathlib import Path
s=Path('/tmp/cpp-m27-02-close.py').read_text().replace('m27-02','m27-03').replace('M27-02','M27-03').replace('(152,156)','(152,157)').replace('2026-09-30','2026-10-01')
a=s.index("intro=f'''");b=s.index("for name in ['README.md'",a)
s=s[:a]+'''intro=f\'''# M27-03 delivered; M27-04 through08 remain planned

[Target PR{number}](https://github.com/tranquilWorks/cpp-rt-car/pull/{number}) merged at
`{sha}` after all32 exact-head hosted records succeeded at `{head}`.
Fetched/tested tree `{tree}` matches; clean/head/base/no-unresolved-review guards passed.
Canonical activation590 and cause-driven amendments591/592 are integrated.
No target/local functional gate was waived.

Experimental SimCore now waits for worker initialization before frame reuse and
for every dispatched worker to return before shared metadata/counters/reduction
storage reuse. Watchdog callbacks publish only atomic state; coordinator frame
completion logs and applies every pending trip, including the final frame.
Watchdog shutdown publishes stop under its condition-variable predicate mutex.
The clock validates each sample before monotonic publication using the existing
1ms drift bound; an atomic compare/exchange loop prevents stale floor overwrite.
Calibration/default selection and original workloads/deadlines remain unchanged.
Actual baseline negative controls establish each claimed cause independently.

Fresh focused53, unchanged10-repeat2/4/8-thread matrix and Runtime owner lifecycle,
startup/dispatch/watchdog/clock/shutdown causal controls, ASan/UBSan/leaks and TSan,
Clang14 analysis, contract, actual default/optional relocated CPack and71 SDK
consumers pass. Final exact-head full portable152/strict157 and all32 hosted
records pass with exact baseline names/multiplicity. Earlier timeouts, actual
sanitizer races, failed fixture drafts and startup mapping failures remain retained.
No supported Runtime, benchmark, original test, ABI or native source was changed.

The M23 submission fixture classification remains bounded: withholding public
submit entry can expire the original1ms deadline with no backend submissions,
violating the fixture's unchanged exact-one assumption. The original historical
provider_error lacks predicate detail, so its precise cause remains unresolved.
Concurrent process-global experimental clock initialization remains unsupported;
new owner tests serialize construction on each execution thread. No claim that
all historical experimental timeouts have one cause or are universally eliminated.

M27-01 through03 software are delivered. M27-04 non-RT exporters,05 fuzz/security,
06 test-identity provenance tooling,07 native golden XDMA host preparation and
08 platform/migration/portable soak remain planned/inactive until selected.
M19 actual licensed Unreal, M18 physical/RT, controlled performance, unfamiliar
consumer review and production signing/release/deployment remain separate.
Full local control validation, hosted disposition and guarded closure integration
are recorded in the closure PR.

## Historical checkpoints

\'''
'''+s[b:]
a=s.index("assert '    completed_batches:");b=s.index("p=b/'automation.json'",a)
s=s[:a]+'''assert '    completed_batches: [M27-01, M27-02]' in part and '    next_batch: M27-03' in part
part=part.replace('    completed_batches: [M27-01, M27-02]','    completed_batches: [M27-01, M27-02, M27-03]',1).replace('    next_batch: M27-03','    next_batch: null',1)
lines=part.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('    planning_note:'));lines[i]=f'    planning_note: M27-01/02 complete. M27-03 target{number} merged {sha}, tested head {head}/tree {tree}; full152+157/all32 exact-head, causal baseline negatives,53 focused,10 repeats,sanitizers/static/CPack71SDK pass. Experimental worker/watchdog/clock boundaries repaired; historical benchmark precise cause and concurrent clock initialization remain explicit limitations. M27-04..08 inactive; external qualification, Unreal, human, signing/release/deployment remain.'
p.write_text(s[:start]+'\\n'.join(lines)+'\\n'+s[end:])
'''+s[b:]
a=s.index("row['reason']=");b=s.index(";p.write_text(json.dumps(d",a)
s=s[:a]+'''row['reason']=f'Delivered in target PR{number} at {sha} after full local and all32 exact-head gates; roadmap marks complete. Later M27 cards remain manual/inactive until selected. Historical benchmark precise cause and concurrent experimental clock initialization remain explicit limitations.' '''.rstrip()+s[b:]
s=s.replace("print('Prepared M27-03 closure; M27-03..08 remain planned/inactive')","print('Prepared M27-03 closure; M27-04..08 remain planned/inactive')")
Path('/tmp/cpp-m27-03-close.py').write_text(s)
