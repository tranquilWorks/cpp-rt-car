from pathlib import Path
import subprocess,json,re
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');d=Path('/tmp/cpp-m27-03-watchdog-baseline');(d/'simcore').mkdir(parents=True,exist_ok=True)
hooks=d/'hooks.hpp';hooks.write_text('''#pragma once
#include <atomic>
#include <thread>
namespace m27_watchdog { inline std::atomic<bool> completed{false}; inline void await_callback() {while(!completed.load()) std::this_thread::yield();} }
''')
s=subprocess.check_output(['git','show','b60a73b1e9bacd6ace250dfa1d5d51fab862eaa7:include/simcore/SimCore.hpp'],cwd=r,text=True)
s='#include "'+str(hooks)+'"\n'+s
s=re.sub(r'#include "([^"]+)"',lambda m:m[0] if m[1].startswith('/') else '#include "'+str(r/'include/simcore'/m[1])+'"',s)
a='        });\n    initThreads();';assert s.count(a)==1;s=s.replace(a,'          m27_watchdog::completed=true;\n'+a);(d/'simcore/SimCore.hpp').write_text(s)
s='#include <gtest/gtest.h>\n#include <simcore/SimCore.hpp>\n'+Path('/tmp/cpp-m27-03-watchdog-test.txt').read_text();a='    EXPECT_GT(sim.watchdogTrips(), 0);';assert s.count(a)==1;s=s.replace(a,'    m27_watchdog::await_callback();\n'+a);p=d/'watchdog_test.cpp';p.write_text(s)
args=json.loads(Path('/tmp/cpp-m27-03-baseline-tsan-command2.json').read_text());args.remove('-fsanitize=thread');args[1:1]=['-I'+str(d)];args[args.index('tests/test_simcore_determinism.cpp')]=str(p);args[-1]=str(d/'probe');(d/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (d/'build.log').open('w') as f:subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
with (d/'run.log').open('w') as f:p=subprocess.run([args[-1]],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=10)
print('exit',p.returncode);print((d/'run.log').read_text())
