#include <cstdio>
#include "/tmp/cpp-m27-03-gated-device.cpp"
int main() {
  namespace b=rtfw::benchmark::runtime;
  using b::Family;
  constexpr b::Case catalog[]{
#include "/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/bench/providers/runtime_cases/catalog.inc"
  };
  for(const auto& c:catalog) if(std::string_view(c.id)=="device-timeout-nonpublication") {
    for(unsigned i=0;i<1;++i) {
      try { b::detail::DeviceFailure f(c);const auto result=f.run(i);if(!result.correct) return 2; }
      catch(const std::exception& e) {std::fprintf(stderr,"iteration=%u %s\n",i,e.what());return 1;}
    }
    std::puts("1000 unchanged timeout-fixture invocations passed");return 0;
  }
  return 3;
}
