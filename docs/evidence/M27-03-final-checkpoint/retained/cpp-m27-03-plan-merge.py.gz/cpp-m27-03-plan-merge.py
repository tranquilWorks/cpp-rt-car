import json,subprocess,re
from pathlib import Path
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*args):return subprocess.check_output(args,cwd=root,text=True).strip()
head,tree=Path('/tmp/cpp-m27-03-plan-identity.txt').read_text().splitlines();base=Path('/tmp/cpp-m27-03-plan-base.txt').read_text().strip();pr=int(Path('/tmp/cpp-m27-03-plan-pr-number.txt').read_text())
assert run('git','rev-parse','HEAD')==head and run('git','rev-parse','HEAD^{tree}')==tree and not run('git','status','--porcelain')
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-plan-control.log').read_text()
checks=json.loads(run('gh','api',f'repos/tranquilWorks/portfolio-control/commits/{head}/check-runs?per_page=100'));Path('/tmp/cpp-m27-03-plan-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
assert len(checks['check_runs'])==1;c=checks['check_runs'][0];assert c['head_sha']==head and c['name']=='validate' and c['status']=='completed'
rid=re.search(r'/runs/(\d+)',c['details_url']).group(1)
jobs=json.loads(run('gh','api',f'repos/tranquilWorks/portfolio-control/actions/runs/{rid}/jobs?per_page=100'));Path('/tmp/cpp-m27-03-plan-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');assert len(jobs['jobs'])==1;j=jobs['jobs'][0];assert j['head_sha']==head and j['status']=='completed'
if c['conclusion']=='success':
 assert j['conclusion']=='success';disposition='Hosted validation passed.'
else:
 assert c['conclusion']=='failure' and j['conclusion']=='failure' and j['steps']==[]
 disposition=f"Hosted run{rid}/job{j['id']} completed failure with steps=[]; recorded UNPERFORMED under the standing control-only infrastructure exception. No target or local functional gate was waived."
p=Path('/tmp/cpp-m27-03-plan-pr.md');s=p.read_text()+f'\nFull local control validation PASSED (exit0). Exact head `{head}`, tree `{tree}`. '+disposition+' Expected head/base, clean state, review threads and fetched merge-tree equality are enforced before closure.\n';p.write_text(s);body=Path('/tmp/cpp-m27-03-plan-body.json');body.write_text(json.dumps({'body':s}));run('gh','api','--method','PATCH',f'repos/tranquilWorks/portfolio-control/pulls/{pr}','--input',str(body))
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base
run('git','fetch','origin',f'refs/pull/{pr}/merge');assert run('git','rev-parse','FETCH_HEAD^{tree}')==tree
query='{repository(owner:"tranquilWorks",name:"portfolio-control"){pullRequest(number:'+str(pr)+'){headRefOid baseRefOid isDraft mergeable reviewThreads(first:100){nodes{isResolved} pageInfo{hasNextPage}}}}}'
def guard(name):
 raw=run('gh','api','graphql','-f','query='+query);Path('/tmp/cpp-m27-03-plan-'+name+'.json').write_text(raw+'\n');p=json.loads(raw)['data']['repository']['pullRequest'];assert p['headRefOid']==head and p['baseRefOid']==base and p['mergeable']=='MERGEABLE'
 assert not p['reviewThreads']['pageInfo']['hasNextPage'] and all(t['isResolved'] for t in p['reviewThreads']['nodes'])
 return p
if guard('pre-guard')['isDraft']:run('gh','pr','ready',str(pr),'--repo','tranquilWorks/portfolio-control')
assert not guard('guard')['isDraft']
payload=Path('/tmp/cpp-m27-03-plan-merge-input.json');payload.write_text(json.dumps({'sha':head,'merge_method':'squash','commit_title':f'plan(cpp-rt-car): activate M27-03 experimental worker dispatch lifetime (#{pr})'}))
raw=run('gh','api','--method','PUT',f'repos/tranquilWorks/portfolio-control/pulls/{pr}/merge','--input',str(payload));Path('/tmp/cpp-m27-03-plan-merge.json').write_text(raw+'\n');m=json.loads(raw);assert m['merged'],m
run('git','fetch','origin','main');assert run('git','rev-parse',m['sha']+'^{tree}')==tree
s+=f"\nMerged at `{m['sha']}`; fetched merged tree equals tested tree `{tree}`. Expected head/base, clean state and no unresolved review-thread guards passed. M27-03 plan is integrated; activate and complete only M27-03 submission and experimental timeout investigation with all required local/hosted/package/guarded integration gates. No later batch or qualification activity is activated.\n";p.write_text(s);body.write_text(json.dumps({'body':s}));run('gh','api','--method','PATCH',f'repos/tranquilWorks/portfolio-control/pulls/{pr}','--input',str(body))
print('MERGED',m['sha'],'tree',tree,disposition)
