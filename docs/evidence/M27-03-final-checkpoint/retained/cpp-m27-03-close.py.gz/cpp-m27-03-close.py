from pathlib import Path
import json,subprocess,collections,gzip
r=Path.cwd();b=r/'products/cpp-rt-car';target=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
merge=json.loads(Path('/tmp/cpp-m27-03-merge.json').read_text());assert merge['merged'];sha=merge['sha'];head,tree=Path('/tmp/cpp-m27-03-final-identity.txt').read_text().splitlines();number=int(Path('/tmp/cpp-m27-03-pr-number.txt').read_text())
checks=json.loads(Path('/tmp/cpp-m27-03-checks.json').read_text())['check_runs'];old=json.loads(Path('/tmp/m26-feature-r4-checks.json').read_text())['check_runs']
assert len(checks)==32 and all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in checks)
assert collections.Counter(c['name'] for c in checks)==collections.Counter(c['name'] for c in old)
full_path=Path('/tmp/cpp-m27-03-passing-full.txt').read_text().strip();full=Path(full_path).read_text();assert f'head={head}' in full and 'completed=' in full and all(f'100% tests passed, 0 tests failed out of {n}' in full for n in (152,157))
assert subprocess.check_output(['git','rev-parse',sha+'^{tree}'],cwd=target,text=True).strip()==tree
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
intro=f'''# M27-03 delivered; M27-04 through08 remain planned

[Target PR{number}](https://github.com/tranquilWorks/cpp-rt-car/pull/{number}) merged at
`{sha}` after all32 exact-head hosted records succeeded at `{head}`.
Fetched/tested tree `{tree}` matches; clean/head/base/no-unresolved-review guards passed.
Canonical activation590 and cause-driven amendments591/592 plus source-binding amendment593 are integrated.
No target/local functional gate was waived.

Experimental SimCore now waits for worker initialization before frame reuse and
for every dispatched worker to return before shared metadata/counters/reduction
storage reuse. Watchdog callbacks publish only atomic state; coordinator frame
completion logs and applies every pending trip, including the final frame.
Watchdog shutdown publishes stop under its condition-variable predicate mutex.
The clock validates each sample before monotonic publication using the existing
1ms drift bound; an atomic compare/exchange loop prevents stale floor overwrite.
Calibration/default selection and original workloads/deadlines remain unchanged.
Actual baseline negative controls establish each claimed cause independently.

Fresh focused53, unchanged10-repeat2/4/8-thread matrix and Runtime owner lifecycle,
startup/dispatch/watchdog/clock/shutdown causal controls, ASan/UBSan/leaks and TSan,
Clang14 analysis, contract, actual default/optional relocated CPack and71 SDK
consumers pass. Final exact-head full portable152/strict157 and all32 hosted
records pass with exact baseline names/multiplicity. Earlier timeouts, actual
sanitizer races, failed fixture drafts and startup mapping failures remain retained.
No supported Runtime, benchmark, original test, ABI or native source was changed.

The M23 submission fixture classification remains bounded: withholding public
submit entry can expire the original1ms deadline with no backend submissions,
violating the fixture's unchanged exact-one assumption. The original historical
provider_error lacks predicate detail, so its precise cause remains unresolved.
Concurrent process-global experimental clock initialization remains unsupported;
new owner tests serialize construction on each execution thread. No claim that
all historical experimental timeouts have one cause or are universally eliminated.

M27-01 through03 software are delivered. M27-04 non-RT exporters,05 fuzz/security,
06 test-identity provenance tooling,07 native golden XDMA host preparation and
08 platform/migration/portable soak remain planned/inactive until selected.
M19 actual licensed Unreal, M18 physical/RT, controlled performance, unfamiliar
consumer review and production signing/release/deployment remain separate.
Full local control validation, hosted disposition and guarded closure integration
are recorded in the closure PR.

## Historical checkpoints

'''
for name in ['README.md','CODEX_HANDOFF.md']:
 p=b/name;p.write_text(intro+p.read_text())
p=b/'roadmap.yaml';s=p.read_text();start=s.index('  - id: M27\n');end=s.index('\ndeferred:',start);part=s[start:end]
assert '    completed_batches: [M27-01, M27-02]' in part and '    next_batch: M27-03' in part
part=part.replace('    completed_batches: [M27-01, M27-02]','    completed_batches: [M27-01, M27-02, M27-03]',1).replace('    next_batch: M27-03','    next_batch: null',1)
lines=part.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('    planning_note:'));lines[i]=f'    planning_note: M27-01/02 complete. M27-03 target{number} merged {sha}, tested head {head}/tree {tree}; full152+157/all32 exact-head, causal baseline negatives,53 focused,10 repeats,sanitizers/static/CPack71SDK pass. Experimental worker/watchdog/clock boundaries repaired; historical benchmark precise cause and concurrent clock initialization remain explicit limitations. M27-04..08 inactive; external qualification, Unreal, human, signing/release/deployment remain.'
p.write_text(s[:start]+'\n'.join(lines)+'\n'+s[end:])
p=b/'automation.json';d=json.loads(p.read_text());row=next(x for x in d['batches'] if x['id']=='M27-03');row['reason']=f'Delivered in target PR{number} at {sha} after full local and all32 exact-head gates; roadmap marks complete. Later M27 cards remain manual/inactive until selected. Historical benchmark precise cause and concurrent experimental clock initialization remain explicit limitations.';p.write_text(json.dumps(d,indent=2)+'\n')
e=b/'evidence/M27-03-closure-2026-10-01';e.mkdir(parents=True,exist_ok=False)
for p in sorted(Path('/tmp').glob('cpp-m27-03-*')):
 if p.is_file() and p.suffix in ('.log','.json','.jsonl','.txt') and 'close-' not in p.name:
  (e/(p.name.removeprefix('cpp-m27-03-')+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
(e/'final-full.log.gz').write_bytes(gzip.compress(Path(full_path).read_bytes(),mtime=0))
for name in ['reviewed-sources.json','installed-evidence.json','risk-review.md']:(e/name).write_bytes((target/'docs/evidence/M27-03-final-checkpoint'/name).read_bytes())
(e/'acceptance.md').write_bytes((target/'docs/evidence/M27-03-2026-10-01.md').read_bytes())
(e/'closure.md').write_text(intro.split('## Historical checkpoints')[0].rstrip()+'\n')
Path('/tmp/cpp-m27-03-close-base.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
print('Prepared M27-03 closure; M27-04..08 remain planned/inactive')
