from pathlib import Path
import subprocess,json,time,collections
head=Path('/tmp/cpp-m27-03-final-identity.txt').read_text().splitlines()[0]
expected=json.loads(Path('/tmp/m26-feature-r4-checks.json').read_text())['check_runs']
last=None
for attempt in range(240):
 p=subprocess.run(['gh','api',f'repos/tranquilWorks/cpp-rt-car/commits/{head}/check-runs?per_page=100'],capture_output=True,text=True,timeout=90)
 if p.returncode:
  with open('/tmp/cpp-m27-03-ci-api-errors.log','a') as f:f.write(p.stderr)
  time.sleep(15);continue
 data=json.loads(p.stdout);Path('/tmp/cpp-m27-03-ci-latest.json').write_text(json.dumps(data,indent=2)+'\n');checks=data['check_runs']
 count=collections.Counter(c['status']+':'+str(c['conclusion']) for c in checks)
 if count!=last:print(dict(count),flush=True);last=count
 failed=[dict(name=c['name'],id=c['id'],url=c['details_url'],conclusion=c['conclusion']) for c in checks if c['status']=='completed' and c['conclusion']!='success']
 if failed:
  Path('/tmp/cpp-m27-03-ci-failures.json').write_text(json.dumps(failed,indent=2)+'\n');print('FAILED',failed,flush=True);raise SystemExit(1)
 if len(checks)==32 and all(c['status']=='completed' and c['conclusion']=='success' for c in checks):
  assert all(c['head_sha']==head for c in checks);assert collections.Counter(c['name'] for c in checks)==collections.Counter(c['name'] for c in expected);print('PASS all32 exact-head hosted checks with baseline names/multiplicity',flush=True);break
 time.sleep(30)
else:raise SystemExit('Hosted checks remain incomplete')
