from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
out=Path('/tmp/cpp-m27-03-repaired-schedule');(out/'simcore').mkdir(parents=True,exist_ok=True)
s=(r/'include/simcore/SimCore.hpp').read_text();s='#include "/tmp/cpp-m27-03-schedule-hooks.hpp"\n'+s
# Sibling quoted includes must resolve exactly as in the original directory.
import re
s=re.sub(r'#include "([^"]+)"',lambda m:'#include "'+str(r/'include/simcore'/m[1])+'"' if not m[1].startswith('/') else m[0],s)
s=s.replace('std::uint64_t localToken = dispatchToken_.load(std::memory_order_acquire);','std::uint64_t localToken = dispatchToken_.load(std::memory_order_acquire);\n    m27_schedule::worker_ready(workerCount_);')
s=s.replace('      processActiveRange();','      m27_schedule::worker_enter(localToken,workerCount_);\n      processActiveRange();\n      m27_schedule::worker_exit(localToken,workerCount_);')
s=s.replace('        nextChunk_.store(0, std::memory_order_relaxed);','        m27_schedule::before_publish(frame_,workerCount_);\n        nextChunk_.store(0, std::memory_order_relaxed);\n        m27_schedule::reset(frame_,workerCount_,remaining_,nextChunk_);')
s=s.replace('        dispatchToken_.fetch_add(1, std::memory_order_acq_rel);','        dispatchToken_.fetch_add(1, std::memory_order_acq_rel);\n        m27_schedule::published(frame_,workerCount_);')
s=s.replace('  void waitForRangeWorkers() {', '  void waitForRangeWorkers() {\n    m27_schedule::quiescence(frame_,workerCount_);')
(out/'simcore/SimCore.hpp').write_text(s)
args=json.loads(Path('/tmp/cpp-m27-03-baseline-tsan-command2.json').read_text());args.remove('-fsanitize=thread');args[1:1]=['-I'+str(out)];args[-1]='/tmp/cpp-m27-03-repaired-schedule-test'
Path('/tmp/cpp-m27-03-repaired-schedule-command.json').write_text(json.dumps(args,indent=2))
with open('/tmp/cpp-m27-03-repaired-schedule-build.log','w') as f:p=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT)
print('build',p.returncode,flush=True)
if p.returncode:raise SystemExit(p.returncode)
with open('/tmp/cpp-m27-03-repaired-schedule-run.log','w') as f:p=subprocess.run([args[-1],'--gtest_filter=CrossMatrixDeterminism/*4ThreadsFmaOff'],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=15)
print('run',p.returncode,flush=True);print(Path('/tmp/cpp-m27-03-repaired-schedule-run.log').read_text())
