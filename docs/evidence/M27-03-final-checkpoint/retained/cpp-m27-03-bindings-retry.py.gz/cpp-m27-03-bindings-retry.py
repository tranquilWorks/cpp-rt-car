from pathlib import Path
import subprocess,time,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
for _ in range(100):
 if 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-bindings-control.log').read_text():break
 time.sleep(5)
else:raise SystemExit('Local control still incomplete')
for label in ['merge']:
 if label=='merge':
  head=Path('/tmp/cpp-m27-03-bindings-identity.txt').read_text().splitlines()[0]
  for _ in range(100):
   p=subprocess.run(['gh','api',f'repos/tranquilWorks/portfolio-control/commits/{head}/check-runs?per_page=100'],cwd=r,capture_output=True,text=True,timeout=90)
   if p.returncode==0:
    c=json.loads(p.stdout)['check_runs']
    if len(c)==1 and c[0]['status']=='completed':break
   time.sleep(15)
  else:raise SystemExit('Hosted still incomplete')
 with open('/tmp/cpp-m27-03-bindings-'+label+'.log','w') as f:p=subprocess.run(['python3','/tmp/cpp-m27-03-bindings-'+label+'.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
