from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-plan-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m27-03-plan'
Path('/tmp/cpp-m27-03-plan-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
paths=['products/cpp-rt-car/'+x for x in ['automation.json','milestones/M27.md','README.md','CODEX_HANDOFF.md','roadmap.yaml','batches/M27-03.yaml']]
changed=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed,set(paths))
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','plan(cpp-rt-car): activate M27-03 experimental worker dispatch lifetime'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-03-plan-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m27-03-plan'),flush=True)
body=f"""Activate M27-03 after completed target287/control589. The unchanged 1500-frame/5000-element Linux baseline hangs at 8-thread FMA-off. TSan identifies worker startup and shared range-metadata races. A controlled old-order schedule reproduces counter underflow and lost progress at 4 threads. Repair only experimental readiness and dispatch lifetime; preserve supported Runtime, benchmarks, all original tests, settings, deadlines, ABIs and support claims.

Trace the retained device-timeout-nonpublication benchmark finding separately. Unestablished causes remain unresolved. Full local control validation PASS for head `{head}`, tree `{tree}`. Require deterministic baseline negatives, focused/sanitizer/static/package/full and all32 exact-head target gates plus guarded integration and canonical closure. M27-04..08 remain inactive. No target/local gate waiver or external qualification claim.
"""
Path('/tmp/cpp-m27-03-plan-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m27-03-plan'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m27-03-plan-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M27-03 experimental worker dispatch lifetime','head':'agent/cpp-m27-03-plan','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m27-03-plan-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m27-03-plan-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
