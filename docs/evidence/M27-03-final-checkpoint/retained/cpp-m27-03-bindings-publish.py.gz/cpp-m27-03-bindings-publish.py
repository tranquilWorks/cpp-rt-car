from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-bindings-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m27-03-bindings'
Path('/tmp/cpp-m27-03-bindings-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
paths=['products/cpp-rt-car/batches/M27-03.yaml']
changed=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed,set(paths))
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','plan(cpp-rt-car): bind M27-03 private source hashes'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-03-bindings-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m27-03-bindings'),flush=True)
body=f"""Permit the existing docs/cuda_capabilities.json product-source hashes to track M27-03's scoped rt/include/rt/watchdog.hpp repair. The mandatory contract gate rejects stale hashes; inventory, coverage statuses, support claims and all other scope are unchanged. Parent amendments590/591/592 is merged, and a controlled baseline reproduces the experimental watchdog shutdown lost wake. Full local control validation PASS at `{head}`, tree `{tree}`. All target/local gates remain mandatory; the standing completed zero-step control-only exception is unchanged.
"""
Path('/tmp/cpp-m27-03-bindings-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m27-03-bindings'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m27-03-bindings-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M27-03 required private source bindings','head':'agent/cpp-m27-03-bindings','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m27-03-bindings-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m27-03-bindings-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
