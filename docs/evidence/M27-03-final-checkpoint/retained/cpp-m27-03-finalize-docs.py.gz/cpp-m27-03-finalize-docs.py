from pathlib import Path
import json,subprocess,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
assert 'PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates' in Path('/tmp/cpp-m27-03-pass2-gates-progress.log').read_text()
intro='''# M27-03 implementation and focused verification complete

Only M27-03 is selected. Canonical plans590/591/592/593 are integrated.
Experimental SimCore now waits for initialized workers and completed dispatches,
consumes atomic watchdog trips at frame completion, joins callbacks before teardown,
and synchronizes watchdog stop with its wait predicate. Clock samples are validated
before publication with the existing1ms drift threshold; atomic publication prevents
stale callers from lowering the monotonic floor. Calibration/default selection,
original workloads/deadlines, supported Runtime, native implementations and ABIs
remain unchanged. Actual baseline negative controls establish each claimed cause.

Fresh53 focused tests, unchanged ten-repeat matrix/lifecycle workload, all causal
controls, ASan/UBSan/leaks, TSan, Clang14 analysis, contract and actual relocated
CPack/default/optional71 SDK consumers pass. Prior failures, sanitizer startup
failures and silent crashes with unknown cause remain retained. Fresh exact-head
full portable152/strict157, all32 hosted records and guarded integration/canonical
closure remain required and are recorded in the associated final PR/closure.
See [M27-03 evidence](evidence/M27-03-2026-10-01.md).

The unchanged M23 benchmark can violate its exact-one-submission assumption when
the original1ms deadline expires before backend submission; its historical precise
cause remains unresolved. Concurrent process-global experimental clock initialization
remains a limitation. M27-04 exporters,05 fuzz/security,06 provenance tooling,
07 XDMA host preparation and08 migration/soak remain inactive. Physical/HIL/RT,
licensed Unreal, controlled performance, unfamiliar-consumer acceptance and
production signing/release/deployment remain separate obligations.

## Historical checkpoints

'''
for name in ['CURRENT_STATE.md','HANDOFF.md','roadmap.md']:
 p=r/'docs'/name;s=p.read_text();assert s.startswith('# M27-03');p.write_text(intro+s.split('## Historical checkpoints\n\n',1)[1])
p=r/'docs/evidence/M27-03-2026-10-01.md';s=p.read_text();s=s.replace('Status: implementation and focused causal checks in progress; full local,\nhosted and integration gates are not yet complete.','Status: implementation and focused/sanitizer/static/package checks complete.\nFresh exact-head full, hosted and guarded integration gates are tracked in the\nfinal PR and canonical closure; this precommit record does not assert their result.')
s+='''

## Final precommit validation

Final code passed53 focused GTests and all ten repetitions of the unchanged
original2/4/8-thread FMA-off workload plus Runtime owner lifecycle test in94.317s,
within the unchanged180s investigation bound. Startup and dispatch controls each
require actual baseline failures at2/4/8threads and unchanged repaired hash tests.
Watchdog handoff requires the four baseline assertion failures and corrected pass.
Clock outlier/monotonic floor controls each fail baseline1 and pass corrected0;
watchdog lost-wake control exits49 on baseline and joins with exit0 after repair.
These diagnostics instrument copies only and do not modify production hooks.

ASan/UBSan with leak detection and TSan each pass all eight selected tests (five
new plus three unchanged determinism tests). TSan initially failed to launch with
unexpected mappings and also exited-11 with empty logs; the silent crash causes
are unknown, retained and never counted as passes. The eventual complete run is
retry2/attempt5,11.062s, with no reported data race. Header/new/original test code
was instrumented; existing dependency archives were reused, so this is bounded
sanitizer evidence, not a claim of fully instrumented dependency libraries.
Clang14 analysis of the new fixture and included experimental headers passed.

The first contract attempt correctly rejected stale release/source hashes. Control
binding amendment593 permits only the existing watchdog product-source digest
refresh; coverage inventories/statuses/support claims stay unchanged. Its initial
hosted validation failed on unrelated onboarding-test temporary .git cleanup,
followed by missing-repository subtests. Failed logs are retained; unchanged-head
hosted validation subsequently passed before the guarded amendment merge.
Release/source contract passes after reviewed digests are refreshed.

Actual default and optional CPack archives were extracted to paths with spaces;
original install prefixes were removed. Independent public startup/poll consumers,
all71 preserved optional SDK consumers, private-path checks and missing-SDK
negative validation pass. No experimental header or dependency leaks into the
default SDK. Installed commands, input hashes and test logs are retained.

Final source hashes, exact commands, exit codes, raw prior failures, causal-copy
sources, sanitizer attempts, scope comparison and risk review are under
`M27-03-final-checkpoint/`. Baseline source remains available at the bound Git
revision. The separate submission classification has1000 ordinary passes and
one controlled original-predicate failure; it does not close the historical exact
cause. Protected supported Runtime/native/benchmark/original tests/ABIs and prior
evidence are unchanged. Rollback reverts only this batch's three experimental
header corrections and additive regressions/wiring/docs; no migration is required.

Remaining integration gates: fresh exact-final-head `./scripts/agent-verify.sh full`
(portable152/strict157), all32 hosted records with exact baseline names/multiplicity,
clean/head/base/no-unresolved-review/fetched-merge-tree guards, then canonical
closure. Final disposition and any further failed attempts belong to the PR and
canonical closure evidence. No local/target gate may be waived. Later batches
and external qualification obligations remain separate.
''';p.write_text(s)
for cmd in [['python3','tools/generate_sdk_docs.py'],['python3','tools/generate_golden_audit.py'],['python3','tools/check_release_contract.py','--write-hashes']]:subprocess.run(cmd,cwd=r,check=True)
