#include <simcore/highres_clock.hpp>
#include <atomic>
#include <cstdio>
#include <chrono>
static std::atomic<unsigned> reads{0};
static std::uint64_t reader() {
  const auto n=reads.fetch_add(1);
  return n<2 ? static_cast<std::uint64_t>(n+1)*1000 : 1'000'000'000ULL;
}
int main() {
 HighResClock::init(reader);
 const auto first=HighResClock::now();
 for(unsigned i=0;i<5000;++i) (void)HighResClock::now();
 const auto after=HighResClock::now();
 const auto reference=static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());
 std::printf("first=%llu after=%llu reference=%llu ahead=%llu tsc=%d\n",static_cast<unsigned long long>(first),static_cast<unsigned long long>(after),static_cast<unsigned long long>(reference),static_cast<unsigned long long>(after>reference?after-reference:0),HighResClock::using_tsc());
 return !HighResClock::using_tsc() && after<=reference+1'000'000 ? 0:1;
}
