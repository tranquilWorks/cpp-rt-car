#pragma once
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>
namespace stop_probe {
inline std::atomic<bool> checked{false}, release{false}, finished{false};
inline void predicate(bool value) {
 if(!value && !checked.exchange(true)) while(!release.load()) std::this_thread::yield();
}
inline void notified() {std::fprintf(stderr,"stop notification while wait predicate remains held\n");release=true;}
}
