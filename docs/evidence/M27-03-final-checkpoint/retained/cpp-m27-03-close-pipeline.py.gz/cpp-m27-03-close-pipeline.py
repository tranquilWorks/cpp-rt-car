from pathlib import Path
import subprocess,time,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def go(label,args):
 with open('/tmp/cpp-m27-03-close-'+label+'.log','w') as f:p=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='agent/cpp-m27-03-close'
go('control',['./scripts/validate-control-plane.sh'])
go('publish',['python3','/tmp/cpp-m27-03-close-publish.py'])
head=Path('/tmp/cpp-m27-03-close-identity.txt').read_text().splitlines()[0]
for n in range(100):
 p=subprocess.run(['gh','api',f'repos/tranquilWorks/portfolio-control/commits/{head}/check-runs?per_page=100'],text=True,capture_output=True,timeout=90)
 if p.returncode:print('Hosted read unavailable; retrying',flush=True);time.sleep(15);continue
 checks=json.loads(p.stdout)['check_runs']
 if len(checks)==1 and checks[0]['status']=='completed':break
 time.sleep(15)
else:raise SystemExit('Control hosted disposition still pending')
go('merge-execution',['python3','/tmp/cpp-m27-03-close-merge.py'])
print('PASS canonical closure integrated',flush=True)
