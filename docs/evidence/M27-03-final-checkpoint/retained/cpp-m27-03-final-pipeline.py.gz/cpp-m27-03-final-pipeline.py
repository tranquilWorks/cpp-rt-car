from pathlib import Path
import subprocess,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
for _ in range(360):
 if 'PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates' in Path('/tmp/cpp-m27-03-pass2-gates-progress.log').read_text():break
 time.sleep(5)
else:raise SystemExit('Package acceptance incomplete')
for label,args in [
 ('finalize-docs',['python3','/tmp/cpp-m27-03-finalize-docs.py']),
 ('checkpoint',['python3','/tmp/cpp-m27-03-checkpoint.py']),
 ('final-contract',['./scripts/agent-verify.sh','contract']),
 ('publish',['python3','/tmp/cpp-m27-03-publish.py'])]:
 with open('/tmp/cpp-m27-03-'+label+'.log','w') as f:p=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('Published scoped final candidate; exact-head full and hosted gates next',flush=True)
