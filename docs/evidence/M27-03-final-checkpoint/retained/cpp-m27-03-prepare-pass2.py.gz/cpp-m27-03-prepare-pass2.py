from pathlib import Path
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
with (r/'docs/evidence/M27-03-2026-10-01.md').open('a') as f:f.write('''

## Clock and shutdown causes found during combined validation

The first combined candidate passed48 focused tests but failed the unchanged
10-repeat matrix at repetition2, 8ThreadsFmaOff, with exit124 after180seconds.
This failed gate is retained. A debugger launched as parent of its own test
process captured frame382 sleeping21.420160ms against a1ms period, with a TSC
conversion coefficient80458805089.947205. This coefficient is calibration
state, not an actual CPU-frequency or performance measurement. The clock waited
4096reads before checking drift. A controlled public-reader outlier independently
showed an artificially future timestamp remaining in last_ns after fallback.
A separate scheduling control proves a delayed caller can overwrite a newer
monotonic floor. Both actual baseline controls fail and proposed repairs pass.

The experimental watchdog also has a lost shutdown notification: stopping and
notifying without its predicate mutex lets an idle worker begin waiting after
the notification, leaving destruction blocked. A held false predicate reproduces
this on the actual baseline source; a diagnostic exits49. Acquiring the existing
mutex to publish stop makes the controlled repaired destructor join normally.

Canonical amendment592 merged at80bb2a957bac2ed80dd63cd06a218e68b0879f74,
blob4e37a41f4527045f2cbf3b1db50745cbcd247ee5, after local and actual hosted
validation. The three production headers are SimCore.hpp, highres_clock.hpp and
rt/watchdog.hpp. The latter is experimental and is not the supported Runtime
watchdog implementation. Supported rt/src and every other rt/include file remain
unchanged. Clock samples now reject backward, nonfinite, out-of-range and greater
than1ms drift before publication; the existing calibration/default TSC selection
and threshold remain. The monotonic floor uses one compare/exchange loop.
Concurrent initialization remains unsupported by this repair. All new combined
gates below must be fresh; previous partial passes do not close acceptance.
''')
with (r/'docs/architecture.md').open('a') as f:f.write('''

The experimental clock validates each counter sample before publishing a
monotonic floor. Backward, nonfinite, unrepresentable or greater-than1ms-drift
samples select steady-clock fallback; calibration and default TSC selection are
unchanged. A compare/exchange loop prevents stale concurrent callers from
lowering the floor. This does not make process-global initialization concurrent.
The experimental watchdog publishes its stop predicate under the same mutex
used by its condition-variable wait, preventing a shutdown notification from
being lost before the worker sleeps. Neither header is part of the default SDK
or the supported Runtime implementation.
''')
s=Path('/tmp/cpp-m27-03-gates.py').read_text().replace("inputs=[r/'include/simcore/SimCore.hpp',", "inputs=[r/'include/simcore/highres_clock.hpp',r/'rt/include/rt/watchdog.hpp',r/'include/simcore/SimCore.hpp',")
s=s.replace('/tmp/cpp-m27-03-', '/tmp/cpp-m27-03-pass2-').replace('m27-03-package01','m27-03-package02').replace(':MemoryPlan.*',':MemoryPlan.*:HighResClock.*:HighResClockIntegration.*')
s=s.replace('/tmp/cpp-m27-03-pass2-repaired-tsan-command.json','/tmp/cpp-m27-03-repaired-tsan-command.json')
needle="args=json.loads(Path('/tmp/cpp-m27-03-repaired-tsan-command.json').read_text());"
s=s.replace(needle,"go('clock-stop-final',['python3','tests/timing_reliability/verify_clock_stop.py','--output-directory','/tmp/cpp-m27-03-pass2-clock-stop-final'],timeout=180)\n"+needle)
Path('/tmp/cpp-m27-03-pass2-gates.py').write_text(s)
