from pathlib import Path
import subprocess,json,re
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');d=Path('/tmp/cpp-m27-03-wait-diagnostic');(d/'simcore').mkdir(parents=True,exist_ok=True)
s=(r/'include/simcore/SimCore.hpp').read_text();s=re.sub(r'#include "([^"]+)"',lambda m:'#include "'+str(r/'include/simcore'/m[1])+'"',s)
s=s.replace('  void waitForRangeWorkers() {','  void waitForRangeWorkers() {\n    const auto diagnostic_start=std::chrono::steady_clock::now();')
s=s.replace('    while (rangeWorkers_.load(std::memory_order_acquire) != 0)\n      std::this_thread::yield();','''    while (rangeWorkers_.load(std::memory_order_acquire) != 0) {
      if(std::chrono::steady_clock::now()-diagnostic_start>std::chrono::seconds(2)) {
        std::fprintf(stderr,"WAIT workers: ready=%zu pending=%zu chunks=%zu next=%zu epoch=%llu\\n",readyWorkers_.load(),rangeWorkers_.load(),remaining_.load(),nextChunk_.load(),static_cast<unsigned long long>(dispatchToken_.load()));std::fflush(stderr);std::_Exit(45);
      }
      std::this_thread::yield();
    }''')
s=s.replace('      const auto scheduled = watchdog_->trips();','      const auto scheduled = watchdog_->trips();\n      const auto diagnostic_start=std::chrono::steady_clock::now();')
s=s.replace('      while (watchdogTrips_.load(std::memory_order_acquire) != scheduled)\n        std::this_thread::yield();','''      while (watchdogTrips_.load(std::memory_order_acquire) != scheduled) {
        if(std::chrono::steady_clock::now()-diagnostic_start>std::chrono::seconds(2)) {
          std::fprintf(stderr,"WAIT watchdog: scheduled=%d completed=%d pending=%d\\n",scheduled,watchdogTrips_.load(),watchdogTripPending_.load());std::fflush(stderr);std::_Exit(46);
        }
        std::this_thread::yield();
      }''')
s=s.replace('        while (remaining_.load(std::memory_order_acquire) > 0) {','''        const auto diagnostic_start=std::chrono::steady_clock::now();
        while (remaining_.load(std::memory_order_acquire) > 0) {
          if(std::chrono::steady_clock::now()-diagnostic_start>std::chrono::seconds(2)) {
            std::fprintf(stderr,"WAIT chunks: ready=%zu pending=%zu chunks=%zu next=%zu epoch=%llu\\n",readyWorkers_.load(),rangeWorkers_.load(),remaining_.load(),nextChunk_.load(),static_cast<unsigned long long>(dispatchToken_.load()));std::fflush(stderr);std::_Exit(47);
          }''')
s=s.replace('    if (now < nextTarget_) {','''    if (now < nextTarget_) {
      if(nextTarget_-now>10'000'000'000ULL) {
        std::fprintf(stderr,"WAIT clock: now=%llu target=%llu difference=%llu\\n",static_cast<unsigned long long>(now),static_cast<unsigned long long>(nextTarget_),static_cast<unsigned long long>(nextTarget_-now));std::fflush(stderr);std::_Exit(48);
      }''')
(d/'simcore/SimCore.hpp').write_text(s)
args=json.loads(Path('/tmp/cpp-m27-03-baseline-tsan-command2.json').read_text());args.remove('-fsanitize=thread');args[1:1]=['-I'+str(d),'-DLOG_ENABLED','-DPROF_ENABLED','-DLOG_DEFAULT_LEVEL=2'];args[-1]=str(d/'probe');(d/'command.json').write_text(json.dumps(args,indent=2)+'\n')
with (d/'build.log').open('w') as f:subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
with (d/'run.log').open('w') as f:p=subprocess.run([args[-1],'--gtest_filter=CrossMatrixDeterminism/*FmaOff','--gtest_repeat=20'],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print('exit',p.returncode);print('\n'.join((d/'run.log').read_text().splitlines()[-12:]))
