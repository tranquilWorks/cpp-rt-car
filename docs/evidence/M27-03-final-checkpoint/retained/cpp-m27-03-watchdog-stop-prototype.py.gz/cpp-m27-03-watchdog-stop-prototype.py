from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');d=Path('/tmp/cpp-m27-03-watchdog-stop-prototype');(d/'rt').mkdir(parents=True,exist_ok=True)
hooks=d/'hooks.hpp';hooks.write_text('''#pragma once
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <thread>
namespace stop_probe {
inline std::atomic<bool> checked{false}, release{false}, finished{false};
inline void predicate(bool value) {
 if(!value && !checked.exchange(true)) while(!release.load()) std::this_thread::yield();
}
inline void notified() {std::fprintf(stderr,"stop notification while wait predicate remains held\\n");release=true;}
}
''')
s=(r/'rt/include/rt/watchdog.hpp').read_text();s=s.replace('        stop_ = true;\n        cv_.notify_all();','        {\n            std::lock_guard<std::mutex> lock(m_);\n            stop_ = true;\n        }\n        cv_.notify_all();');s='#include "'+str(hooks)+'"\n'+s
old='cv_.wait(lk, [this] { return stop_.load() || armed_; });';assert s.count(old)==1;s=s.replace(old,'cv_.wait(lk, [this] { const bool value=stop_.load() || armed_; stop_probe::predicate(value); return value; });')
old='    ~Watchdog() {';assert s.count(old)==1;s=s.replace(old,old+'\n        stop_probe::release=true;');(d/'rt/watchdog.hpp').write_text(s)
p=d/'probe.cpp';p.write_text('''#include <rt/watchdog.hpp>
#include <memory>
int main() {
 auto watchdog=std::make_unique<rt::Watchdog>(std::chrono::hours(24),std::chrono::hours(24),[]{});
 while(!stop_probe::checked.load()) std::this_thread::yield();
 std::thread monitor([] {
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(2);
  while(!stop_probe::finished.load()) {
   if(std::chrono::steady_clock::now()>deadline) {std::fprintf(stderr,"REPRO: watchdog stop notification lost before condition-variable wait; join cannot complete\\n");std::_Exit(49);}
   std::this_thread::yield();
  }
 });
 watchdog.reset();stop_probe::finished=true;monitor.join();std::puts("watchdog stop joined");
}
''')
args=['c++','-std=c++20','-O1','-g','-pthread','-I'+str(d),str(p),'-o',str(d/'probe')];(d/'command.json').write_text(json.dumps(args,indent=2)+'\n');subprocess.run(args,check=True)
with (d/'run.log').open('w') as f:p=subprocess.run([str(d/'probe')],stdout=f,stderr=subprocess.STDOUT,timeout=10)
print('exit',p.returncode);print((d/'run.log').read_text())
