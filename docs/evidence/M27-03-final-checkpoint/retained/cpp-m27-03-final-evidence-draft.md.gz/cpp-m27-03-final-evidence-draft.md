M27-03 acceptance update to apply only after every referenced gate completes:
- Narrow production change: experimental SimCore.hpp only, readiness and dispatch
  acknowledgement, atomic watchdog notification + coordinator final-frame handoff,
  joined watchdog teardown. Supported Runtime/benchmarks/native sources unchanged.
- Original baseline actual repeat hangs at6th8-thread test (exit124); TSan reports
  startup/active metadata races. Source-copy scheduling controls: startup and
  dispatch baseline failures2/4/8, repaired exact original workload positives.
- Additional unchanged8-thread TSan failure proves watchdog frame/settings race;
  actual baseline callback-completion control fails4 assertions; repaired passes.
- Original benchmark fixture1000 passes, public submit-entry preemption control
  terminal1/submission0/provider1/copied0 triggersoriginalpredicate failure after
  releasing callback for cleanup. Original hostedprovider_error exactcause still
  unknown; unchanged fixture remains open. No Runtime repairclaim.
- Failednewfixture concurrentclockinit and wrongthreadTLSbinding remain retained.
  Stagedsame-threadconstruction supports concurrentrun, but doesn'trepairglobal
  clockinit. No claim every experimentalcombination is fixed.
- Focused48 tests pass; six-test focusedTSan pass aftermappinglaunchfailures. Fresh
  final gatespipeline stillrunning; don'tclaim latersteps prematurely.
