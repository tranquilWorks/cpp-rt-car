from pathlib import Path
import json,gzip,hashlib,subprocess,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');out=r/'docs/evidence/M27-03-final-checkpoint';out.mkdir(exist_ok=False)
assert 'PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates' in Path('/tmp/cpp-m27-03-pass2-gates-progress.log').read_text()
assert 'PASS TSan eight tests' in Path('/tmp/cpp-m27-03-pass2-tsan-retry2-progress.log').read_text()
records=[]
for root in sorted(Path('/tmp').glob('cpp-m27-03-*')):
 paths=[root] if root.is_file() else sorted(root.rglob('*')) if root.is_dir() else []
 for p in paths:
  if not p.is_file() or p.is_symlink() or p.suffix not in ('.log','.json','.txt','.py','.cpp','.hpp','.md','.plist'):continue
  if p.stat().st_size>20_000_000:raise RuntimeError('Unexpected large text artifact '+str(p))
  raw=p.read_bytes();relative=p.relative_to('/tmp');dest=out/'retained'/str(relative.parent)/(relative.name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0))
  records.append(dict(original=str(p),retained=str(dest.relative_to(out)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(out/'retained-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'risk-review.md').write_bytes(Path('/tmp/cpp-m27-03-risk-review-draft.md').read_bytes())
bindings=json.loads(Path('/tmp/cpp-m27-03-pass2-gate-source-bindings.json').read_text());assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items());(out/'reviewed-sources.json').write_text(json.dumps(bindings,indent=2)+'\n')
paths=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=r,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines());batch=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in batch['scope']['forbidden_paths']),p
protected=['rt/src','bench','abi','VERSION.txt','LICENSE','tests/test_simcore_determinism.cpp','tests/test_command_batch.cpp','tests/test_benchmark_runtime.cpp','tests/test_highres_clock.cpp','tests/test_highres_clock_integration.cpp','.github/workflows']
for path in protected:assert not subprocess.check_output(['git','diff','--name-only','b60a73b1e9bacd6ace250dfa1d5d51fab862eaa7','--',path],cwd=r,text=True).strip(),path
(out/'scope-review.json').write_text(json.dumps(dict(canonical=batch['sources']['canonical_revision'],baseline=batch['sources']['baseline_commit'],changed_paths=sorted(paths),protected_unchanged=protected),indent=2)+'\n')
# Installed package reports and logs, with binaries represented by original manifests.
package=r/'build/m27-03-package02'
installed=[]
for p in sorted(package.rglob('*')):
 if p.is_file() and p.suffix in ('.log','.json','.txt','.md'):
  raw=p.read_bytes();dest=out/'installed'/(str(p.relative_to(package))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));installed.append(dict(path=str(p.relative_to(package)),sha256=hashlib.sha256(raw).hexdigest()))
workspace=Path((package/'relocation-directory.txt').read_text().strip())
for p in sorted(workspace.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 if 'independent tests' in p.parts or p.name in ('compile_commands.json','provenance.json','LastTest.log','CTestTestfile.cmake','CMakeCache.txt'):
  raw=p.read_bytes();dest=out/'installed-workspace'/(str(p.relative_to(workspace))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));installed.append(dict(workspace_path=str(p.relative_to(workspace)),sha256=hashlib.sha256(raw).hexdigest()))
(out/'installed-evidence.json').write_text(json.dumps(installed,indent=2)+'\n')
print('Retained artifacts',len(records),'installed',len(installed))
