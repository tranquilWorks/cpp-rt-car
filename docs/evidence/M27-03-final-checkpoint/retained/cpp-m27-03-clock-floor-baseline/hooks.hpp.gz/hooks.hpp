#pragma once
#include <atomic>
#include <thread>
namespace floor_probe {
inline std::atomic<bool> paused{false}, release{false};
inline void after_read(unsigned long long ns) {
 if(ns==200) {paused=true;while(!release.load()) std::this_thread::yield();}
}
}
