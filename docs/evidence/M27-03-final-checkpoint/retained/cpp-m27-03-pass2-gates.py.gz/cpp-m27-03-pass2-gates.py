from pathlib import Path
import subprocess,json,hashlib,os,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');records=[]
inputs=[r/'include/simcore/highres_clock.hpp',r/'rt/include/rt/watchdog.hpp',r/'include/simcore/SimCore.hpp',r/'tests/test_timing_reliability.cpp',r/'tests/test_simcore_determinism.cpp',r/'tests/CMakeLists.txt',*sorted((r/'tests/timing_reliability').glob('*.py')),*sorted((r/'tests/timing_reliability').glob('*.hpp'))]
bindings={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs};Path('/tmp/cpp-m27-03-pass2-gate-source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
def go(label,args,timeout=1800,env=None):
 assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
 log=Path('/tmp/cpp-m27-03-pass2-'+label+'.log');start=time.monotonic()
 with log.open('w') as f:
  f.write('COMMAND '+json.dumps(list(map(str,args)))+'\n');f.flush()
  try:p=subprocess.run(list(map(str,args)),cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=timeout);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 records.append(dict(label=label,command=list(map(str,args)),exit=code,seconds=round(time.monotonic()-start,3),log=str(log)))
 Path('/tmp/cpp-m27-03-pass2-gate-results.json').write_text(json.dumps(records,indent=2)+'\n');print(label,code,flush=True)
 assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
 if code:raise SystemExit(code)
go('focused-configure',['cmake','-S','.', '-B','build/agent-full','-DCMAKE_BUILD_TYPE=RelWithDebInfo','-DENABLE_TESTS=ON','-DRTFW_BUILD_EXPERIMENTAL=ON','-DENABLE_RAPIDCHECK=ON','-DSIM_SANITIZERS=','-DSIM_WERROR=ON'])
go('focused-build',['cmake','--build','build/agent-full','--target','simcore_tests','--parallel','2'])
go('focused',['build/agent-full/tests/simcore_tests','--gtest_filter=SimCoreTimingReliability.*:CrossMatrixDeterminism/*:DeterministicReduction.*:BudgetMonitor.*:LimpMode.*:PhaseGraph.*:StaticPhaseGraph.*:RtWatchdog.*:SmallArrayBalance.*:ChunkAutotune.*:TraceNoAlloc.*:MemoryPlan.*:HighResClock.*:HighResClockIntegration.*'])
go('repeated',['build/agent-full/tests/simcore_tests','--gtest_filter=CrossMatrixDeterminism/*FmaOff:CommandBatch.RepeatedSubmissionLifecyclesKeepIndependentOwnersDrained','--gtest_repeat=10'],timeout=180)
go('schedules-final',['python3','tests/timing_reliability/verify_schedules.py','--build-directory','build/agent-full','--output-directory','/tmp/cpp-m27-03-pass2-schedules-final'],timeout=600)
go('watchdog-final',['python3','tests/timing_reliability/verify_watchdog.py','--build-directory','build/agent-full','--output-directory','/tmp/cpp-m27-03-pass2-watchdog-final'],timeout=400)
go('clock-stop-final',['python3','tests/timing_reliability/verify_clock_stop.py','--output-directory','/tmp/cpp-m27-03-pass2-clock-stop-final'],timeout=180)
args=json.loads(Path('/tmp/cpp-m27-03-repaired-tsan-command.json').read_text());args[args.index('-fsanitize=thread')]='-fsanitize=address,undefined';args.insert(1,'-fno-omit-frame-pointer');args[-1]='/tmp/cpp-m27-03-pass2-asan'
go('asan-build',args)
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
go('asan',['/tmp/cpp-m27-03-pass2-asan','--gtest_filter=SimCoreTimingReliability.*:CrossMatrixDeterminism/*FmaOff'],timeout=90,env=env)
go('static',['clang++-14','--analyze','-std=c++20','-Xanalyzer','-analyzer-output=text','-Iinclude','-Irt/include','-Icore/include','-Ihal','-Igpu','-Iexternal/googletest/googletest/include','tests/test_timing_reliability.cpp','-o','/tmp/cpp-m27-03-pass2-static.plist'])
go('contract',['./scripts/agent-verify.sh','contract'])
go('package',['python3','tests/startup_poll_reliability/verify_package.py','--work-directory','build/m27-03-package02'],timeout=7200)
print('PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates',flush=True)
