from pathlib import Path
import subprocess,yaml,json,hashlib,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');c=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
for _ in range(180):
 log=Path('/tmp/cpp-m27-03-bindings-merge.log')
 if log.exists() and 'MERGED' in log.read_text():break
 time.sleep(5)
else:raise SystemExit('Canonical merge pending')
m=json.loads(Path('/tmp/cpp-m27-03-bindings-merge.json').read_text());assert m['merged'];rev=m['sha'];path='products/cpp-rt-car/batches/M27-03.yaml'
raw=subprocess.check_output(['git','show',rev+':'+path],cwd=c);blob=subprocess.check_output(['git','rev-parse',rev+':'+path],cwd=c,text=True).strip();d=yaml.safe_load(raw);old=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
d['sources'].update({k:old['sources'][k] for k in ['control_plane_repository','control_plane_path','activation','predecessor_control_revision']});d['sources'].update(control_plane_revision=rev,canonical_revision=rev,canonical_blob_sha=blob);assert 'docs/cuda_capabilities.json' in d['scope']['allowed_paths'];(r/'contracts/active-batch.yaml').write_text(yaml.safe_dump(d,sort_keys=False,width=100))
with (r/'AGENTS.md').open('a') as f:f.write('\nCanonical binding amendment #593 merged at '+rev+', blob '+blob+'.\nRefresh only the existing capability product-source digest for the approved\nexperimental watchdog header; all coverage inventory/status/support claims remain\nunchanged. Final local/hosted/integration gates remain mandatory.\n')
p=r/'docs/cuda_capabilities.json';raw=p.read_text();matrix=json.loads(raw);path='rt/include/rt/watchdog.hpp';old=matrix['product_sources'][path];new=hashlib.sha256((r/path).read_bytes()).hexdigest();assert raw.count(old)==1;p.write_text(raw.replace(old,new))
with open('/tmp/cpp-m27-03-hash-refresh.log','w') as f:subprocess.run(['python3','tools/check_release_contract.py','--write-hashes'],cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True)
print('Bound canonical',rev,blob,flush=True)
with open('/tmp/cpp-m27-03-pass2-gates-progress.log','a') as f:p=subprocess.run(['python3','/tmp/cpp-m27-03-pass2-resume.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)
