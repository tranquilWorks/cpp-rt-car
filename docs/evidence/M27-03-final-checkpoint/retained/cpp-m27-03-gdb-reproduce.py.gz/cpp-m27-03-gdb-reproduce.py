from pathlib import Path
import subprocess,signal,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
with open('/tmp/cpp-m27-03-gdb-reproduce.log','w') as f:
 p=subprocess.Popen(['gdb','-q','-nx','-batch','-ex','set pagination off','-ex','run','-ex','thread apply all bt 6','-ex','thread 1','-ex','bt 16','-ex','quit','--args','build/agent-full/tests/simcore_tests','--gtest_filter=CrossMatrixDeterminism/*FmaOff','--gtest_repeat=20'],cwd=r,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:p.wait(timeout=60)
 except subprocess.TimeoutExpired:
  p.send_signal(signal.SIGINT)
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 print('gdb exit',p.returncode)
