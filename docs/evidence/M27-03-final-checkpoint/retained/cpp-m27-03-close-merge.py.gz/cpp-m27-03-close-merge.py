import json,subprocess,re,time
from pathlib import Path
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*args):return subprocess.check_output(args,cwd=root,text=True).strip()
head,tree=Path('/tmp/cpp-m27-03-close-identity.txt').read_text().splitlines();base=Path('/tmp/cpp-m27-03-close-base.txt').read_text().strip();number=int(Path('/tmp/cpp-m27-03-close-pr-number.txt').read_text())
assert run('git','rev-parse','HEAD')==head and run('git','rev-parse','HEAD^{tree}')==tree and not run('git','status','--porcelain')
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-03-close-control.log').read_text()
checks=json.loads(run('gh','api',f'repos/tranquilWorks/portfolio-control/commits/{head}/check-runs?per_page=100'));Path('/tmp/cpp-m27-03-close-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
assert len(checks['check_runs'])==1;c=checks['check_runs'][0];assert c['head_sha']==head and c['name']=='validate' and c['status']=='completed'
run_id=re.search(r'/actions/runs/(\d+)',c['details_url']).group(1)
jobs=json.loads(run('gh','api',f'repos/tranquilWorks/portfolio-control/actions/runs/{run_id}/jobs?per_page=100'));Path('/tmp/cpp-m27-03-close-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n');assert len(jobs['jobs'])==1;j=jobs['jobs'][0];assert j['head_sha']==head and j['status']=='completed'
if c['conclusion']=='success':
 assert j['conclusion']=='success';disposition='Hosted validation passed.'
else:
 assert c['conclusion']=='failure' and j['conclusion']=='failure' and j['steps']==[]
 disposition=f'Hosted run{run_id}/job{j["id"]} completed failure with steps=[]; recorded UNPERFORMED under the standing control-only infrastructure exception after complete local PASS. No target or local functional gate was waived.'
p=Path('/tmp/cpp-m27-03-close-pr.md');s=p.read_text()+f'\nFull local control validation PASSED (exit0). Exact head `{head}`, tree `{tree}`. '+disposition+'\n';p.write_text(s);body=Path('/tmp/cpp-m27-03-close-body.json');body.write_text(json.dumps({'body':s}));run('gh','api','--method','PATCH',f'repos/tranquilWorks/portfolio-control/pulls/{number}','--input',str(body))
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base
run('git','fetch','origin',f'refs/pull/{number}/merge');assert run('git','rev-parse','FETCH_HEAD^{tree}')==tree
query='{repository(owner:"tranquilWorks",name:"portfolio-control"){pullRequest(number:'+str(number)+'){headRefOid baseRefOid isDraft mergeable reviewThreads(first:100){nodes{isResolved} pageInfo{hasNextPage}}}}}'
def guard(name):
 raw=run('gh','api','graphql','-f','query='+query);Path('/tmp/cpp-m27-03-close-'+name+'.json').write_text(raw+'\n');p=json.loads(raw)['data']['repository']['pullRequest'];assert p['headRefOid']==head and p['baseRefOid']==base and p['mergeable']=='MERGEABLE'
 assert not p['reviewThreads']['pageInfo']['hasNextPage'] and all(t['isResolved'] for t in p['reviewThreads']['nodes'])
 return p
if guard('pre-guard')['isDraft']:run('gh','pr','ready',str(number),'--repo','tranquilWorks/portfolio-control')
assert not guard('guard')['isDraft']
payload=Path('/tmp/cpp-m27-03-close-merge-input.json');payload.write_text(json.dumps({'sha':head,'merge_method':'squash','commit_title':f'cpp-rt-car: close M27-03 and supply control validation dependency (#{number})'}))
raw=run('gh','api','--method','PUT',f'repos/tranquilWorks/portfolio-control/pulls/{number}/merge','--input',str(payload));Path('/tmp/cpp-m27-03-close-merge.json').write_text(raw+'\n');m=json.loads(raw);assert m['merged'],m
run('git','fetch','origin','main');assert run('git','rev-parse',m['sha']+'^{tree}')==tree
s+=f'\nMerged at `{m["sha"]}`; fetched merged tree equals tested tree `{tree}`. Expected head/base, clean state and no unresolved review-thread guards passed. M27-03 is delivered and this closure is complete. M27-04..08 remain planned/inactive, with all broader qualification and acceptance obligations open.\n';p.write_text(s);body.write_text(json.dumps({'body':s}));run('gh','api','--method','PATCH',f'repos/tranquilWorks/portfolio-control/pulls/{number}','--input',str(body))
print('MERGED',m['sha'],'tree',tree,disposition)
