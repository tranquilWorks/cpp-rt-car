#include <simcore/highres_clock.hpp>
#include <cstdio>
int main() {
 HighResClock::last_ns_=100;
 unsigned long long delayed=0;
 std::thread older([&] {delayed=HighResClock::ensure_monotonic(200);});
 while(!floor_probe::paused.load()) std::this_thread::yield();
 const auto newer=HighResClock::ensure_monotonic(300);
 floor_probe::release=true;older.join();
 const auto following=HighResClock::ensure_monotonic(250);
 std::printf("delayed=%llu completed=%llu following=%llu\n",delayed,static_cast<unsigned long long>(newer),static_cast<unsigned long long>(following));
 return following>newer && following>delayed?0:1;
}
