from pathlib import Path
import tarfile,hashlib,json,shutil,os
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24/build/m26-04r-asan');dest=Path('/home/kbianco/.local/share/portfolio-control/evidence-archives/cpp-m26-04r-asan-build.tar.gz');manifest={}
assert root.is_dir() and not dest.exists()
for p in [root,*sorted(root.rglob('*'))]:
 name='workspace'+('/'+p.relative_to(root).as_posix() if p!=root else '')
 record={'mode':p.lstat().st_mode & 0o7777}
 if p.is_symlink():record.update(kind='symlink',target=os.readlink(p))
 elif p.is_dir():record['kind']='directory'
 elif p.is_file():record.update(kind='file',sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
 else:raise RuntimeError('unexpected special file '+str(p))
 manifest[name]=record
with tarfile.open(dest,'w:gz',dereference=False) as t:t.add(root,arcname='workspace',recursive=True)
with tarfile.open(dest,'r:gz') as t:
 assert set(t.getnames())==set(manifest)
 for m in t.getmembers():
  r=manifest[m.name];assert m.mode==r['mode']
  if r['kind']=='file':
   data=t.extractfile(m).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
  elif r['kind']=='symlink':assert m.issym() and m.linkname==r['target']
  else:assert m.isdir()
record={'source':str(root),'archive':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':manifest}
dest.with_suffix('.manifest.json').write_text(json.dumps(record,indent=2)+'\n')
Path('/tmp/cpp-m26-04r-asan-build-archive.json').write_text(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2)+'\n')
shutil.rmtree(root)
print('Archived and verified',len(manifest),'entries including symlinks and modes;',dest.stat().st_size,'bytes')
