from pathlib import Path
import subprocess,signal,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');log=Path('/tmp/cpp-m27-03-gdb-clock.log')
commands=['set pagination off','run','thread apply all bt 8','thread 1','bt 12','frame 0','info args','p *req','frame 3','info args','info locals','p this->frame_','p this->nextTarget_','p this->dtNs_','p this->startReal_','p HighResClock::ref_start_ns_','p HighResClock::last_ns_','p HighResClock::tsc_freq_','p HighResClock::tsc_ok_','quit']
args=['gdb','-q','-nx','-batch']
for command in commands:args+=['-ex',command]
args+=['--args','build/agent-full/tests/simcore_tests','--gtest_filter=CrossMatrixDeterminism/*FmaOff','--gtest_repeat=30']
with log.open('w') as f:
 p=subprocess.Popen(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);start=time.monotonic();last=start;size=0
 while p.poll() is None and time.monotonic()-start<180:
  current=log.stat().st_size
  if current!=size:last=time.monotonic();size=current
  if time.monotonic()-last>8:
   print('No debugger/test output for8s; capturing stacks',flush=True);break
  time.sleep(1)
 if p.poll() is None:
  p.send_signal(signal.SIGINT)
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 print('gdb exit',p.returncode,flush=True)
