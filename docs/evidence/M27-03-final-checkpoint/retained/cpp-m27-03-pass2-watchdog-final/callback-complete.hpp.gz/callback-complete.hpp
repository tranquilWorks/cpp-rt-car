#pragma once
#include <atomic>
#include <chrono>
#include <cstdlib>
#include <thread>
namespace m27_watchdog {
inline std::atomic<bool> completed{false};
inline void await_callback() {
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(5);
  while(!completed.load()) {
    if(std::chrono::steady_clock::now()>deadline) std::_Exit(43);
    std::this_thread::yield();
  }
}
}
