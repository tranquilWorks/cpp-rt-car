from pathlib import Path
p=Path('/tmp/cpp-m27-02-publish.py').read_text().replace('m27-02','m27-03').replace('M27-02','M27-03')
a=p.index("assert 'PASS focused/sanitizer");b=p.index('batch=yaml.safe_load',a)
p=p[:a]+'''assert 'PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates' in Path('/tmp/cpp-m27-03-pass2-gates-progress.log').read_text()
assert 'PASS TSan eight tests' in Path('/tmp/cpp-m27-03-pass2-tsan-progress.log').read_text()
assert 'Release contract OK' in Path('/tmp/cpp-m27-03-final-contract.log').read_text()
'''+p[b:]
p=p.replace('fix: conserve command poll faults and startup cleanup ownership','fix: synchronize experimental dispatch, watchdog and clock boundaries')
a=p.index('body=f"""');b=p.index('Path(\'/tmp/cpp-m27-03-pr.md\')',a)
p=p[:a]+'''body=f"""Experimental SimCore could reuse frame arenas before workers initialized, and overwrite range metadata before old workers finished. Explicit readiness and dispatch acknowledgements establish those lifetime boundaries. Watchdog callbacks now publish atomic state for the coordinator to consume at frame completion, including the final frame; shutdown publishes stop under its condition-variable mutex.

An unchanged repeated determinism workload also exposed bad TSC calibration. Validate samples before monotonic publication with the existing1ms threshold, and use an atomic compare/exchange loop so delayed callers cannot lower the clock floor. Calibration and default clock selection stay unchanged. Concurrent process-global clock initialization remains outside this repair.

Actual baseline source controls fail for startup, dispatch, watchdog handoff, lost shutdown wake, clock outlier poisoning and stale monotonic publication; corrected controls pass. Original1500-frame/5000-element2/4/8-thread tests, deadlines and assertions remain unchanged. Fresh focused, repeated, ASan/UBSan/leaks, TSan, static, contract and actual relocated default/optional CPack plus71 SDK consumer checks pass. All prior failed attempts are retained.

The M23 benchmark submission finding is classified separately: a held public submit callback can expire the original1ms deadline with zero backend submissions, violating the unchanged fixture's exact-one assumption. The historical provider_error lacks predicate detail, so its precise cause remains unresolved. Supported Runtime, benchmark fixtures, ABI/native implementations and prior evidence remain unchanged.

Canonical plans590/591/592 are integrated. Candidate `{head}`, tree `{tree}`. Evidence: docs/evidence/M27-03-final-checkpoint and docs/evidence/M27-03-2026-10-01.md. Fresh exact-head portable152/strict157 and all32 hosted records with baseline names/multiplicity remain mandatory before guarded merge and canonical closure. M27-04..08 and external qualification/Unreal/signing/release/deployment remain separate.
"""
'''+p[b:]
Path('/tmp/cpp-m27-03-publish.py').write_text(p)
s=Path('/tmp/cpp-m27-02-full.py').read_text().replace('m27-02','m27-03').replace('(152,156)','(152,157)');Path('/tmp/cpp-m27-03-full.py').write_text(s)
s=Path('/tmp/cpp-m27-02-merge.py').read_text().replace('m27-02','m27-03').replace('M27-02','M27-03').replace('677fae6976f8eddd6ed7e060f222c3535a9e7ae2','b60a73b1e9bacd6ace250dfa1d5d51fab862eaa7').replace('(152,156)','(152,157)').replace('portable152/strict156','portable152/strict157').replace('M27-03..08','M27-04..08').replace('fix: conserve command poll faults and startup cleanup ownership','fix: synchronize experimental dispatch, watchdog and clock boundaries');Path('/tmp/cpp-m27-03-merge.py').write_text(s)
p=Path('/tmp/cpp-m27-03-risk-review-draft.md');s=p.read_text();s=s.replace('- New range tests', '''- Experimental watchdog stop uses its existing predicate mutex before notify,
  so the worker cannot miss the transition between checking and sleeping. The
  destructor releases that mutex before join. Callback lifetime still ends before
  dependent SimCore members are destroyed; supported Runtime is unchanged.
- Clock rejects backward, nonfinite and unrepresentable deltas before unsigned
  conversion/addition, then applies the existing1ms drift bound before publishing
  every sample. Conservative floating bounds reject the rounded limit itself.
  Atomic compare/exchange publishes one monotonic maximum without a stale store.
  No cross-thread initialization guarantee or physical timing claim is added.
- New range tests''').replace('watchdog assertion failures are distinct','watchdog assertion failures and shutdown diagnostic49 are distinct')
p.write_text(s)
