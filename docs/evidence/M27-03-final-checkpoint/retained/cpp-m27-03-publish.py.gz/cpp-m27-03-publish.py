from pathlib import Path
import subprocess,json,fnmatch,yaml
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*args):return subprocess.check_output(args,cwd=root,text=True,timeout=900).strip()
assert run('git','branch','--show-current')=='agent/m27-03-reliability'
assert 'PASS M27-03 focused/repeated/causal/ASan/static/contract/relocated package gates' in Path('/tmp/cpp-m27-03-pass2-gates-progress.log').read_text()
assert 'PASS TSan eight tests' in Path('/tmp/cpp-m27-03-pass2-tsan-retry2-progress.log').read_text()
assert 'Release contract OK' in Path('/tmp/cpp-m27-03-final-contract.log').read_text()
batch=yaml.safe_load((root/'contracts/active-batch.yaml').read_text())
paths=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines())
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in batch['scope']['forbidden_paths']),p
run('git','diff','--check');run('git','add','--',*sorted(paths));run('git','diff','--cached','--check')
print(run('git','commit','-m','fix: synchronize experimental dispatch, watchdog and clock boundaries (M27-03)'),flush=True)
head,tree=run('git','rev-parse','HEAD'),run('git','rev-parse','HEAD^{tree}');assert not run('git','status','--porcelain')
Path('/tmp/cpp-m27-03-final-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','--set-upstream','origin','agent/m27-03-reliability'),flush=True)
body=f"""Experimental SimCore could reuse frame arenas before workers initialized, and overwrite range metadata before old workers finished. Explicit readiness and dispatch acknowledgements establish those lifetime boundaries. Watchdog callbacks now publish atomic state for the coordinator to consume at frame completion, including the final frame; shutdown publishes stop under its condition-variable mutex.

An unchanged repeated determinism workload also exposed bad TSC calibration. Validate samples before monotonic publication with the existing1ms threshold, and use an atomic compare/exchange loop so delayed callers cannot lower the clock floor. Calibration and default clock selection stay unchanged. Concurrent process-global clock initialization remains outside this repair.

Actual baseline source controls fail for startup, dispatch, watchdog handoff, lost shutdown wake, clock outlier poisoning and stale monotonic publication; corrected controls pass. Original1500-frame/5000-element2/4/8-thread tests, deadlines and assertions remain unchanged. Fresh focused, repeated, ASan/UBSan/leaks, TSan, static, contract and actual relocated default/optional CPack plus71 SDK consumer checks pass. All prior failed attempts are retained.

The M23 benchmark submission finding is classified separately: a held public submit callback can expire the original1ms deadline with zero backend submissions, violating the unchanged fixture's exact-one assumption. The historical provider_error lacks predicate detail, so its precise cause remains unresolved. Supported Runtime, benchmark fixtures, ABI/native implementations and prior evidence remain unchanged.

Canonical plans590/591/592/593 are integrated. Candidate `{head}`, tree `{tree}`. Evidence: docs/evidence/M27-03-final-checkpoint and docs/evidence/M27-03-2026-10-01.md. Fresh exact-head portable152/strict157 and all32 hosted records with baseline names/multiplicity remain mandatory before guarded merge and canonical closure. M27-04..08 and external qualification/Unreal/signing/release/deployment remain separate.
"""
Path('/tmp/cpp-m27-03-pr.md').write_text(body)
existing=json.loads(run('gh','api','repos/tranquilWorks/cpp-rt-car/pulls?state=open&head=tranquilWorks:agent/m27-03-reliability&base=main'));assert len(existing)<=1
if existing:
 number=existing[0]['number']
 p=Path('/tmp/cpp-m27-03-update.json');p.write_text(json.dumps({'body':body}));run('gh','api','--method','PATCH',f'repos/tranquilWorks/cpp-rt-car/pulls/{number}','--input',str(p))
else:
 p=Path('/tmp/cpp-m27-03-create.json');p.write_text(json.dumps({'title':'fix: synchronize experimental dispatch, watchdog and clock boundaries (M27-03)','head':'agent/m27-03-reliability','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(p));Path('/tmp/cpp-m27-03-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m27-03-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/cpp-rt-car/pull/'+str(number),flush=True)
