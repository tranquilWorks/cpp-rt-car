#include <rt/watchdog.hpp>
#include <memory>
int main() {
 auto watchdog=std::make_unique<rt::Watchdog>(std::chrono::hours(24),std::chrono::hours(24),[]{});
 while(!stop_probe::checked.load()) std::this_thread::yield();
 std::thread monitor([] {
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(2);
  while(!stop_probe::finished.load()) {
   if(std::chrono::steady_clock::now()>deadline) {std::fprintf(stderr,"REPRO: watchdog stop notification lost before condition-variable wait; join cannot complete\n");std::_Exit(49);}
   std::this_thread::yield();
  }
 });
 watchdog.reset();stop_probe::finished=true;monitor.join();std::puts("watchdog stop joined");
}
