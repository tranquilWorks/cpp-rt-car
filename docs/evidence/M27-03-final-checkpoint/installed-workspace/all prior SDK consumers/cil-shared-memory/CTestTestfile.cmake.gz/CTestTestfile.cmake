# CMake generated Testfile for 
# Source directory: /tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/cil_shared_memory
# Build directory: /tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/cil-shared-memory
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[cil_shared_memory_processes]=] "/home/kbianco/.local/bin/python3.12" "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/cil_shared_memory/runner.py" "--plant" "/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/cil-shared-memory/cil_plant" "--controller" "/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/cil-shared-memory/cil_controller")
set_tests_properties([=[cil_shared_memory_processes]=] PROPERTIES  TIMEOUT "90" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/cil_shared_memory/CMakeLists.txt;25;add_test;/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/cil_shared_memory/CMakeLists.txt;0;")
