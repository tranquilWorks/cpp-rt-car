# CMake generated Testfile for 
# Source directory: /tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter
# Build directory: /tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/host-adapter
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[host_adapter_native]=] "/usr/bin/cmake" "-DHOST_EXECUTABLE=/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/host-adapter/host_adapter" "-DHOST_MODE=native" "-P" "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/check_output.cmake")
set_tests_properties([=[host_adapter_native]=] PROPERTIES  TIMEOUT "40" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;22;add_test;/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;0;")
add_test([=[host_adapter_host]=] "/usr/bin/cmake" "-DHOST_EXECUTABLE=/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/host-adapter/host_adapter" "-DHOST_MODE=host" "-P" "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/check_output.cmake")
set_tests_properties([=[host_adapter_host]=] PROPERTIES  TIMEOUT "40" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;22;add_test;/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/host_adapter/CMakeLists.txt;0;")
