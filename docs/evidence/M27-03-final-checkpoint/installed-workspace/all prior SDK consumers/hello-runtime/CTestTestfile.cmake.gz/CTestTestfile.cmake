# CMake generated Testfile for 
# Source directory: /tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime
# Build directory: /tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/hello-runtime
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[hello_runtime_output]=] "/usr/bin/cmake" "-DHELLO_EXECUTABLE=/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/hello-runtime/hello_runtime" "-P" "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime/check_output.cmake")
set_tests_properties([=[hello_runtime_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime/CMakeLists.txt;19;add_test;/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/hello_runtime/CMakeLists.txt;0;")
