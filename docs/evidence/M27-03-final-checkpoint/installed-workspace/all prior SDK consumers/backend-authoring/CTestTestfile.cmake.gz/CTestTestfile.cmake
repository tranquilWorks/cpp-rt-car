# CMake generated Testfile for 
# Source directory: /tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring
# Build directory: /tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/backend-authoring
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[backend_authoring_output]=] "/usr/bin/cmake" "-DBACKEND_EXECUTABLE=/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/backend-authoring/backend_authoring" "-P" "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/check_output.cmake")
set_tests_properties([=[backend_authoring_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/CMakeLists.txt;19;add_test;/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/CMakeLists.txt;0;")
