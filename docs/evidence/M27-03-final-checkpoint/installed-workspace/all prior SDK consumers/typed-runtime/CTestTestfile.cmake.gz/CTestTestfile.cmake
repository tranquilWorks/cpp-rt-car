# CMake generated Testfile for 
# Source directory: /tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime
# Build directory: /tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/typed-runtime
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[typed_runtime_output]=] "/usr/bin/cmake" "-DTYPED_EXECUTABLE=/tmp/startup poll relocated 0fxf4rs3/all prior SDK consumers/typed-runtime/typed_runtime" "-P" "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime/check_output.cmake")
set_tests_properties([=[typed_runtime_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime/CMakeLists.txt;19;add_test;/tmp/startup poll relocated 0fxf4rs3/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime/CMakeLists.txt;0;")
