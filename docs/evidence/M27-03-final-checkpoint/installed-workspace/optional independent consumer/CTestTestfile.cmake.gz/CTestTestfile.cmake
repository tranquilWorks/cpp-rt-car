# CMake generated Testfile for 
# Source directory: /tmp/startup poll relocated 0fxf4rs3/independent tests/startup_poll_reliability
# Build directory: /tmp/startup poll relocated 0fxf4rs3/optional independent consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[host_adapter_startup_poll_reliability]=] "/tmp/startup poll relocated 0fxf4rs3/optional independent consumer/rtfw_startup_poll_tests")
set_tests_properties([=[host_adapter_startup_poll_reliability]=] PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/tmp/startup poll relocated 0fxf4rs3/independent tests/startup_poll_reliability/CMakeLists.txt;17;add_test;/tmp/startup poll relocated 0fxf4rs3/independent tests/startup_poll_reliability/CMakeLists.txt;0;")
