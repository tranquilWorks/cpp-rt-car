from pathlib import Path
import subprocess,json,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');c=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a,cwd=r):return subprocess.check_output(a,cwd=cwd,text=True).strip()
m=json.loads(Path('/tmp/cpp-m27-08-plan-merge.json').read_text());assert m['merged'];rev=m['sha'];path='products/cpp-rt-car/batches/M27-08.yaml';d=yaml.safe_load(run('git','show',rev+':'+path,cwd=c))
assert not run('git','status','--porcelain');run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==d['sources']['baseline_commit'];run('git','switch','-c','agent/m27-08-migration','origin/main')
d['sources'].update(control_plane_revision=rev,canonical_revision=rev,canonical_blob_sha=run('git','rev-parse',rev+':'+path,cwd=c));(r/'contracts/active-batch.yaml').write_text(yaml.safe_dump(d,sort_keys=False,width=100))
p=r/'AGENTS.md';p.write_text(p.read_text()+f'\n## M27-08 platform migration and bounded portable soak\n\nCanonical activation `{rev}` selects only08 after completed07.\nAdd missing actual installed-package migration checks and bounded fixed ordinary\nlifecycle/replay/owner-isolation repetitions, journals and resource observations.\nOnly additive new-test wiring; preserve production, old tests, ABI/defaults and\nall prior evidence. Original05/06 excluded work stays unperformed. Full local/\nall32 exact-head gates, risk review, scoped publication, guarded merge and\ncanonical closure remain required and authorized. No physical/RT/Unreal/human/\ncontrolled-performance/signing/release/deployment claim follows.\n')
for folder in ['tests/platform_migration','tools/portable_soak']:(r/folder).mkdir()
def write(name,s):(r/name).write_text(s)
write('tests/platform_migration/main.cpp',r'''// The same source is compiled against both documented 1.x CMake targets.
#include <rt/runtime.hpp>
#include "memory.hpp"
#include <array>
#include <charconv>
#include <chrono>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string_view>
#include <vector>
namespace {
void require(bool value) { if (!value) throw std::runtime_error("migration/soak invariant failed"); }
struct Clock final : rt::RuntimeClock {
  std::uint64_t now_ns() noexcept override { return 1000; }
};
struct Owner {
  Clock clock;
  std::array<std::byte,8> state{};
  std::size_t calls=0;
  golden::Memory& memory;
  rt::Runtime runtime{clock};
  explicit Owner(golden::Memory& storage):memory(storage) {
    rt::RuntimeConfig cfg;
    cfg.callback_capacity=1; cfg.worker_count=1;
    cfg.executor_queue_capacity=2; cfg.task_scratch_slots=2;
    cfg.scratch_bytes=256; cfg.task_scratch_bytes=256; cfg.trace_capacity=32;
    require(runtime.configure(cfg)==rt::Status::ok);
    require(runtime.set_memory_provider(memory.table())==rt::Status::ok);
    require(runtime.set_cpu_memory_policy(golden::Memory::policy())==rt::Status::ok);
    rt::PhaseHandle phase;
    require(runtime.register_callback({"increment",[](void* p,const rt::CallbackContext&) {
      auto& self=*static_cast<Owner*>(p);
      self.state[0]=static_cast<std::byte>((std::to_integer<unsigned>(self.state[0])+1u)&255u);
      ++self.calls; return rt::CallbackResult::ok;
    },this},phase)==rt::Status::ok);
    require(runtime.register_state({"state",1,state})==rt::Status::ok);
    require(runtime.finalize()==rt::Status::ok);
    require(runtime.start()==rt::Status::ok && memory.live_count()==3);
  }
  ~Owner(){(void)runtime.stop();}
  void step(std::uint64_t frame) {
    require(runtime.step({frame,std::chrono::nanoseconds{100}})==rt::Status::ok);
  }
};
void cycle() {
  auto am=std::make_unique<golden::Memory>();
  auto bm=std::make_unique<golden::Memory>();
  {
    Owner a(*am),b(*bm);
    std::size_t extent=0;
    require(a.runtime.checkpoint_size(extent)==rt::Status::ok && extent<=65536);
    std::vector<std::byte> saved(extent);
    rt::ArtifactWriteResult result;
    require(a.runtime.write_checkpoint(0,saved,result)==rt::Status::ok && result.bytes_written==extent);
    for (std::uint64_t i=1;i<=64;++i) {
      a.step(i);require(b.calls==0 && b.state[0]==std::byte{0});
    }
    const auto expected=a.state;
    require(a.calls==64 && expected[0]==std::byte{64});
    require(a.runtime.restore_checkpoint(saved)==rt::Status::ok && a.state[0]==std::byte{0});
    for (std::uint64_t i=1;i<=64;++i) a.step(i);
    require(a.state==expected && a.calls==128 && b.calls==0);
    // Documented ordinary compatible cross-owner checkpoint restore.
    require(b.runtime.restore_checkpoint(saved)==rt::Status::ok);
    for (std::uint64_t i=1;i<=64;++i) b.step(i);
    require(b.state==expected && b.calls==64 && a.calls==128);
    require(a.runtime.stop()==rt::Status::ok && am->live_count()==0);
    require(a.runtime.step({65,std::chrono::nanoseconds{100}})==rt::Status::invalid_state);
    require(a.runtime.start()==rt::Status::invalid_state);
    b.step(65);require(b.calls==65 && b.state[0]==std::byte{65} && a.state==expected);
    require(b.runtime.stop()==rt::Status::ok && bm->live_count()==0);
    require(a.runtime.stop()==rt::Status::ok && b.runtime.stop()==rt::Status::ok);
  }
  require(am->acquisitions==3 && bm->acquisitions==3);
  require(am->releases==3 && bm->releases==3);
  require(am->violations==0 && bm->violations==0 && am->live_count()==0 && bm->live_count()==0);
}
}
int main(int argc,char** argv) {
  unsigned cycles=2;
  if (argc==3 && std::string_view(argv[1])=="--cycles") {
    const std::string_view arg(argv[2]);
    const auto parsed=std::from_chars(arg.data(),arg.data()+arg.size(),cycles);
    if(parsed.ec!=std::errc{} || parsed.ptr!=arg.data()+arg.size() || cycles<1 || cycles>10000) return 2;
  } else if(argc!=1) return 2;
  try {
    for(unsigned i=1;i<=cycles;++i) {
      cycle();
      std::cout << "{\"cycle\":" << i << ",\"frames\":193,\"logical_ns\":19300,\"owners\":2,\"acquired\":6,\"released\":6,\"live\":0,\"checkpoint_reexecutions\":1,\"expected_refusals\":2}" << std::endl;
    }
    return 0;
  } catch(const std::exception& e) {std::cerr << e.what() << '\n';return 1;}
}
''')
write('tests/platform_migration/CMakeLists.txt',r'''cmake_minimum_required(VERSION 3.20)
if(CMAKE_SOURCE_DIR STREQUAL CMAKE_CURRENT_SOURCE_DIR)
  project(rtfw_platform_migration LANGUAGES CXX)
  enable_testing()
  find_package(rtfw 1.2 CONFIG REQUIRED COMPONENTS runtime cpp_runtime)
endif()
if(DEFINED RTFW_DATA_DIR)
  set(migration_memory_dir "${RTFW_DATA_DIR}/examples/golden_system")
else()
  set(migration_memory_dir "${CMAKE_CURRENT_LIST_DIR}/../../samples/golden_system")
endif()
foreach(kind IN ITEMS current legacy)
  add_executable(rtfw_migration_${kind} main.cpp)
  target_compile_features(rtfw_migration_${kind} PRIVATE cxx_std_20)
  target_include_directories(rtfw_migration_${kind} PRIVATE "${migration_memory_dir}")
  if(kind STREQUAL "current")
    target_link_libraries(rtfw_migration_${kind} PRIVATE rtfw::runtime)
  else()
    target_link_libraries(rtfw_migration_${kind} PRIVATE rtfw::simcore_rt)
  endif()
  if(WIN32)
    target_link_libraries(rtfw_migration_${kind} PRIVATE psapi)
  endif()
  if(COMMAND rtfw_enable_project_warnings)
    rtfw_enable_project_warnings(rtfw_migration_${kind})
  elseif(MSVC)
    target_compile_options(rtfw_migration_${kind} PRIVATE /W4 /WX)
  else()
    target_compile_options(rtfw_migration_${kind} PRIVATE -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror)
  endif()
  add_test(NAME migration_${kind}_lifecycle COMMAND rtfw_migration_${kind})
  set_tests_properties(migration_${kind}_lifecycle PROPERTIES TIMEOUT 60)
endforeach()
''')
p=r/'tests/CMakeLists.txt';p.write_text(p.read_text()+'\n# M27-08 fixed lifecycle equivalence and journal validation.\nadd_subdirectory(platform_migration)\nfind_package(Python3 REQUIRED COMPONENTS Interpreter)\nadd_test(NAME portable_soak_journal COMMAND ${Python3_EXECUTABLE} "${CMAKE_SOURCE_DIR}/tools/portable_soak/test_run.py")\nset_tests_properties(portable_soak_journal PROPERTIES TIMEOUT 60)\n')
p=r/'tests/package_consumer/CMakeLists.txt';p.write_text(p.read_text()+'\n# Exercise both compatibility names against the same extracted SDK.\nadd_subdirectory("${CMAKE_CURRENT_LIST_DIR}/../platform_migration" platform-migration)\nfind_package(Python3 REQUIRED COMPONENTS Interpreter)\nadd_test(NAME installed_migration_discovery COMMAND ${Python3_EXECUTABLE}\n  "${CMAKE_CURRENT_LIST_DIR}/../platform_migration/discovery.py"\n  --prefix "${RTFW_PREFIX}" --output "${CMAKE_CURRENT_BINARY_DIR}/migration-discovery")\nset_tests_properties(installed_migration_discovery PROPERTIES TIMEOUT 180)\n')
print('Activated08; C++ migration source and additive wiring prepared')
