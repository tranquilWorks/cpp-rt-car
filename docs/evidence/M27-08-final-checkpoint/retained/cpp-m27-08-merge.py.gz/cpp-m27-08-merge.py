from pathlib import Path
import subprocess,json,collections,hashlib,fnmatch,yaml,time
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
head,tree=Path('/tmp/cpp-m27-08-final-identity.txt').read_text().splitlines();base='7567c9621d49dc113bca2fd4951cb477d5d63b67';number=int(Path('/tmp/cpp-m27-08-pr-number.txt').read_text())

def run(*args):return subprocess.check_output(args,cwd=root,text=True,timeout=120).strip()
def read_api(*args):
 for n in range(4):
  p=subprocess.run(['gh','api',*args],cwd=root,text=True,capture_output=True,timeout=90)
  if p.returncode==0:return p.stdout
  with open('/tmp/cpp-m27-08-merge-api-errors.log','a') as f:f.write(json.dumps(args)+'\n'+p.stderr+'\n')
  if n<3:time.sleep(5)
 raise RuntimeError(p.stderr)
assert run('git','rev-parse','HEAD')==head and run('git','rev-parse','HEAD^{tree}')==tree and not run('git','status','--porcelain')
full_path=Path('/tmp/cpp-m27-08-passing-full.txt').read_text().strip();full=Path(full_path).read_text()
assert f'head={head}' in full and 'completed=' in full and all(f'100% tests passed, 0 tests failed out of {n}' in full for n in (160,165))
manifest=json.loads((root/'docs/evidence/M27-08-final-checkpoint/reviewed-sources.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
batch=yaml.safe_load((root/'contracts/active-batch.yaml').read_text())
for p in run('git','diff','--name-only',base,head).splitlines():
 assert any(fnmatch.fnmatch(p,x) for x in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in batch['scope']['forbidden_paths']),p
checks=json.loads(read_api(f'repos/tranquilWorks/cpp-rt-car/commits/{head}/check-runs?per_page=100'));Path('/tmp/cpp-m27-08-checks.json').write_text(json.dumps(checks,indent=2)+'\n');records=checks['check_runs']
expected=json.loads(Path('/tmp/m26-feature-r4-checks.json').read_text())['check_runs']
assert len(records)==32 and all(c['head_sha']==head and c['status']=='completed' and c['conclusion']=='success' for c in records)
assert collections.Counter(c['name'] for c in records)==collections.Counter(c['name'] for c in expected)
run('git','fetch','origin','main');assert run('git','rev-parse','origin/main')==base
run('git','fetch','origin',f'refs/pull/{number}/merge');tested_merge=run('git','rev-parse','FETCH_HEAD');assert run('git','rev-parse',tested_merge+'^{tree}')==tree
Path('/tmp/cpp-m27-08-tested-merge-tree.json').write_text(json.dumps({'head':head,'base':base,'fetched_pr_merge':tested_merge,'tree':tree},indent=2)+'\n')
query='{repository(owner:"tranquilWorks",name:"cpp-rt-car"){pullRequest(number:'+str(number)+'){headRefOid baseRefOid isDraft mergeable reviewThreads(first:100){nodes{isResolved} pageInfo{hasNextPage}}}}}'
def guard(name):
 for n in range(4):
  raw=read_api('graphql','-f','query='+query);Path('/tmp/cpp-m27-08-'+name+'.json').write_text(raw+'\n');p=json.loads(raw)['data']['repository']['pullRequest']
  assert p['headRefOid']==head and p['baseRefOid']==base
  assert not p['reviewThreads']['pageInfo']['hasNextPage'] and all(t['isResolved'] for t in p['reviewThreads']['nodes'])
  if p['mergeable']=='UNKNOWN' and n<3:time.sleep(5);continue
  assert p['mergeable']=='MERGEABLE';return p
if guard('pre-guard')['isDraft']:run('gh','pr','ready',str(number),'--repo','tranquilWorks/cpp-rt-car')
assert not guard('guard')['isDraft']
assert run('git','rev-parse','HEAD')==head and not run('git','status','--porcelain')
payload=Path('/tmp/cpp-m27-08-merge-input.json');payload.write_text(json.dumps({'sha':head,'merge_method':'squash','commit_title':f'tests: verify portable migration and bounded lifecycle soak (M27-08) (#{number})'}))
# A failed/ambiguous mutation is never blindly retried; inspect PR state first.
raw=run('gh','api','--method','PUT',f'repos/tranquilWorks/cpp-rt-car/pulls/{number}/merge','--input',str(payload));Path('/tmp/cpp-m27-08-merge.json').write_text(raw+'\n');merged=json.loads(raw);assert merged['merged'],merged
run('git','fetch','origin','main');assert run('git','rev-parse',merged['sha']+'^{tree}')==tree
body=Path('/tmp/cpp-m27-08-pr.md').read_text()+f'\nFinal validation passed at `{head}`: fresh complete portable160/strict165 and all32 hosted records with exact baseline names/multiplicity. Clean/head/base/no-unresolved-review guards passed. Merged at `{merged["sha"]}`; fetched merged tree equals tested tree `{tree}`. No target/local gate was waived. Canonical M27-08 closure follows; excluded original05/06 work and M18/M19/M20/M25 qualification obligations stay open.\n';Path('/tmp/cpp-m27-08-pr.md').write_text(body);payload=Path('/tmp/cpp-m27-08-pr-body.json');payload.write_text(json.dumps({'body':body}));run('gh','api','--method','PATCH',f'repos/tranquilWorks/cpp-rt-car/pulls/{number}','--input',str(payload))
print('MERGED',merged['sha'],'tree',tree,flush=True)
