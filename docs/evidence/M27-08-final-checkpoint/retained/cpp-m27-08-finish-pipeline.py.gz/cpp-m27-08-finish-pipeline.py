from pathlib import Path
import subprocess,json,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
for _ in range(200):
 f=Path('/tmp/cpp-m27-08-final-full-result.json');c=Path('/tmp/cpp-m27-08-final-checks-progress.json')
 if f.exists():assert json.loads(f.read_text())['exit_code']==0,'Full failed'
 if c.exists():
  rows=json.loads(c.read_text())['check_runs'];bad=[x for x in rows if x['status']=='completed' and x['conclusion']!='success'];assert not bad,[(x['name'],x['conclusion']) for x in bad]
  if len(rows)==32 and all(x['status']=='completed' and x['conclusion']=='success' for x in rows) and Path('/tmp/cpp-m27-08-passing-full.txt').exists():break
 time.sleep(20)
else:raise SystemExit('Waiting window expired; no gate waived')
for phase in ['merge','close','close-pipeline']:
 with open('/tmp/cpp-m27-08-'+phase+'-execution.log','w') as f:p=subprocess.run(['python3','/tmp/cpp-m27-08-'+phase+'.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(phase,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('PASS target and canonical07 closure integrated',flush=True)
