from pathlib import Path
import json,subprocess,fnmatch,yaml,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'completed=' in Path('/tmp/cpp-m27-08-contract-final.log').read_text()
assert 'PASS complete Runtime migration consumer' in Path('/tmp/cpp-m27-08-sanitizers01.log').read_text()
assert 'PASS actual relocated archive' in Path('/tmp/cpp-m27-08-package01.log').read_text()
assert run('git','branch','--show-current')=='agent/m27-08-migration'
b=yaml.safe_load((r/'contracts/active-batch.yaml').read_text());paths=run('git','diff','--name-only','HEAD').splitlines()+run('git','ls-files','--others','--exclude-standard').splitlines()
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in b['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in b['scope']['forbidden_paths']),p
bindings=json.loads((r/'docs/evidence/M27-08-final-checkpoint/reviewed-sources.json').read_text());assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','tests: verify portable migration and bounded lifecycle soak'),flush=True)
assert not run('git','status','--porcelain')
head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-08-final-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/m27-08-migration'),flush=True)
body=(r/'docs/evidence/M27-08-2026-10-02.md').read_text()+f'\nFinal head `{head}`, tree `{tree}`. Complete portable160/strict165 and all32 exact-head hosted records with baseline names/multiplicity remain mandatory before guarded integration. No target/local functional gate is waived.\n'
Path('/tmp/cpp-m27-08-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/cpp-rt-car/pulls?state=open&head=tranquilWorks:agent/m27-08-migration'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m27-08-create.json');p.write_text(json.dumps({'title':'tests: verify portable migration and bounded lifecycle soak (M27-08)','head':'agent/m27-08-migration','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(p));Path('/tmp/cpp-m27-08-create-result.json').write_text(raw);number=json.loads(raw)['number']
Path('/tmp/cpp-m27-08-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/cpp-rt-car/pull/'+str(number),flush=True)
