from pathlib import Path
import json,hashlib,subprocess,gzip,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
assert 'PASS actual relocated archive' in Path('/tmp/cpp-m27-08-package01.log').read_text()
assert 'PASS complete Runtime migration consumer' in Path('/tmp/cpp-m27-08-sanitizers01.log').read_text()
assert 'completed=' in Path('/tmp/cpp-m27-08-contract-final.log').read_text()
reports=[json.loads(Path('/tmp/cpp-m27-08-package/soak-'+k+'/report.json').read_text()) for k in ['current','legacy']]
assert all(v['status']=='passed' and v['completed_cycles']==4096 for v in reports)
assert reports[0]['totals']==reports[1]['totals']
base='7567c9621d49dc113bca2fd4951cb477d5d63b67'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('diff',base,'--','rt','src','include','core','abi','VERSION.txt','LICENSE','configs','profiles','.github/workflows','samples/golden_system','samples/golden_cuda','samples/golden_xdma','samples/golden_xdma_native','tests/runtime_robustness','tests/golden_xdma_native')
for name in ['tests/CMakeLists.txt','tests/package_consumer/CMakeLists.txt']:
 old=subprocess.check_output(['git','show',base+':'+name],cwd=r);assert (r/name).read_bytes().startswith(old)
# Actual copied consumer input and installed provider are identical to reviewed source.
for n in ['main.cpp','CMakeLists.txt','discovery.py']:
 assert (r/'tests/platform_migration'/n).read_bytes()==(Path('/tmp/cpp-m27-08-package/independent consumer')/n).read_bytes()
assert (r/'samples/golden_system/memory.hpp').read_bytes()==Path('/tmp/cpp-m27-08-package/relocated prefix/custom data/rtfw/examples/golden_system/memory.hpp').read_bytes()
text=f'''# M27-08 platform migration and bounded portable readiness

Baseline `{base}`; canonical activation605 merged at
8a3e60b27959f8759d01b4629a2cc90510e24b46. Target implementation is ready for
final exact-head full/local32-hosted gates, guarded integration and canonical closure.

The existing three supported platform tuples, C ABI/aliases, C++ aggregate defaults,
profiles/replay, optional components and relocated consumers were inventoried in
[the migration guide](../migration.md). Additive coverage compiles the identical
public consumer against current `rtfw::runtime` and legacy `rtfw::simcore_rt`.
An actual fresh default CPack archive is extracted beneath a relocated path with
spaces/custom include/data directories after deleting its original install prefix.
Copied consumer builds contain no checkout/SDK-build/original-prefix include paths.
Both consumers run and emit identical fixed records. Eight actual version/component
requests pass their expected acceptance/refusal; optional unknown remains absent.
No historical binary package or additional supported tuple is claimed.

Each installed executable completed4096 cycles in one process, covering790528
callbacks,79052800 logical nanoseconds,8192 owner lifetimes,4096 checkpoint
reexecutions,8192 expected post-stop refusals and24576 provider acquisitions/releases.
Current-target wall time was{reports[0]['elapsed_wall_seconds']:.6f}s; legacy-target
wall time was{reports[1]['elapsed_wall_seconds']:.6f}s. Every cycle balanced resources
and retained zero live provider regions/violations. Only three explicit provider
regions per owner are accounted, not all process memory. Fixed checkpoint restoration
and replayed steps are distinct from the existing active/live-control replay gates.

The bounded journal runner retains start/terminal records, complete stdout/stderr,
arguments, executable/runner/log hashes, wall time and logical totals. Behavioral
tests cover success, immutable existing output, nonzero diagnostic preservation,
missing output, unbalanced record, real timeout/reaping and POSIX interruption.
Windows skips only POSIX signal delivery; timeout/failure tests still run. No
hard-kill recovery or resumed-result aggregation is claimed. A start-only journal
is incomplete. No generated-input campaign, new schedule/workflow or scanner added.

Focused3/3 and complete contract pass. The new C++ consumer plus unchanged fully
instrumented Runtime passes ASan/UBSan/leaks and16 cycles under initialized TSan;
Clang14 static analysis reports no warning. TSan initialized on attempt48; retain
all47 pre-main mapping/empty-signal failures separately from the actual passing run.
No race report was suppressed. First contract attempts caught stale generated docs
and existing digest bindings; refreshes preserve schemas, targets and support claims.
Canonical605 first hosted validation failed unrelated temporary-Git cleanup with
Errno39; unchanged retry passed. All raw attempts remain retained.

Production/default/ABI/old-test byte comparisons pass; CMake test edits only append
new declarations. Existing ABI/default/no-allocation tests remain mandatory in full
verification. This batch adds coverage over already-correct baseline behavior;
there is no production repair or invented baseline defect. Ordinary failing journal
controls establish that nonpassing observations are not accepted as successful.
No target/local gate is waived. Final full160/strict165 and all32 exact-head check
names/multiplicity remain mandatory; final receipts belong to PR/canonical closure.

No M27 software card follows08. Remaining: original05 generated-input/continuous
and06 signature expansion (CAP-M20 not promoted); historical clock/benchmark/native
timing issues including07 full-frame TSan; actual Unreal and unfamiliar-consumer
human review; named hardware/RT/endurance qualification; controlled performance;
production identity/signing, release approval/publication/deployment. These remain
open under their original procedures. Portable software readiness is not global
acceptance or release authorization.
'''
(r/'docs/evidence/M27-08-2026-10-02.md').write_text(text)
(r/'docs/evidence/M27-08-risk-review.md').write_text('''# M27-08 scoped risk review

High-risk batch, reviewed against activated canonical605 and baseline target292.

- Scope/compatibility: no production/runtime/native/default/ABI/workflow change.
  Prior evidence and assertions are preserved. New CMake lines are strictly additive;
  release-contract hashes add only new coverage/doc sources and refresh changed files.
- Entry points: actual extracted CPack with deleted original prefix and independently
  copied consumer passes both targets, exact-output equivalence and eight discovery
  outcomes. NO_DEFAULT_PATH prevents silently selecting another SDK for version tests.
- Observation validity: executable and runner hashes, fixed integer row contracts,
  complete log hashes, request counts and measured monotonic time are retained.
  Exit0 alone does not pass; missing/extra rows and resource imbalance fail. Start-only
  journals remain incomplete. Existing output cannot be reused. Source/build bindings
  supplement the unsigned runner observation; this is not authenticated provenance.
- Lifetime: two isolated owners, checkpoint reexecution, compatible cross-owner
  restore, checked/idempotent stop and continued peer progression are asserted.
  All six reference-provider acquisitions/releases balance each cycle. This does not
  claim universal heap conservation or physical endurance. ASan/leaks and initialized
  TSan exercise the complete unchanged Runtime separately; all startup attempts remain.
- Cancellation: parent handles interruption/timeout, terminates then waits, with a
  bounded graceful allowance and forced cleanup fallback. Abrupt parent death may
  leave incomplete evidence. No automatic resume, child daemon or schedule exists.
- Baseline controls: no production defect is claimed. Fixed nonzero/missing/unbalanced
  journal fixtures and actual timeout/interruption prove refusal semantics. New tests
  exercise compatible behavior already present in baseline; no old test is weakened.
- Limits/open findings: native timing, experimental clock, benchmark assumptions,
  original05/06 exclusions, actual Unreal/human/hardware/RT/performance/signing/release
  obligations remain open. Existing32 exact-head records, full160/165, clean/head/base/
  no-unresolved-review and fetched tested merge-tree equality are integration blockers.

Disposition: implementation passes focused/package/instrumented/static/contract
review. Eligible for final full+hosted verification, then guarded scoped integration;
not global qualification or release acceptance. No high-risk finding is waived.
''')
out=r/'docs/evidence/M27-08-final-checkpoint';out.mkdir(exist_ok=False)
files=[p for p in Path('/tmp').glob('cpp-m27-08-*') if p.is_file() and p.suffix in ('.log','.json','.txt','.py')]
for folder in ['cpp-m27-08-package','cpp-m27-08-sanitizers']:
 for p in (Path('/tmp')/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and (p.suffix in ('.log','.json','.jsonl','.plist') or p.name in ('CMakeLists.txt','main.cpp','discovery.py','CMakeCache.txt','CPackConfig.cmake')):files.append(p)
records=[]
for p in sorted(set(files)):
 raw=p.read_bytes();dest=out/'retained'/(str(p.relative_to('/tmp'))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));records.append(dict(original=str(p),retained=str(dest.relative_to(out)),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
(out/'retained-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
paths=[p for folder in ['tests/platform_migration','tools/portable_soak'] for p in (r/folder).glob('*') if p.is_file()]+[r/n for n in ['tests/CMakeLists.txt','tests/package_consumer/CMakeLists.txt','tools/check_release_contract.py','docs/migration.md','docs/release_policy.md','release/rtfw-release-contract.json']]
(out/'reviewed-sources.json').write_text(json.dumps({str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
b=yaml.safe_load((r/'contracts/active-batch.yaml').read_text());changed=set(git('diff','--name-only',base).splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
for p in changed:
 assert any(fnmatch.fnmatch(p,x) for x in b['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in b['scope']['forbidden_paths']),p
(out/'scope-review.json').write_text(json.dumps(dict(baseline=base,canonical=b['sources']['canonical_revision'],changed_paths=sorted(changed)),indent=2)+'\n')
print('PASS scope/protected bytes/additive wiring/source bindings and',len(records),'retained records',flush=True)
