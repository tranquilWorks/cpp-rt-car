from pathlib import Path
import time,subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
for _ in range(180):
 p=Path('/tmp/cpp-m27-08-plan-merge.json')
 if p.exists() and json.loads(p.read_text()).get('merged'):break
 time.sleep(5)
else:raise SystemExit('Canonical activation pending')
for script in ['implement','python','docs']:
 subprocess.run(['python3','/tmp/cpp-m27-08-'+script+'.py'],check=True)
for name,args in [('contract',['./scripts/agent-verify.sh','contract']),('configure',['cmake','-S','.','-B','build/agent-quick']),('build',['cmake','--build','build/agent-quick','--target','rtfw_migration_current','rtfw_migration_legacy','--parallel','2']),('focused',['ctest','--test-dir','build/agent-quick','--output-on-failure','-R','migration_.*_lifecycle|portable_soak_journal'])]:
 with open('/tmp/cpp-m27-08-'+name+'01.log','w') as f:p=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
