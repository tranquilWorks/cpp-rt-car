from pathlib import Path
import subprocess,json,hashlib,shutil,sys
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');work=Path('/tmp/cpp-m27-08-package');work.mkdir(exist_ok=False);records=[]
def run(*args):
 args=list(map(str,args));print('COMMAND',json.dumps(args),flush=True);p=subprocess.run(args,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(p.stdout,flush=True);records.append({'command':args,'exit':p.returncode});(work/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0;return p.stdout
sdk=work/'SDK build';prefix=work/'relocated prefix';original=work/'original prefix';archives=work/'archives'
run('cmake','-S',r,'-B',sdk,'-DCMAKE_BUILD_TYPE=Release','-DENABLE_TESTS=OFF','-DRTFW_BUILD_EXAMPLES=OFF','-DRTFW_BUILD_RUNTIME_DEMO=OFF','-DRTFW_BUILD_EXPERIMENTAL=OFF','-DRTFW_BUILD_BENCHMARKS=OFF','-DRTFW_ENABLE_CUDA=OFF','-DRTFW_ENABLE_XDMA=OFF','-DSIM_SANITIZERS=','-DSIM_WERROR=ON','-DCMAKE_INSTALL_INCLUDEDIR=sdk include','-DCMAKE_INSTALL_DATADIR=custom data','-DCMAKE_INSTALL_PREFIX='+str(original))
run('cmake','--build',sdk,'--parallel','2');run('cmake','--install',sdk)
run('cpack','--config',sdk/'CPackConfig.cmake','-G','TGZ','-B',archives,'-D','CPACK_PACKAGING_INSTALL_PREFIX=/','-D','CPACK_PACKAGE_FILE_NAME=migration-current-sdk')
shutil.rmtree(original)
run(sys.executable,r/'tools/extract_release_archive.py','--artifact-dir',archives,'--destination',prefix)
source=work/'independent consumer';shutil.copytree(r/'tests/platform_migration',source)
(source/'inputs.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file()},indent=2)+'\n')
build=work/'consumer build';run('cmake','-S',source,'-B',build,'-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON');run('cmake','--build',build,'--parallel','2');run('ctest','--test-dir',build,'--output-on-failure')
commands=(build/'compile_commands.json').read_text();assert str(r) not in commands and str(sdk) not in commands and str(original) not in commands
run(sys.executable,source/'discovery.py','--prefix',prefix,'--output',work/'discovery')
outputs=[]
for kind in ['current','legacy']:
 binary=build/('rtfw_migration_'+kind);outputs.append(run(binary))
 run(sys.executable,r/'tools/portable_soak/run.py','--executable',binary,'--cycles','4096','--maximum-seconds','300','--output',work/('soak-'+kind))
assert outputs[0]==outputs[1]
print('PASS actual relocated archive, copied modern/legacy consumer equivalence, version/component discovery and two 4096-cycle fixed observations',flush=True)
