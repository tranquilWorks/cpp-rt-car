from pathlib import Path
import subprocess,json,collections,time,datetime
head=Path('/tmp/cpp-m27-08-final-identity.txt').read_text().splitlines()[0]
last=None
while True:
 p=subprocess.run(['gh','api',f'repos/tranquilWorks/cpp-rt-car/commits/{head}/check-runs?per_page=100'],capture_output=True,text=True,timeout=45)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if p.returncode:
  with open('/tmp/cpp-m27-08-monitor-api-errors.log','a') as f:f.write(now+'\n'+p.stderr+'\n')
  print(now,'API unavailable; retrying read',flush=True)
 else:
  d=json.loads(p.stdout);Path('/tmp/cpp-m27-08-final-checks-progress.json').write_text(json.dumps(d,indent=2)+'\n');rows=d['check_runs'];summary=collections.Counter((x['status'],x['conclusion']) for x in rows)
  failures=[(x['name'],x['id'],x['conclusion']) for x in rows if x['status']=='completed' and x['conclusion']!='success']
  current=(str(summary),str(failures))
  if current!=last:print(now,str(summary),'failures',failures,flush=True);last=current
  if len(rows)==32 and all(x['status']=='completed' and x['conclusion']=='success' for x in rows):print('PASS all32 final-head records',flush=True);break
 time.sleep(30)
