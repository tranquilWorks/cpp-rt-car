from pathlib import Path
import tarfile,json,hashlib,subprocess,os,resource
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');work=Path('/tmp/cpp-m27-08-sanitizers');work.mkdir(exist_ok=True)
archive=Path('/home/kbianco/.local/share/portfolio-control/evidence-archives/cpp-m27-05-sanitizer-builds.tar.gz');manifest=json.loads(archive.with_suffix('.manifest.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
assert not subprocess.check_output(['git','diff','b8d54b3aced4083dfd91d34c65e871eab7e2e3c0','HEAD','--','rt','core','include'],cwd=r,text=True)
with tarfile.open(archive) as t:
 for idx,mode in enumerate(['asan','tsan']):
  n=f'{idx}/librtfw_runtime.a';data=t.extractfile(n).read();assert hashlib.sha256(data).hexdigest()==manifest['manifest'][n]['sha256'];(work/(mode+'-runtime.a')).write_bytes(data)
records=[]
def run(name,args,env=None):
 path=work/(name+'-03.log')
 with path.open('w') as f:
  f.write(json.dumps(args)+'\n');f.flush()
  p=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=180)
 records.append({'name':name,'command':args,'exit':p.returncode});(work/'results03.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,path.read_text()
for mode in ['asan','tsan']:
 flags=['-fsanitize=address,undefined'] if mode=='asan' else ['-fsanitize=thread']
 binary=str(work/(mode+'03'))
 args=['g++','-std=c++20','-O1','-g','-fno-pie','-no-pie','-pthread','-Irt/include','-Icore/include','-Iinclude','-fno-omit-frame-pointer',*flags,'-Isamples/golden_system','tests/platform_migration/main.cpp',str(work/(mode+'-runtime.a')),'-o',binary]
 code,_=run(mode+'-build',args);assert code==0
 if mode=='asan':
  code,_=run(mode,[binary,'--cycles','16'],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'));assert code==0
 else:
  for attempt in range(1,101):
   code,out=run(mode+f'-{attempt:02}',[binary,'--cycles','16'],dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'))
   if code==0:assert 'Running under ThreadSanitizer' in out;break
   if 'WARNING: ThreadSanitizer' in out:raise SystemExit('Actual TSan finding')
   body='\n'.join(out.splitlines()[1:]).strip()
   if 'unexpected memory mapping' in out or (code==-11 and not body):continue
   raise SystemExit('Unclassified TSan failure')
  else:raise SystemExit('No initialized TSan pass')
code,out=run('static',['clang++-14','--analyze','-std=c++20','-Xanalyzer','-analyzer-output=text','-Irt/include','-Icore/include','-Iinclude','-Isamples/golden_system','tests/platform_migration/main.cpp','-o',str(work/'static.plist')]);assert code==0 and 'warning:' not in out
print('PASS complete Runtime migration consumer ASan/UBSan/leaks, initialized TSan and Clang14 static analysis',flush=True)
