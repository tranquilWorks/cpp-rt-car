from pathlib import Path
import subprocess,json,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24');t=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');b=r/'products/cpp-rt-car'
def run(*a,cwd=r):return subprocess.check_output(a,cwd=cwd,text=True).strip()
assert not run('git','status','--porcelain');run('git','fetch','origin','main');run('git','switch','-c','agent/cpp-m27-08-plan','origin/main')
run('git','fetch','origin','main',cwd=t);base=run('git','rev-parse','origin/main',cwd=t);assert base=='7567c9621d49dc113bca2fd4951cb477d5d63b67'
p=b/'batches/M27-08.yaml';d=yaml.safe_load(p.read_text());d['sources'].update(baseline_commit=base,activation='owner_selected',owner_scope='Owner explicitly selected08 after completed07/closure604. Add missing ordinary installed-package migration tests and bounded fixed C++ lifecycle/replay/owner-isolation soak with truthful journals/resource observations. Preserve original05 generated-input/continuous/scanner and06 signature exclusions. Standing scoped publication/guarded merge and completed zero-step control-only exception persist; no target/local functional waiver.')
d['dependencies']=['M27-04','M27-05','M27-06','M27-07'];d['scope']['allowed_paths']+=['tests/CMakeLists.txt'];d['scope']['forbidden_paths']+=['rt/','src/','include/','samples/golden_system/','samples/golden_cuda/','samples/golden_xdma/','samples/golden_xdma_native/','tests/golden_system/','tests/golden_cuda/','tests/golden_xdma/','tests/golden_xdma_native/','tests/runtime_robustness/','tests/release_verification/','tools/release_rebuild.py']+[f'docs/evidence/M27-0{i}-*' for i in range(1,8)]
d['acceptance'][1]='Run bounded fixed ordinary portable lifecycle/replay/expected-refusal/owner-isolation repetitions with complete logs, interruption/failure journals and resource conservation observations; distinguish logical workload from measured wall duration. No generated-input campaign, deliberate crash/memory-error fixture, scanner, workflow or continuous schedule.'
d['acceptance'].append('tests/CMakeLists.txt changes are additive new-test wiring only; preserve every existing test/assertion/deadline. Package migration uses the current actual SDK and documented same-major discovery/compatibility surfaces, never fabricated historical binaries or new supported tuples.')
d['validation']['focused_tests_to_add']=d['acceptance'][:3]
p.write_text(yaml.safe_dump(d,sort_keys=False,width=100))
intro=f'''# M27-08 selected: platform migration and bounded portable soak

Owner selected08 after target292 merged at `{base}` and canonical closure604.
Inventory the existing supported platform/package/API checks; add only missing
same-major installed-package discovery/migration behavior and ordinary fixed
lifecycle/replay/owner-isolation repetitions. Retain exact inputs, observable
outcomes, complete logs, interruption/failure journals and resource conservation
observations. Distinguish logical work from measured wall time. Additive test
wiring is permitted; all old tests, production, ABI/defaults and evidence remain.

No generated-input campaign, deliberate crash/memory-error fixture, scanner,
continuous schedule, new workflow or signature expansion is activated. Original05
and06 exclusions remain unperformed. Existing32 hosted checks, full local gates,
risk review and guarded target/canonical closure remain required and authorized.
Portable repetition is not physical endurance, controlled performance, RT, human
acceptance, release approval or deployment. Native07 full-frame TSan deadline and
historical timing/initialization limitations stay open. Actual Unreal, named
hardware qualification, signing and publication remain separate. This is the last
planned M27 software card; closure must list the finite remaining obligations.

## Historical checkpoints

'''
for name in ['README.md','CODEX_HANDOFF.md','milestones/M27.md']:
 p=b/name;p.write_text(intro+p.read_text())
p=b/'roadmap.yaml';s=p.read_text();start=s.index('  - id: M27\n');part=s[start:];assert '    next_batch: null' in part;part=part.replace('    next_batch: null','    next_batch: M27-08',1);lines=part.splitlines();i=next(i for i,l in enumerate(lines) if l.startswith('    planning_note:'));lines[i]='    planning_note: Owner selected M27-08 after completed01-07. Missing installed migration checks and bounded fixed portable soak/readiness only. Preserve original05/06 exclusions and all qualification/release boundaries.';p.write_text(s[:start]+'\n'.join(lines)+'\n')
p=b/'automation.json';d=json.loads(p.read_text());next(x for x in d['batches'] if x['id']=='M27-08')['reason']='Owner selected08: missing installed migration checks and bounded fixed portable soak/readiness; original05/06 exclusions and external qualification remain unperformed.';p.write_text(json.dumps(d,indent=2)+'\n')
for phase in ['publish','merge','pipeline']:
 s=Path('/tmp/cpp-m27-07-plan-'+phase+'.py').read_text().replace('m27-07','m27-08').replace('M27-07','M27-08').replace('native golden XDMA host preparation','platform migration and portable soak readiness')
 Path('/tmp/cpp-m27-08-plan-'+phase+'.py').write_text(s)
print('Prepared08 canonical activation')
