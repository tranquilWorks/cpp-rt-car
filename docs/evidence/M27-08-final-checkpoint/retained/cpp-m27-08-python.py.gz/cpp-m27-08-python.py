from pathlib import Path
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def write(name,s):(r/name).write_text(s)
write('tools/portable_soak/run.py',r'''#!/usr/bin/env python3
"""Bounded fixed public-API repetition; no daemon, scheduling or hardware access."""
import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path

FIELDS = dict(frames=193, logical_ns=19300, owners=2, acquired=6, released=6,
              live=0, checkpoint_reexecutions=1, expected_refusals=2)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(command, cycles, seconds, output):
    if not 1 <= cycles <= 10000 or not 0 < seconds <= 3600:
        raise ValueError('cycles must be 1..10000; seconds must be >0 and <=3600')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    args = [*map(str, command), '--cycles', str(cycles)]
    report = dict(schema=1, command=args, requested_cycles=cycles, maximum_wall_seconds=seconds,
                  executable_sha256=digest(command[0]), runner_sha256=digest(__file__),
                  started_unix_ns=time.time_ns(), status='started',
                  resource_scope='three provider regions per owner; not total process memory',
                  claim='bounded portable fixed-workload observation; no endurance or timing qualification')
    journal = output / 'journal.jsonl'
    def record():
        with journal.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(report, sort_keys=True) + '\n')
            stream.flush()
    record()
    start = time.monotonic()
    child = None
    reason = None
    try:
        with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
            child = subprocess.Popen(args, stdout=stdout, stderr=stderr)
            while child.poll() is None:
                if time.monotonic() - start >= seconds:
                    reason = 'timeout'; break
                if stdout.tell() + stderr.tell() > 8 * 1024 * 1024:
                    reason = 'log_limit'; break
                time.sleep(0.02)
    except KeyboardInterrupt:
        reason = 'interrupted'
    except OSError as error:
        reason = 'launch_failed'
        report['error'] = str(error)
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait()
    report['elapsed_wall_seconds'] = time.monotonic() - start
    report['returncode'] = child.returncode if child is not None else None
    report['status'] = reason or ('passed' if report['returncode'] == 0 else 'failed')
    report['completed_cycles'] = 0
    try:
        lines = (output / 'stdout.log').read_text(encoding='utf-8').splitlines()
        for index, line in enumerate(lines, 1):
            value = json.loads(line)
            expected = dict(FIELDS, cycle=index)
            if value != expected or any(type(value[k]) is not int for k in expected):
                raise ValueError('cycle record does not match fixed workload/resource contract')
            report['completed_cycles'] += 1
        if report['status'] == 'passed' and len(lines) != cycles:
            raise ValueError('successful process did not finish the requested cycles')
        if len(lines) > cycles:
            raise ValueError('extra cycle records')
        if digest(command[0]) != report['executable_sha256']:
            raise ValueError('executable changed during observation')
    except (ValueError, OSError) as error:
        report['validation_error'] = str(error)
        if report['status'] == 'passed':
            report['status'] = 'invalid_output'
    report['totals'] = {key: value * report['completed_cycles'] for key, value in FIELDS.items()}
    report['logs'] = {name: dict(bytes=(output / name).stat().st_size, sha256=digest(output / name))
                      for name in ('stdout.log', 'stderr.log') if (output / name).exists()}
    record()
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--executable', type=Path, required=True)
    parser.add_argument('--cycles', type=int, default=1024)
    parser.add_argument('--maximum-seconds', type=float, default=300)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        report = run([args.executable.resolve()], args.cycles, args.maximum_seconds, args.output)
    except (OSError, ValueError) as error:
        parser.exit(2, str(error) + '\n')
    print(json.dumps(report, sort_keys=True))
    return {'passed': 0, 'timeout': 124, 'interrupted': 130}.get(report['status'], 1)

if __name__ == '__main__':
    raise SystemExit(main())
''')
write('tools/portable_soak/test_run.py',r'''import json
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
import run

class JournalTests(unittest.TestCase):
    def execute(self, source, cycles=2, seconds=3):
        folder=Path(self.temp.name)
        fixture=folder/'fixture.py'; fixture.write_text(source, encoding='utf-8')
        output=folder/'result'
        value=run.run([sys.executable, fixture], cycles, seconds, output)
        records=[json.loads(line) for line in (output/'journal.jsonl').read_text().splitlines()]
        self.assertEqual(records[0]['status'], 'started')
        self.assertEqual(records[-1], value)
        self.assertEqual(json.loads((output/'report.json').read_text()), value)
        return value, output
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
    def test_actual_success_and_existing_output_refusal(self):
        source='import json\n'+''.join('print('+repr(json.dumps(dict(run.FIELDS,cycle=i)))+')\n' for i in (1,2))
        value, output=self.execute(source)
        self.assertEqual(value['status'],'passed')
        self.assertEqual(value['totals']['frames'],386)
        self.assertEqual(value['totals']['acquired'],value['totals']['released'])
        with self.assertRaises(FileExistsError): run.run([sys.executable],2,1,output)
    def test_nonzero_retains_complete_diagnostic(self):
        value,output=self.execute('import sys\nprint("ordinary fixture refusal",file=sys.stderr)\nsys.exit(7)\n')
        self.assertEqual(value['status'],'failed');self.assertEqual(value['returncode'],7)
        self.assertIn('ordinary fixture refusal',(output/'stderr.log').read_text())
    def test_zero_exit_missing_rows_is_not_success(self):
        value,_=self.execute('pass\n');self.assertEqual(value['status'],'invalid_output')
    def test_unbalanced_resource_record_is_not_success(self):
        value,_=self.execute('print('+repr(json.dumps(dict(run.FIELDS,cycle=1,released=5)))+')\n',cycles=1)
        self.assertEqual(value['status'],'invalid_output')
    def test_timeout_reaps_child(self):
        value,_=self.execute('import time\ntime.sleep(30)\n',seconds=.1)
        self.assertEqual(value['status'],'timeout');self.assertIsNotNone(value['returncode'])
        self.assertLess(value['elapsed_wall_seconds'],10)
    @unittest.skipIf(sys.platform=='win32','POSIX signal delivery fixture')
    def test_interrupt_has_terminal_journal(self):
        root=Path(self.temp.name); fixture=root/'interrupted.py'; output=root/'result'
        fixture.write_text('import sys\nsys.path.insert(0,'+repr(str(Path(run.__file__).parent))+')\nimport run\nrun.run([sys.executable,"-c","import time; time.sleep(30)"],2,20,'+repr(str(output))+')\n')
        child=subprocess.Popen([sys.executable,str(fixture)])
        try:
            for _ in range(200):
                if (output/'stdout.log').exists():break
                time.sleep(.01)
            else:self.fail('fixture did not start')
            time.sleep(.05);child.send_signal(signal.SIGINT);child.wait(timeout=10)
            value=json.loads((output/'report.json').read_text())
            self.assertEqual(value['status'],'interrupted');self.assertIsNotNone(value['returncode'])
        finally:
            if child.poll() is None:child.kill();child.wait()
if __name__=='__main__':unittest.main()
''')
write('tests/platform_migration/discovery.py',r'''#!/usr/bin/env python3
"""Check current installed package against documented version/component requests."""
import argparse
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    root=Path(tempfile.mkdtemp(prefix='attempt-',dir=args.output))
    cases=[('v10','1.0','runtime',True),('v11','1.1','cpp_runtime',True),
           ('v12','1.2','runtime',True),('exact','1.2.1 EXACT','runtime',True),
           ('future_patch','1.2.2','runtime',False),('major','2.0','runtime',False),
           ('old_exact','1.1 EXACT','runtime',False),('unknown','1.2','missing_component',False)]
    records=[]
    for name,version,component,success in cases:
        source=root/name;source.mkdir()
        cmake='cmake_minimum_required(VERSION 3.20)\nproject(migration LANGUAGES CXX)\n'
        cmake+=f'find_package(rtfw {version} CONFIG REQUIRED COMPONENTS {component})\n'
        cmake+='if(NOT RTFW_VERSION STREQUAL "1.2.1" OR NOT TARGET rtfw::runtime OR NOT TARGET rtfw::simcore_rt)\nmessage(FATAL_ERROR "migration target/version mismatch")\nendif()\n'
        cmake+='find_package(rtfw 1.2 CONFIG REQUIRED COMPONENTS runtime OPTIONAL_COMPONENTS missing_component)\nif(rtfw_missing_component_FOUND)\nmessage(FATAL_ERROR "unknown optional component admitted")\nendif()\n'
        (source/'CMakeLists.txt').write_text(cmake,encoding='utf-8')
        command=['cmake','-S',str(source),'-B',str(source/'build'),'-DCMAKE_PREFIX_PATH='+str(args.prefix.resolve()),'-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF','-DCMAKE_FIND_USE_SYSTEM_PACKAGE_REGISTRY=OFF']
        with (source/'configure.log').open('w',encoding='utf-8') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
        output=(source/'configure.log').read_text(encoding='utf-8')
        okay=(result.returncode==0)==success
        if not success:
            okay=okay and ('Could not find a configuration file for package "rtfw"' in output or 'rtfw_FOUND to FALSE' in output)
        records.append(dict(name=name,request=version,component=component,expected_success=success,
                            command=command,returncode=result.returncode,passed=okay,
                            input_sha256=hashlib.sha256(cmake.encode()).hexdigest(),
                            log_sha256=hashlib.sha256((source/'configure.log').read_bytes()).hexdigest()))
        (root/'report.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
        if not okay:raise SystemExit('Unexpected discovery result: '+str(source/'configure.log'))
    print('PASS eight current-package version/component requests; retained '+str(root))
if __name__=='__main__':main()
''')
print('Wrote bounded runner, behavioral journal tests and actual discovery matrix')
