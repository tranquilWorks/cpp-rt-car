from pathlib import Path
import subprocess,json,os,tarfile,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m28-02-focused02');w.mkdir(exist_ok=True);records=[]
def run(name,cmd,env=None):
 with (w/(name+'.log')).open('w') as f:
  f.write(json.dumps(cmd)+'\n');f.flush();p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=240)
 records.append(dict(name=name,command=cmd,exit=p.returncode));(w/'results.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,(w/(name+'.log')).read_text()
base=w/'baseline';base.mkdir(exist_ok=True);(base/'device.cpp').write_bytes(subprocess.check_output(['git','show','ab22bb4580de18794fcb2bad2b72b4e8a1e104c5:bench/providers/runtime_cases/device.cpp'],cwd=r))
for label,provider in [('baseline',base),('current',r/'bench/providers/runtime_cases')]:
 out=w/label;out.mkdir(exist_ok=True);code,log=run(label+'-generate',['python3','tests/closeout_benchmark/prepare.py','--provider-directory',str(provider),'--output',str(out/'device-observed.hpp')]);assert code==0,log
 cmd=['g++','-std=c++20','-O1','-g1','-Wall','-Wextra','-Werror','-I'+str(out),'-Ibench/providers/runtime_cases','-Ibench/include','-Iinclude','-Irt/include','-Icore/include','tests/closeout_benchmark/accounting.cpp','build/agent-full/librtfw_runtime.a','-pthread','-o',str(out/'accounting')]
 code,log=run(label+'-build',cmd);assert code==0,log
 code,log=run(label+'-run',[str(out/'accounting')]);assert code==(1 if label=='baseline' else 0),log
 if label=='baseline':assert 'Observed invariant rejection' in log
 print(label,code,flush=True)
archive=Path('/home/kbianco/.local/share/portfolio-control/evidence-archives/cpp-m27-05-sanitizer-builds.tar.gz');manifest=json.loads(archive.with_suffix('.manifest.json').read_text());assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256'];assert not subprocess.check_output(['git','diff','b8d54b3aced4083dfd91d34c65e871eab7e2e3c0','--','rt','core'],cwd=r,text=True)
for mode in ['asan','tsan']:
 binary=str(w/(mode+'-accounting'));cmd=['g++','-std=c++20','-O1','-g1','-fno-pie','-no-pie','-pthread','-fno-omit-frame-pointer','-I'+str(w/'current'),'-Ibench/providers/runtime_cases','-Ibench/include','-Iinclude','-Irt/include','-Icore/include','-fsanitize='+('address,undefined' if mode=='asan' else 'thread'),'tests/closeout_benchmark/accounting.cpp',str(Path('/tmp/cpp-m28-02-focused')/(mode+'-runtime.a')),'-o',binary]
 code,log=run(mode+'-build',cmd);assert code==0,log
 if mode=='asan':
  code,log=run(mode+'-run',[binary],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'));assert code==0,log
 else:
  for n in range(1,101):
   code,log=run(mode+f'-run-{n:02}',[binary],dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'))
   if code==0:assert 'Running under ThreadSanitizer' in log;break
   if 'WARNING: ThreadSanitizer' in log:raise RuntimeError(log)
   body='\n'.join(log.splitlines()[1:]).strip()
   if 'unexpected memory mapping' in log or (code==-11 and not body):continue
   raise RuntimeError((code,log))
  else:raise RuntimeError('No initialized TSan result')
 print(mode,'PASS',flush=True)
cmd=['clang++-14','--analyze','-std=c++20','-Xanalyzer','-analyzer-output=text','-I'+str(w/'current'),'-Ibench/providers/runtime_cases','-Ibench/include','-Iinclude','-Irt/include','-Icore/include','tests/closeout_benchmark/accounting.cpp','-o',str(w/'accounting.plist')]
code,log=run('static',cmd);assert code==0 and 'warning:' not in log,log
print('PASS baseline rejection, corrected controls, ASan/UBSan/leaks, initialized TSan and static analysis',flush=True)
