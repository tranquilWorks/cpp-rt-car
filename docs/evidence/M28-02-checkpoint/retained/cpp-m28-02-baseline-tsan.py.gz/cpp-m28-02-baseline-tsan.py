from pathlib import Path
import subprocess,json,os
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m28-02-baseline-tsan');w.mkdir(exist_ok=False)
s=(r/'tests/closeout_benchmark/accounting.cpp').read_text();s=s[:s.index('int main()')]+'''int main() {try {failure_case("unchanged-after-acceptance",closeout::Schedule::after_acceptance);return 0;}catch(const std::exception& e){std::fprintf(stderr,"FAIL %s\\n",e.what());return 1;}}\n''';(w/'baseline.cpp').write_text(s)
cmd=['g++','-std=c++20','-O1','-g1','-fno-pie','-no-pie','-pthread','-fno-omit-frame-pointer','-fsanitize=thread','-I/tmp/cpp-m28-02-focused/baseline','-Ibench/providers/runtime_cases','-Ibench/include','-Iinclude','-Irt/include','-Icore/include',str(w/'baseline.cpp'),'/tmp/cpp-m28-02-focused/tsan-runtime.a','-o',str(w/'baseline')];(w/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (w/'build.log').open('w') as f:subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=180)
for n in range(1,101):
 with (w/f'run-{n:02}.log').open('w') as f:p=subprocess.run([str(w/'baseline')],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=60,env=dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'))
 log=(w/f'run-{n:02}.log').read_text()
 if 'WARNING: ThreadSanitizer' in log:
  assert 'cancel_batch' in log and 'submit_batch' in log
  (w/'result.json').write_text(json.dumps(dict(attempt=n,exit=p.returncode,classification='unchanged provider loopback cancel/submit data race'),indent=2)+'\n');print('REPRODUCED baseline race',n,flush=True);break
 if 'unexpected memory mapping' in log or (p.returncode==-11 and not log.strip()):continue
 raise RuntimeError((p.returncode,log))
else:raise RuntimeError('No initialized result')
