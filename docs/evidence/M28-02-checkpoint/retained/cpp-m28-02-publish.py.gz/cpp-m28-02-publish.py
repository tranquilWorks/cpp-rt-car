from pathlib import Path
import subprocess,json,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'PASS scoped risk review' in Path('/tmp/cpp-m28-02-review.log').read_text()
assert run('git','branch','--show-current')=='agent/m28-02-benchmark'
bindings=json.loads((r/'docs/evidence/M28-02-checkpoint/reviewed-sources.json').read_text())
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
paths=run('git','diff','--name-only','HEAD').splitlines()+run('git','ls-files','--others','--exclude-standard').splitlines()
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','fix: reconcile benchmark timeout acceptance after checked shutdown'),flush=True)
head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');assert not run('git','status','--porcelain');Path('/tmp/cpp-m28-02-final-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','-u','origin','agent/m28-02-benchmark'),flush=True)
body='The timeout benchmark assumed the backend had already accepted one submission when the original1ms deadline expired. A retained unchanged held-submit control proves a valid terminal with zero accepted submissions. Reconcile terminal observations with exactly one submit attempt, its returned status and stable backend copy/action/completion/cancellation counts after checked shutdown, while preserving all terminal and nonpublication checks.\n\nInitialized TSan also reproduces a pre-existing loopback cancellation/publication race on unchanged provider source. A fixture-owned observer for failure/timeout cases publishes the submit result before forwarding cancellation, with no callback mutex/allocation or Runtime/backend change. The broader direct-backend race remains open for later software closeout; this is a provider-local correction.\n\nValidation:26 fixed real-provider schedule/accounting scenarios, baseline negatives, ASan/UBSan/leaks, initialized TSan, Clang14 static,17 selected benchmark CTests including original inventories/no-allocation, actual relocated CPack with copied accounting/provider/modern-legacy consumers and installed fake/steady CLI validators. Old tests, catalog/schema, Runtime/native/experimental sources,1ms deadline and ABI/defaults remain unchanged. Exact-head full180 portable/168 strict, all32 hosted names/multiplicity and committed-source repackaging remain required before guarded integration.\n\nCanonical activation610 and amendment611. Retain the original historical hosted benchmark cause as unproven, startup/native timing findings, optional experimental SDK HAL-header gap and original05/06 exclusions. M28-03..06 and all final owner-stage qualification/release work remain inactive. Details and raw evidence: docs/evidence/M28-02-*.\n' + f'\nExact head `{head}`, tree `{tree}`.\n'
Path('/tmp/cpp-m28-02-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/cpp-rt-car/pulls?state=open&head=tranquilWorks:agent/m28-02-benchmark'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m28-02-create.json');p.write_text(json.dumps({'title':'fix: benchmark timeout and submission accounting (M28-02)','head':'agent/m28-02-benchmark','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(p));Path('/tmp/cpp-m28-02-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m28-02-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/cpp-rt-car/pull/'+str(number),flush=True)
