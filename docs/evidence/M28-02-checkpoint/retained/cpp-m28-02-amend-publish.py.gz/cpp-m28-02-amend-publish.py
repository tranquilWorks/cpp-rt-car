from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m28-02-amend-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m28-02-amend'
Path('/tmp/cpp-m28-02-amend-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
paths=['products/cpp-rt-car/'+x for x in ['automation.json','milestones/M28.md','README.md','CODEX_HANDOFF.md','roadmap.yaml','batches/M28-02.yaml']]
changed=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed,set(paths))
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','plan(cpp-rt-car): activate M28-02 benchmark acceptance and cancellation ordering'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m28-02-amend-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m28-02-amend'),flush=True)
body=(r/'products/cpp-rt-car/README.md').read_text().split('## Historical checkpoints')[0]+f'\nFull local control validation passed at `{head}`, tree `{tree}`. Hosted validation and guarded integration remain required.\n'
Path('/tmp/cpp-m28-02-amend-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m28-02-amend'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m28-02-amend-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M28-02 benchmark acceptance and cancellation ordering','head':'agent/cpp-m28-02-amend','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m28-02-amend-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m28-02-amend-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
