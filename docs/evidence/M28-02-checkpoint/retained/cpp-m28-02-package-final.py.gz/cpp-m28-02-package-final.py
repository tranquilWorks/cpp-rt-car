from pathlib import Path
import subprocess,json,hashlib,shutil,sys
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m28-02-package-final');w.mkdir(exist_ok=False);records=[]
def run(*args):
 args=list(map(str,args));print('COMMAND',json.dumps(args),flush=True)
 p=subprocess.run(args,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=1200)
 print(p.stdout,flush=True);records.append(dict(command=args,exit=p.returncode));(w/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0;return p.stdout
sdk=Path('/tmp/cpp-m28-02-package/SDK build');prefix=w/'relocated prefix';original=w/'original prefix';archives=w/'archives'
run('cmake','-S',r,'-B',sdk,'-DCMAKE_BUILD_TYPE=Release','-DENABLE_TESTS=OFF','-DRTFW_BUILD_EXAMPLES=OFF','-DRTFW_BUILD_RUNTIME_DEMO=OFF','-DRTFW_BUILD_EXPERIMENTAL=OFF','-DRTFW_BUILD_BENCHMARKS=ON','-DRTFW_ENABLE_CUDA=OFF','-DRTFW_ENABLE_XDMA=OFF','-DSIM_SANITIZERS=','-DSIM_WERROR=ON','-DCMAKE_INSTALL_PREFIX='+str(original))
run('cmake','--build',sdk,'--parallel','2');run('cmake','--install',sdk)
run('cpack','--config',sdk/'CPackConfig.cmake','-G','TGZ','-B',archives,'-D','CPACK_PACKAGING_INSTALL_PREFIX=/','-D','CPACK_PACKAGE_FILE_NAME=benchmark-sdk')
shutil.rmtree(original);run(sys.executable,r/'tools/extract_release_archive.py','--artifact-dir',archives,'--destination',prefix)
examples=prefix/'share/rtfw/bench/examples'
for label,source_path in [('accounting','tests/closeout_benchmark'),('provider','tests/benchmark_fixtures/runtime_consumer'),('migration','tests/platform_migration')]:
 source=w/('independent '+label);shutil.copytree(r/source_path,source);build=w/(label+' build')
 args=['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
 if label=='accounting':args+=['-DRTFW_BENCHMARK_EXAMPLES='+str(examples)]
 run(*args);run('cmake','--build',build,'--parallel','2');run('ctest','--test-dir',build,'--output-on-failure')
 commands=(build/'compile_commands.json').read_text();assert str(r) not in commands and str(sdk) not in commands and str(original) not in commands
cli=prefix/'bin/rtfw-bench';validator=prefix/'share/rtfw/tools/check_benchmark_artifact.py'
for clock in ['fake','steady']:
 for case in ['device-timeout-nonpublication','device-failure-nonpublication']:
  output=w/(clock+'-'+case);run(cli,'run','--provider','rtfw.runtime','--case',case,'--clock',clock,'--output',output);run(sys.executable,validator,'--artifact-root',output)
  result=json.loads((output/'result.json').read_text());assert result['status']=='ok' and result['warmup_completed']==2 and result['measured_completed']==5
head,tree=Path('/tmp/cpp-m28-02-final-identity.txt').read_text().splitlines()
for result_path in w.glob('*-device-*/result.json'):
 identity=json.loads(result_path.read_text())['identity'];assert identity['source_commit']==head and identity['source_tree']==tree and identity['source_dirty']=='false'
installed=examples/'runtime_cases/device.cpp';assert installed.read_bytes()==(r/'bench/providers/runtime_cases/device.cpp').read_bytes()
contracts=list(prefix.rglob('rtfw-release-contract.json'));assert len(contracts)==1 and contracts[0].read_bytes()==(r/'release/rtfw-release-contract.json').read_bytes()
paths=['bench/providers/runtime_cases/device.cpp','tests/closeout_benchmark/accounting.cpp','tests/closeout_benchmark/prepare.py','tests/closeout_benchmark/CMakeLists.txt','release/rtfw-release-contract.json'];(w/'source-bindings.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
print('PASS actual relocated benchmark CPack, copied accounting/provider/current-legacy consumers and installed fake/steady CLI validators',flush=True)
