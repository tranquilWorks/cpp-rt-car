from pathlib import Path
import subprocess,json,os
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
w=Path('/tmp/cpp-m28-01-baseline');w.mkdir(exist_ok=True)
src=r'''#include <simcore/highres_clock.hpp>
#include <atomic>
#include <barrier>
#include <cstdio>
#include <cstring>
std::atomic<unsigned> calls{0};
std::atomic<bool> release{false};
uint64_t counter() { return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count()); }
uint64_t held() {
 const auto n=calls.fetch_add(1);
 if(n==0) while(!release.load()) std::this_thread::yield();
 return counter();
}
int main(int argc,char** argv) {
 if(argc>1 && std::strcmp(argv[1],"race")==0) {
  std::barrier start(3);
  auto work=[&]{start.arrive_and_wait();for(int i=0;i<3;++i){HighResClock::init(counter);for(int j=0;j<1000;++j)(void)HighResClock::now();}};
  std::thread a(work),b(work);start.arrive_and_wait();a.join();b.join();
  std::puts("concurrent initialization complete");return 0;
 }
 HighResClock::init(counter);
 std::thread writer([]{HighResClock::init(held);});
 while(calls.load()==0)std::this_thread::yield();
 (void)HighResClock::now();
 const auto during=calls.load();release=true;writer.join();
 std::printf("reader calls while calibration held=%u (expected 1)\n",during);
 return during==1?0:41;
}
'''
(w/'probe.cpp').write_text(src)
records=[]
def run(name,cmd,env=None):
 with (w/(name+'.log')).open('w') as f:
  f.write(json.dumps(cmd)+'\n');f.flush();p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=60)
 records.append({'name':name,'command':cmd,'exit':p.returncode});(w/'results.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,(w/(name+'.log')).read_text()
for mode in ['ordinary','tsan']:
 cmd=['g++','-std=c++20','-O1','-g','-pthread','-fno-pie','-no-pie','-Iinclude',str(w/'probe.cpp'),'-o',str(w/mode)]
 if mode=='tsan':cmd+=['-fsanitize=thread','-fno-omit-frame-pointer']
 code,_=run(mode+'-build',cmd);assert code==0
 if mode=='ordinary':
  code,out=run('ordinary',[str(w/mode)]);assert code==41 and 'calibration held=2' in out
 else:
  for n in range(1,101):
   code,out=run(f'tsan-{n:02}',[str(w/mode),'race'],dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'))
   if 'WARNING: ThreadSanitizer: data race' in out:
    assert 'HighResClock::init' in out;break
   body='\n'.join(out.splitlines()[1:]).strip()
   if 'unexpected memory mapping' in out or (code==-11 and not body):continue
   raise RuntimeError((code,out))
  else:raise RuntimeError('No initialized TSan result')
print('PASS retained baseline partial-publication failure and initialized TSan initialization race')
