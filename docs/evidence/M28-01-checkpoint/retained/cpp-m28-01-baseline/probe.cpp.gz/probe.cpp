#include <simcore/highres_clock.hpp>
#include <atomic>
#include <barrier>
#include <cstdio>
#include <cstring>
std::atomic<unsigned> calls{0};
std::atomic<bool> release{false};
uint64_t counter() { return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count()); }
uint64_t held() {
 const auto n=calls.fetch_add(1);
 if(n==0) while(!release.load()) std::this_thread::yield();
 return counter();
}
int main(int argc,char** argv) {
 if(argc>1 && std::strcmp(argv[1],"race")==0) {
  std::barrier start(3);
  auto work=[&]{start.arrive_and_wait();for(int i=0;i<3;++i){HighResClock::init(counter);for(int j=0;j<1000;++j)(void)HighResClock::now();}};
  std::thread a(work),b(work);start.arrive_and_wait();a.join();b.join();
  std::puts("concurrent initialization complete");return 0;
 }
 HighResClock::init(counter);
 std::thread writer([]{HighResClock::init(held);});
 while(calls.load()==0)std::this_thread::yield();
 (void)HighResClock::now();
 const auto during=calls.load();release=true;writer.join();
 std::printf("reader calls while calibration held=%u (expected 1)\n",during);
 return during==1?0:41;
}
