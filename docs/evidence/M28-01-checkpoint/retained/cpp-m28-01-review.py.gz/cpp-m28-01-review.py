from pathlib import Path
import subprocess,json,hashlib,gzip,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
for name,token in [('sanitizers','PASS clock and owner'),('regressions03','PASS original clock/timing'),('package02','PASS actual relocated'),('contract-final','completed=')]:
 assert token in Path('/tmp/cpp-m28-01-'+name+'.log').read_text(),name
base='389e3fc84cfc2a5946b6e555befdff0962f3989a'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('diff',base,'--','rt','src','core','abi','VERSION.txt','LICENSE','configs','profiles','.github/workflows','samples')
old=subprocess.check_output(['git','show',base+':tests/CMakeLists.txt'],cwd=r);assert (r/'tests/CMakeLists.txt').read_bytes().startswith(old)
for p in git('ls-tree','-r','--name-only',base,'tests').splitlines():
 if p!='tests/CMakeLists.txt':assert not git('diff',base,'--',p),p
for p in git('ls-tree','-r','--name-only',base,'include').splitlines():
 if p!='include/simcore/highres_clock.hpp':assert not git('diff',base,'--',p),p
evidence='''# M28-01 concurrent experimental clock initialization

Baseline target293 `389e3fc84cfc2a5946b6e555befdff0962f3989a`;
canonical activation608 `937a5b100ba48798d0fafc6bfb57457c16ef600b`.
Only the experimental clock header changes production behavior. Supported Runtime,
all other production headers/sources, old tests, ABI/defaults and workflows remain
byte-identical. New CMake wiring is appended to the exact previous test file.

## Cause and correction

The unchanged public entry point deterministically exposes a replacement reader
while its calibration is held: the new callback is called twice where only its
single calibration entry should be visible (exit41). Initialized TSan independently
reports concurrent initialization writes to HighResClock::tsc_reader_. A separate
concurrent SimCore-owner baseline also reports this same global data race. No
fixture construction lock is used for that control.

Initialization calibrates under a writer-only mutex, then publishes an even
generation with atomic reader/frequency/epoch fields. Sequentially consistent
operations make one equal-even snapshot consistent; readers encountering a
publication immediately use the existing monotonic fallback. Read paths never
take the writer mutex or retry the snapshot. The pre-existing monotonic CAS loop
remains. Failed samples disable only their own generation; stale readers cannot
disable a newer initialization. Failed calibration disables TSC, and init never
resets the shared monotonic floor. Calibration remains50ms and drift bound1ms.
Generation exhaustion disables TSC instead of reusing an identity.

Injected function pointers remain borrowed. Concurrently used callbacks must be
thread-safe, valid throughout outstanding calls, and non-reentrant into init or
set_tsc_reader. No plugin lifetime management or physical timing guarantee is
added. This repairs the shared clock, not every experimental SimCore global policy.
The owner test uses the existing FMA-off configuration and retains caller-thread
arena construction/run/destruction. Broader global FMA-policy concurrency is not
qualified or changed by this batch.

## Validation at the reviewed implementation

- New strict source-build clock and owner tests pass. Held calibration cannot
  publish its reader; old failed reads cannot disable replacement; null/invalid
  calibration falls back and valid reinit recovers. Concurrent init/read/setter
  preserves per-reader monotonicity. Clock read/reinit paths allocate zero tracked
  C++ heap objects, with a positive allocation-counter control.
- Two independent owners construct, run16 exact integer frames and destruct on
  their own caller threads with2/4 workers, repeated three times. Exact independent
  outputs pass without a fixture construction mutex.
- New clock/owner ASan+UBSan+leak checks, initialized TSan and Clang14 static
  analysis pass. Complete affected header/platform source is instrumented; the
  unchanged supported Runtime archive is reused only after source and archive/member
  hashes match its retained instrumented build. Legacy runtime.cpp is not linked
  into these direct instrumentation probes.
- Unmodified original clock/integration, timing-reliability and2/4/8-thread FMA-off
  determinism tests pass ASan+UBSan+leaks and initialized TSan. The unchanged prior
  clock-outlier/floor and watchdog-stop causal-control runner also passes, retaining
  its original baseline failures. TSan pre-main mapping failures remain distinct
  from initialized findings and passes; none is relabeled as a passing test.
- An actual optional experimental CPack archive is extracted under a relocated
  custom include/data prefix after deleting the original install. The copied
  standalone clock test passes using the byte-identical installed header. Existing
  copied public Runtime modern/legacy migration consumers both pass against this
  archive, without checkout/build/original-prefix include paths.
- Contract checks, SDK/audit generation and release hash validation pass. Full local
  profiles (expected portable161/strict167), all32 original exact-head hosted checks,
  and final committed-source repackaging remain required before integration. Final
  receipts belong to the guarded PR/canonical closure; this precommit checkpoint
  does not invent completed final-head gates.

## Retained failures and remaining work

The first new allocation probe hit GCC's inlined mismatched-new-delete diagnostic;
out-of-line/noinline test replacement delete functions corrected the probe without
disabling warnings. The first owner link lacked the existing experimental platform
library; new wiring now links it and adds owner coverage only in source experimental
builds. An initial baseline overlay included both current and old clock headers via
quoted includes; a complete unchanged include-tree copy fixes the diagnostic setup.
The baseline-owner TSan report inlines init into SimCore's constructor but names the
clock global; the diagnostic classifier was corrected and the original report kept.

The first installed full-owner consumer exposed a pre-existing optional experimental
SDK packaging gap: simcore/hal.hpp includes an absent hal.hpp. This is retained as
an unresolved software packaging finding for later M28 closeout triage, not repaired
or passed here. Standalone installation validation is scoped to the clock and the
supported public Runtime targets; full-owner tests stay in the source build. No old
package test, test count, requirement or default installation is weakened.

M28-02..06 remain unperformed. The benchmark/startup/native-frame timing findings,
original05/06 excluded scope and final owner hardware/RT/Unreal/performance/human/
production-signing/release/deployment acceptance remain separate. No physical or
RT claim follows. Revert this header correction and new test wiring for rollback;
retain every predecessor source and evidence record.
'''
(r/'docs/evidence/M28-01-2026-10-02.md').write_text(evidence)
risk='''# M28-01 risk review

No unresolved finding in the bounded clock correction after reviewed focused gates.
Final full/hosted/package/source-tree guards remain mandatory before integration.

- Atomic snapshot: every concurrently accessed calibration field is atomic. All
  field and generation accesses are SC; equal even generations cannot bracket a
  different publication. A snapshot is attempted once and never waits for a writer.
- Writers serialize calibration and replacement off the read path. Callback
  reentry into a writer is unsupported and documented; callbacks remain borrowed.
  Holding calibration cannot block ordinary reads, proven by the held-reader test.
- Failure is generation-specific. A stale callback's result neither reads a mixed
  calibration nor disables a replacement, proven by held stale-sample ordering.
- init cannot lower the monotonic floor; invalid samples still receive the existing
  pre-publication finite/range/drift validation. Original causal controls are kept.
- Zero/allocation control and lock-free atomic assertions protect the read path.
  The existing monotonic CAS loop is retained, not newly claimed wait-free or RT.
- The correction remains experimental. Supported Runtime/default ABI/support tuples
  are unchanged. FMA-off owner tests preserve caller-thread arenas; no universal
  SimCore global-policy concurrency guarantee is inferred.
- Installed full-SimCore missing HAL header is a real pre-existing limitation;
  the failed attempt is retained and scoped installed clock plus supported Runtime
  verification cannot close that separate software packaging finding.
- Old source tests/assertions/deadlines and evidence are byte-preserved. The new
  standalone clock test does not change old installed consumer inventories.

Validation evidence and unperformed gates are in M28-01-2026-10-02.md and the
retained manifest. Only the exact final-head full/all32/package and guarded merge
receipts may establish final software integration. No independent human review or
external qualification is fabricated by this risk review.
'''
(r/'docs/evidence/M28-01-risk-review.md').write_text(risk)
out=r/'docs/evidence/M28-01-checkpoint';out.mkdir(exist_ok=True);retained=[]
paths=list(Path('/tmp').glob('cpp-m28-01-*.log'))+list(Path('/tmp').glob('cpp-m28-01-*.py'))
for dirname in ['baseline','sanitizers','regressions','regressions02','regressions03','package','package02']:
 directory=Path('/tmp/cpp-m28-01-'+dirname)
 paths+=list(directory.rglob('*.log'))+list(directory.rglob('results.json'))+list(directory.rglob('commands.json'))+list(directory.rglob('source-bindings.json'))
paths+=[Path('/tmp/cpp-m28-01-baseline/probe.cpp')]
for p in sorted(set(paths)):
 if not p.is_file():continue
 raw=p.read_bytes();dest=out/'retained'/(str(p.relative_to('/tmp'))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));retained.append({'original':str(p),'retained':str(dest.relative_to(out)),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
(out/'retained-manifest.json').write_text(json.dumps(retained,indent=2)+'\n')
changed=git('diff','--name-only',base).splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
contract=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
for p in changed:
 assert any(fnmatch.fnmatch(p,x) for x in contract['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in contract['scope']['forbidden_paths']),p
bindings={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in sorted(set(changed)) if not p.startswith('docs/evidence/')}
(out/'reviewed-sources.json').write_text(json.dumps(bindings,indent=2)+'\n')
print('PASS scoped risk review, protected-byte checks and retained',len(retained),'raw evidence files')
