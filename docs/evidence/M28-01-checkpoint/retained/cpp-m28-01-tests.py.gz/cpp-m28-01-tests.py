from pathlib import Path
w=Path('/tmp/cpp-m28-01-new-tests');w.mkdir(exist_ok=True)
(w/'clock.cpp').write_text(r'''#include <simcore/highres_clock.hpp>
#include <array>
#include <atomic>
#include <barrier>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <thread>

namespace {
thread_local bool track_allocations = false;
std::atomic<unsigned> allocations{0};
void check(bool value, const char* message) {
    if (!value) { std::fprintf(stderr, "FAIL %s\n", message); std::abort(); }
}
std::uint64_t steady() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count());
}
std::uint64_t zero() { return 0; }
std::atomic<unsigned> calls{0};
std::atomic<bool> release{false};
std::uint64_t calibrating() {
    if (calls.fetch_add(1) == 0)
        while (!release.load()) std::this_thread::yield();
    return steady();
}
std::atomic<bool> hold_sample{false}, entered{false};
std::uint64_t stale() {
    if (hold_sample.load()) {
        entered = true;
        while (!release.load()) std::this_thread::yield();
        return 0;
    }
    return steady();
}
void publication() {
    HighResClock::init(steady);
    check(HighResClock::using_tsc(), "initial calibration");
    calls = 0; release = false;
    std::thread writer([] { HighResClock::init(calibrating); });
    while (calls.load() == 0) std::this_thread::yield();
    // Must return while the writer is held, and must not call its new reader.
    const auto before = HighResClock::now();
    const auto during = calls.load();
    release = true; writer.join();
    check(during == 1, "unpublished reader observed");
    check(HighResClock::now() > before, "reinitialization regressed time");
    HighResClock::init(zero);
    check(!HighResClock::using_tsc(), "failed calibration retained old enable");
    HighResClock::init(steady);
    check(HighResClock::using_tsc(), "valid recalibration did not recover");
    HighResClock::set_tsc_reader(nullptr);
    check(!HighResClock::using_tsc(), "null reader remained enabled");
    check(HighResClock::now() > before, "null fallback regressed");
}
void stale_failure() {
    hold_sample = false; release = false; entered = false;
    HighResClock::init(stale);
    hold_sample = true;
    std::thread delayed([] { (void)HighResClock::now(); });
    while (!entered.load()) std::this_thread::yield();
    HighResClock::init(steady);
    check(HighResClock::using_tsc(), "replacement calibration failed");
    release = true; delayed.join();
    check(HighResClock::using_tsc(), "stale sample disabled replacement");
}
void concurrent() {
    HighResClock::init(steady);
    std::barrier start(4);
    std::array<bool, 4> okay{true, true, true, true};
    const auto run = [&](std::size_t index) {
        start.arrive_and_wait();
        auto previous = HighResClock::now();
        for (unsigned cycle = 0; cycle < 4; ++cycle) {
            if (index < 2) HighResClock::init(steady);
            else if (index == 2) HighResClock::set_tsc_reader(steady);
            for (unsigned i = 0; i < 4000; ++i) {
                const auto next = HighResClock::now();
                okay[index] = okay[index] && next > previous;
                previous = next;
            }
        }
    };
    std::array<std::thread, 4> workers;
    for (std::size_t i = 0; i < workers.size(); ++i) workers[i] = std::thread(run, i);
    for (auto& worker : workers) worker.join();
    for (bool result : okay) check(result, "concurrent monotonicity");
}
void allocation() {
    HighResClock::init(steady);
    allocations = 0;
    track_allocations = true;
    auto previous = HighResClock::now();
    for (unsigned i = 0; i < 4096; ++i) {
        const auto next = HighResClock::now();
        check(next > previous, "allocation probe monotonicity"); previous = next;
    }
    HighResClock::set_tsc_reader(nullptr);
    HighResClock::init(zero);
    (void)HighResClock::now();
    track_allocations = false;
    check(allocations.load() == 0, "clock allocated");
    // Positive control proves this executable's allocation counter is active.
    track_allocations = true;
    void* control = ::operator new(17);
    track_allocations = false;
    ::operator delete(control);
    check(allocations.load() == 1, "allocation counter control");
}
}
void* operator new(std::size_t size) {
    if (track_allocations) allocations.fetch_add(1);
    if (void* p = std::malloc(size ? size : 1)) return p;
    throw std::bad_alloc();
}
void* operator new[](std::size_t size) { return ::operator new(size); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, std::size_t) noexcept { std::free(p); }
void operator delete[](void* p, std::size_t) noexcept { std::free(p); }
int main() {
    publication(); stale_failure(); concurrent(); allocation();
    HighResClock::init();
    std::puts("PASS calibration publication, stale failure, concurrent read/init/replacement and allocation controls");
}
''')
(w/'owners.cpp').write_text(r'''#include <simcore/SimCore.hpp>
#include <array>
#include <barrier>
#include <cstdio>
#include <thread>
#include <vector>

int main() {
    std::barrier stage(2);
    std::array<bool, 2> okay{true, true};
    const auto run = [&](std::size_t index) {
        for (unsigned iteration = 0; iteration < 3; ++iteration) {
            stage.arrive_and_wait();
            {
                SimCore::Settings settings;
                settings.threads = index == 0 ? 2 : 4;
                settings.maxFrames = 16; settings.hz = 1000;
                settings.autoTuneChunks = false; settings.chunkSize = 127;
                settings.rateGovernorEnable = false; settings.driftLogInterval = 0;
                settings.useFMA = false;
                // No fixture construction mutex: owners construct, execute and
                // destruct on their own caller threads, preserving arena binding.
                SimCore owner(settings);
                const double initial = static_cast<double>(index * 100 + iteration);
                std::vector<double> values(1025, initial);
                const auto phase = owner.addPhase("increment", values.size());
                owner.addParallelRangeTask(phase, [&](std::size_t begin, std::size_t end,
                                                     std::int64_t, SimCore::Seconds) {
                    for (auto i = begin; i < end; ++i) values[i] += 1;
                });
                stage.arrive_and_wait();
                owner.run();
                for (double value : values) okay[index] = okay[index] && value == initial + 16;
                stage.arrive_and_wait();
            }
            stage.arrive_and_wait();
        }
    };
    std::thread first(run, 0), second(run, 1); first.join(); second.join();
    if (!okay[0] || !okay[1]) return 1;
    std::puts("PASS concurrent caller-thread owner construction/run/destruction, three cycles, exact independent outputs");
}
''')
(w/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.20)
if(CMAKE_SOURCE_DIR STREQUAL CMAKE_CURRENT_SOURCE_DIR)
  project(rtfw_closeout_clock LANGUAGES CXX)
  enable_testing()
  find_package(rtfw 1.2 CONFIG REQUIRED COMPONENTS cpp_runtime experimental)
endif()
foreach(kind IN ITEMS clock owners)
  add_executable(rtfw_closeout_${kind} ${kind}.cpp)
  target_compile_features(rtfw_closeout_${kind} PRIVATE cxx_std_20)
  target_link_libraries(rtfw_closeout_${kind} PRIVATE rtfw::simcore_rt)
  if(WIN32)
    target_link_libraries(rtfw_closeout_${kind} PRIVATE psapi)
  endif()
  if(COMMAND rtfw_enable_project_warnings)
    rtfw_enable_project_warnings(rtfw_closeout_${kind})
  endif()
  add_test(NAME closeout_${kind} COMMAND rtfw_closeout_${kind})
  set_tests_properties(closeout_${kind} PROPERTIES TIMEOUT 60)
endforeach()
''')
print('Prepared focused clock and concurrent-owner tests')
