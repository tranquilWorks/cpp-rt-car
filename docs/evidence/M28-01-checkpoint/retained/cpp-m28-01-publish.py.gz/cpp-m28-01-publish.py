from pathlib import Path
import subprocess,json,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'PASS scoped risk review' in Path('/tmp/cpp-m28-01-review.log').read_text()
assert run('git','branch','--show-current')=='agent/m28-01-clock'
bindings=json.loads((r/'docs/evidence/M28-01-checkpoint/reviewed-sources.json').read_text())
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
paths=run('git','diff','--name-only','HEAD').splitlines()+run('git','ls-files','--others','--exclude-standard').splitlines()
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','fix: publish concurrent experimental clock calibration consistently'),flush=True)
head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');assert not run('git','status','--porcelain');Path('/tmp/cpp-m28-01-final-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','-u','origin','agent/m28-01-clock'),flush=True)
body='''Concurrent experimental clock initialization wrote shared calibration fields while other owners read or initialized them. A held-calibration public-API control and initialized TSan reproduce the baseline defect. Serialize writers off the read path and publish versioned atomic calibration; readers take one snapshot attempt and immediately fall back during publication. Stale failed reads cannot disable a new generation, failed calibration falls back, and reinitialization preserves the monotonic floor.

New tests cover publication ordering, stale replacement, concurrent read/init/setter, allocation controls and repeated caller-thread owner lifecycle. Existing clock, timing and2/4/8-thread determinism tests remain unchanged. New and original focused instrumentation passes ASan/UBSan/leaks and initialized TSan; Clang14 static and relocated installed clock plus modern/legacy Runtime consumers pass. Full local161/167, all32 original hosted checks and final-source repackaging remain required before guarded integration.

The existing optional full-SimCore SDK omits a required HAL header. Retain its failed installed-owner attempt as a separate unresolved packaging finding; owner lifecycle verification uses the source build. This repairs only the experimental clock, preserves50ms calibration/1ms drift, and makes no broader SimCore global-policy, hardware, RT or release claim. M28-02..06 remain inactive. Detailed failures, scope, rollback and risk review are in docs/evidence/M28-01-*.
'''+f'\nExact head `{head}`, tree `{tree}`. Canonical activation608.\n'
Path('/tmp/cpp-m28-01-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/cpp-rt-car/pulls?state=open&head=tranquilWorks:agent/m28-01-clock'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m28-01-create.json');p.write_text(json.dumps({'title':'fix: concurrent experimental clock initialization (M28-01)','head':'agent/m28-01-clock','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(p));Path('/tmp/cpp-m28-01-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m28-01-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/cpp-rt-car/pull/'+str(number),flush=True)
