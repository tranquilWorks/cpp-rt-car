from pathlib import Path
import subprocess,json,os,shutil
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');w=Path('/tmp/cpp-m28-01-regressions03');w.mkdir(exist_ok=True);records=[]
def run(name,cmd,env=None,timeout=300):
 with (w/(name+'.log')).open('w') as f:
  f.write(json.dumps(cmd)+'\n');f.flush();p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=timeout)
 records.append({'name':name,'command':cmd,'exit':p.returncode});(w/'results.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,(w/(name+'.log')).read_text()
def tsan(name,binary,args=(),negative=False):
 for n in range(1,101):
  code,out=run(name+f'-{n:02}',[str(binary),*args],dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'))
  if negative and 'WARNING: ThreadSanitizer: data race' in out:
   assert 'HighResClock::init' in out or "Location is global 'HighResClock::" in out;return
  if code==0 and not negative:assert 'Running under ThreadSanitizer' in out;return
  if 'WARNING: ThreadSanitizer' in out:raise RuntimeError(out)
  body='\n'.join(out.splitlines()[1:]).strip()
  if 'unexpected memory mapping' in out or (code==-11 and not body):continue
  raise RuntimeError((code,out))
 raise RuntimeError('No initialized TSan result')
shutil.copytree(r/'include',w/'baseline',dirs_exist_ok=True)
baseline=w/'baseline/simcore'
(baseline/'highres_clock.hpp').write_bytes(subprocess.check_output(['git','show','389e3fc84cfc2a5946b6e555befdff0962f3989a:include/simcore/highres_clock.hpp'],cwd=r))
common=['g++','-std=c++20','-O1','-g1','-fno-pie','-no-pie','-pthread','-fno-omit-frame-pointer','-Iinclude','-Irt/include','-Icore/include','-Ihal','-Igpu']
cmd=common[:1]+['-I'+str(baseline.parent)]+common[1:]+['-fsanitize=thread','tests/closeout_clock/owners.cpp','src/platform_init.cpp','src/metrics.cpp','/tmp/cpp-m28-01-sanitizers/tsan-runtime.a','-o',str(w/'baseline-owners')]
code,out=run('baseline-owners-build',cmd);assert code==0,out;tsan('baseline-owners',w/'baseline-owners',negative=True)
sources=['tests/test_highres_clock.cpp','tests/test_highres_clock_integration.cpp','tests/test_simcore_determinism.cpp','tests/test_timing_reliability.cpp','src/platform_init.cpp','src/metrics.cpp']
for mode in ['asan','tsan']:
 binary=w/(mode+'-original-tests')
 cmd=common+['-Iexternal/googletest/googletest/include','-fsanitize='+('address,undefined' if mode=='asan' else 'thread'),*sources,'build/agent-full/lib/libgtest_main.a','build/agent-full/lib/libgtest.a','/tmp/cpp-m28-01-sanitizers/'+mode+'-runtime.a','-o',str(binary)]
 code,out=run(mode+'-build',cmd,timeout=600);assert code==0,out
 args=['--gtest_filter=HighResClock.*:HighResClockIntegration.*:SimCoreTimingReliability.*:CrossMatrixDeterminism/*FmaOff']
 if mode=='asan':
  code,out=run('asan',[str(binary),*args],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'));assert code==0,out
 else:tsan('tsan',binary,args)
code,out=run('original-clock-stop',['python3','tests/timing_reliability/verify_clock_stop.py','--output-directory',str(w/'original-clock-stop')]);assert code==0,out
print('PASS original clock/timing/2-4-8-thread determinism ASan/UBSan/leaks and initialized TSan, original causal controls; retained concurrent-owner baseline race')
