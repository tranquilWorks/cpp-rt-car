from pathlib import Path
import subprocess,json,os,tarfile,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
w=Path('/tmp/cpp-m28-01-sanitizers');w.mkdir(exist_ok=True);records=[]
archive=Path('/home/kbianco/.local/share/portfolio-control/evidence-archives/cpp-m27-05-sanitizer-builds.tar.gz')
manifest=json.loads(archive.with_suffix('.manifest.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archive_sha256']
assert not subprocess.check_output(['git','diff','b8d54b3aced4083dfd91d34c65e871eab7e2e3c0','--','rt','core'],cwd=r,text=True)
with tarfile.open(archive) as t:
 for idx,mode in enumerate(['asan','tsan']):
  n=f'{idx}/librtfw_runtime.a';data=t.extractfile(n).read();assert hashlib.sha256(data).hexdigest()==manifest['manifest'][n]['sha256'];(w/(mode+'-runtime.a')).write_bytes(data)
def run(name,cmd,env=None):
 with (w/(name+'.log')).open('w') as f:
  f.write(json.dumps(cmd)+'\n');f.flush();p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=240)
 records.append({'name':name,'command':cmd,'exit':p.returncode});(w/'results.json').write_text(json.dumps(records,indent=2)+'\n');return p.returncode,(w/(name+'.log')).read_text()
for mode in ['asan','tsan']:
 for kind in ['clock','owners']:
  cmd=['g++','-std=c++20','-O1','-g1','-fno-pie','-no-pie','-pthread','-fno-omit-frame-pointer','-Iinclude','-Irt/include','-Icore/include','-Ihal','-Igpu','-fsanitize='+('address,undefined' if mode=='asan' else 'thread'),'tests/closeout_clock/'+kind+'.cpp']
  if kind=='owners':cmd+=['src/platform_init.cpp','src/metrics.cpp',str(w/(mode+'-runtime.a'))]
  binary=str(w/(mode+'-'+kind));cmd+=['-o',binary];code,out=run(mode+'-'+kind+'-build',cmd);assert code==0,out
  if mode=='asan':
   code,out=run(mode+'-'+kind,[binary],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'));assert code==0,out
  else:
   for n in range(1,101):
    code,out=run(mode+'-'+kind+f'-{n:02}',[binary],dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'))
    if code==0:assert 'Running under ThreadSanitizer' in out;break
    if 'WARNING: ThreadSanitizer' in out:raise RuntimeError(out)
    body='\n'.join(out.splitlines()[1:]).strip()
    if 'unexpected memory mapping' in out or (code==-11 and not body):continue
    raise RuntimeError((code,out))
   else:raise RuntimeError('No initialized TSan result')
for kind in ['clock','owners']:
 cmd=['clang++-14','--analyze','-std=c++20','-Xanalyzer','-analyzer-output=text','-Iinclude','-Irt/include','-Icore/include','-Ihal','-Igpu','tests/closeout_clock/'+kind+'.cpp','-o',str(w/(kind+'.plist'))]
 code,out=run('static-'+kind,cmd);assert code==0 and 'warning:' not in out,out
print('PASS clock and owner ASan/UBSan/leaks, initialized TSan and Clang14 static analysis')
