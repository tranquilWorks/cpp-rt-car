from pathlib import Path
import subprocess,json,hashlib,shutil,sys
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
w=Path('/tmp/cpp-m28-01-package02');w.mkdir(exist_ok=False);records=[]
def run(*args):
 args=list(map(str,args));print('COMMAND',json.dumps(args),flush=True)
 p=subprocess.run(args,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 print(p.stdout,flush=True);records.append({'command':args,'exit':p.returncode});(w/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert p.returncode==0;return p.stdout
sdk=w/'SDK build';prefix=w/'relocated prefix';original=w/'original prefix';archives=w/'archives'
run('cmake','-S',r,'-B',sdk,'-DCMAKE_BUILD_TYPE=Release','-DENABLE_TESTS=OFF','-DRTFW_BUILD_EXAMPLES=OFF','-DRTFW_BUILD_RUNTIME_DEMO=OFF','-DRTFW_BUILD_EXPERIMENTAL=ON','-DRTFW_INSTALL_EXPERIMENTAL=ON','-DRTFW_BUILD_BENCHMARKS=OFF','-DRTFW_ENABLE_CUDA=OFF','-DRTFW_ENABLE_XDMA=OFF','-DSIM_SANITIZERS=','-DSIM_WERROR=ON','-DCMAKE_INSTALL_INCLUDEDIR=sdk include','-DCMAKE_INSTALL_DATADIR=custom data','-DCMAKE_INSTALL_PREFIX='+str(original))
run('cmake','--build',sdk,'--parallel','2');run('cmake','--install',sdk)
run('cpack','--config',sdk/'CPackConfig.cmake','-G','TGZ','-B',archives,'-D','CPACK_PACKAGING_INSTALL_PREFIX=/','-D','CPACK_PACKAGE_FILE_NAME=clock-sdk')
shutil.rmtree(original)
run(sys.executable,r/'tools/extract_release_archive.py','--artifact-dir',archives,'--destination',prefix)
for label,source_path in [('clock','tests/closeout_clock'),('migration','tests/platform_migration')]:
 source=w/('independent '+label);shutil.copytree(r/source_path,source)
 build=w/(label+' build');run('cmake','-S',source,'-B',build,'-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON');run('cmake','--build',build,'--parallel','2');run('ctest','--test-dir',build,'--output-on-failure')
 commands=(build/'compile_commands.json').read_text();assert str(r) not in commands and str(sdk) not in commands and str(original) not in commands
installed=prefix/'sdk include/simcore/highres_clock.hpp';assert installed.read_bytes()==(r/'include/simcore/highres_clock.hpp').read_bytes()
contracts=list(prefix.rglob('rtfw-release-contract.json'));assert len(contracts)==1 and contracts[0].read_bytes()==(r/'release/rtfw-release-contract.json').read_bytes()
(w/'source-bindings.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in ['include/simcore/highres_clock.hpp','tests/closeout_clock/clock.cpp','tests/closeout_clock/owners.cpp','tests/closeout_clock/CMakeLists.txt','release/rtfw-release-contract.json']},indent=2)+'\n')
print('PASS actual relocated experimental CPack, copied clock consumer and current/legacy public Runtime migration')
