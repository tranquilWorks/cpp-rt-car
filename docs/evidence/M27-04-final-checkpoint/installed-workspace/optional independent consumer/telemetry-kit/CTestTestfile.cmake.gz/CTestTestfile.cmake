# CMake generated Testfile for 
# Source directory: /tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/integrations/telemetry
# Build directory: /tmp/telemetry relocated 4uf0t0kq/optional independent consumer/telemetry-kit
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[telemetry_example]=] "/tmp/telemetry relocated 4uf0t0kq/optional independent consumer/telemetry-kit/rtfw_telemetry_example")
set_tests_properties([=[telemetry_example]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/integrations/telemetry/CMakeLists.txt;22;add_test;/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/integrations/telemetry/CMakeLists.txt;0;")
