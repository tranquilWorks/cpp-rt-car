# CMake generated Testfile for 
# Source directory: /tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime
# Build directory: /tmp/telemetry relocated 4uf0t0kq/all prior SDK consumers/typed-runtime
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[typed_runtime_output]=] "/usr/bin/cmake" "-DTYPED_EXECUTABLE=/tmp/telemetry relocated 4uf0t0kq/all prior SDK consumers/typed-runtime/typed_runtime" "-P" "/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime/check_output.cmake")
set_tests_properties([=[typed_runtime_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime/CMakeLists.txt;19;add_test;/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/typed_runtime/CMakeLists.txt;0;")
