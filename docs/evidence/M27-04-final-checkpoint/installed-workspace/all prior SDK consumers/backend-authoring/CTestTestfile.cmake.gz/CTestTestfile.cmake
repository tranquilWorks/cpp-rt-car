# CMake generated Testfile for 
# Source directory: /tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring
# Build directory: /tmp/telemetry relocated 4uf0t0kq/all prior SDK consumers/backend-authoring
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[backend_authoring_output]=] "/usr/bin/cmake" "-DBACKEND_EXECUTABLE=/tmp/telemetry relocated 4uf0t0kq/all prior SDK consumers/backend-authoring/backend_authoring" "-P" "/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/check_output.cmake")
set_tests_properties([=[backend_authoring_output]=] PROPERTIES  TIMEOUT "30" _BACKTRACE_TRIPLES "/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/CMakeLists.txt;19;add_test;/tmp/telemetry relocated 4uf0t0kq/optional relocated SDK with spaces/custom data/rtfw/examples/backend_authoring/CMakeLists.txt;0;")
