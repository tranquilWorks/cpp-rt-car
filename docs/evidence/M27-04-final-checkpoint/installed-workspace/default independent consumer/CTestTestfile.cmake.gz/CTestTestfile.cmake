# CMake generated Testfile for 
# Source directory: /tmp/telemetry relocated 4uf0t0kq/independent tests/telemetry_export
# Build directory: /tmp/telemetry relocated 4uf0t0kq/default independent consumer
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[telemetry_queue]=] "/tmp/telemetry relocated 4uf0t0kq/default independent consumer/rtfw_telemetry_tests")
set_tests_properties([=[telemetry_queue]=] PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/tmp/telemetry relocated 4uf0t0kq/independent tests/telemetry_export/CMakeLists.txt;18;add_test;/tmp/telemetry relocated 4uf0t0kq/independent tests/telemetry_export/CMakeLists.txt;0;")
add_test([=[telemetry_spool_contract]=] "/home/kbianco/.local/bin/python3.12" "/tmp/telemetry relocated 4uf0t0kq/independent tests/telemetry_export/test_spool.py" "/tmp/telemetry relocated 4uf0t0kq/default relocated SDK with spaces/custom data/rtfw/integrations/telemetry/export.py" "/tmp/telemetry relocated 4uf0t0kq/default independent consumer/telemetry-kit/rtfw_telemetry_example")
set_tests_properties([=[telemetry_spool_contract]=] PROPERTIES  TIMEOUT "60" _BACKTRACE_TRIPLES "/tmp/telemetry relocated 4uf0t0kq/independent tests/telemetry_export/CMakeLists.txt;21;add_test;/tmp/telemetry relocated 4uf0t0kq/independent tests/telemetry_export/CMakeLists.txt;0;")
subdirs("telemetry-kit")
