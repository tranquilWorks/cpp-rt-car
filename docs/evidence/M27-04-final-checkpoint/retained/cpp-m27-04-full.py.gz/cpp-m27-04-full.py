from pathlib import Path
import subprocess,json,datetime
root=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
head,tree=Path('/tmp/cpp-m27-04-final-identity.txt').read_text().splitlines()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
logs=sorted(Path('/tmp').glob('cpp-m27-04-full[0-9][0-9].log'));p=Path('/tmp/cpp-m27-04-full%02d.log'%(len(logs)+1))
with p.open('w') as f:r=subprocess.run(['./scripts/agent-verify.sh','full'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
result={'head':head,'tree':tree,'log':str(p),'exit_code':r.returncode,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}
Path('/tmp/cpp-m27-04-final-full-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
if r.returncode==0:
 s=p.read_text();assert f'head={head}' in s and 'completed=' in s
 assert all(f'100% tests passed, 0 tests failed out of {n}' in s for n in (155,160))
 Path('/tmp/cpp-m27-04-passing-full.txt').write_text(str(p)+'\n')
raise SystemExit(r.returncode)
