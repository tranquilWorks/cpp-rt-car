from pathlib import Path
import subprocess,json,os,time,hashlib
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');records=[]
bindings=json.loads(Path('/tmp/cpp-m27-04-gate-source-bindings.json').read_text())
def verify():assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in bindings.items())
def go(label,args,env=None):
 verify();p=Path('/tmp/cpp-m27-04-'+label+'.log');start=time.monotonic()
 with p.open('w') as f:
  f.write('COMMAND '+json.dumps(args)+'\n');f.flush()
  try:x=subprocess.run(args,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=180);code=x.returncode
  except subprocess.TimeoutExpired:code=124
 records.append(dict(label=label,command=args,exit=code,seconds=time.monotonic()-start,log=str(p)))
 Path('/tmp/cpp-m27-04-sanitizer-results03.json').write_text(json.dumps(records,indent=2));verify();return code,p.read_text()
base=['g++','-std=c++20','-g','-O1','-pthread','-Irt/include','-Icore/include','-Iinclude','-Iintegrations/telemetry','integrations/telemetry/telemetry.cpp','tests/telemetry_export/main.cpp','build/agent-quick/librtfw_runtime.a']
code,_=go('asan-build03',base+['-fsanitize=address,undefined','-fno-omit-frame-pointer','-o','/tmp/cpp-m27-04-asan']);assert code==0
code,_=go('asan',['/tmp/cpp-m27-04-asan'],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'));assert code==0
code,_=go('tsan-build',base+['-fsanitize=thread','-o','/tmp/cpp-m27-04-tsan']);assert code==0
for attempt in range(1,81):
 code,out=go('tsan-%02d'%attempt,['/tmp/cpp-m27-04-tsan'],dict(os.environ,TSAN_OPTIONS='halt_on_error=1'))
 if code==0:break
 if 'unexpected memory mapping' not in out:raise SystemExit('Real TSan failure; inspect '+records[-1]['log'])
else:raise SystemExit('TSan never initialized; unperformed')
code,_=go('static',['clang++-14','--analyze','-std=c++20','-Xanalyzer','-analyzer-output=text','-Irt/include','-Icore/include','-Iinclude','-Iintegrations/telemetry','integrations/telemetry/telemetry.cpp','-o','/tmp/cpp-m27-04-static.plist']);assert code==0
print('PASS ASan/UBSan/leak, initialized TSan, clang static; new queue/test code instrumented, unchanged Runtime archive not reinstrumented',flush=True)
