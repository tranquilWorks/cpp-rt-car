from pathlib import Path
import json,subprocess,os,hashlib,resource
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');bindings=json.loads(Path('/tmp/cpp-m27-04-gate-source-bindings02.json').read_text());records=[]
assert '__tsan::InitializeAllocator' in Path('/tmp/cpp-m27-04-tsan-diagnostics/attempt04.log').read_text()
def limits():resource.setrlimit(resource.RLIMIT_FSIZE,(2097152,2097152))
for i in range(1,81):
 assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
 log=Path('/tmp/cpp-m27-04-tsan-resume-%02d.log'%i)
 with log.open('w') as f:
  p=subprocess.run(['/tmp/cpp-m27-04-tsan'],cwd=r,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'),timeout=60,preexec_fn=limits)
 s=log.read_text();records.append(dict(attempt=i,exit=p.returncode,log=str(log)))
 Path('/tmp/cpp-m27-04-tsan-resume-results.json').write_text(json.dumps(records,indent=2))
 if p.returncode==0:
  assert 'PASS bounded queue' in s;print('PASS initialized TSan',i,flush=True);break
 if 'WARNING: ThreadSanitizer' in s:raise SystemExit('Actual sanitizer finding: '+str(log))
 if 'unexpected memory mapping' in s:continue
 if p.returncode==-11 and not s.strip():continue # actual pre-main allocator mmap crash captured above
 raise SystemExit('Unclassified failure: '+str(log))
else:raise SystemExit('TSan did not initialize; remains UNPERFORMED')
