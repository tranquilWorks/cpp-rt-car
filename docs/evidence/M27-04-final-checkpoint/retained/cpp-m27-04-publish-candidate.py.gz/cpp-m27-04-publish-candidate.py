from pathlib import Path
import subprocess,json,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'completed=' in Path('/tmp/cpp-m27-04-contract02.log').read_text()
assert run('git','branch','--show-current')=='agent/m27-04-telemetry'
b=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
paths=run('git','diff','--name-only','HEAD').splitlines()+run('git','ls-files','--others','--exclude-standard').splitlines()
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in b['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in b['scope']['forbidden_paths']),p
 assert '__pycache__' not in p,p
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','feat: add optional native telemetry source kit (M27-04 candidate)'),flush=True)
head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-04-candidate01-identity.txt').write_text(head+'\n'+tree+'\n')
print(run('git','push','-u','origin','agent/m27-04-telemetry'),flush=True)
body='''Add an optional installed source kit for bounded, caller-owned host telemetry capture. It produces native Perfetto protobuf, OTLP/HTTP logs/metrics and Windows TraceLogging without changing Runtime, public schema/ABI, default SDK targets/headers or predecessor implementations/tests.

The queue preserves cursors on full, disabled and failed capture; sink failures retain snapshots. Explicit session/Runtime/clock correlation separates Runtime losses, queue rejections and transport delivery semantics. Native formats carry exact identities and original event timestamps.

Candidate validation: three portable CTests (including five parser cases), actual Perfetto Trace Processor 34 events/128 metrics with zero import errors, real OpenTelemetry Collector 34 logs/128 metrics, six transport rejection cases and repository contract/ABI checks PASS. Windows native ETL/TDH collection runs in existing Windows CI. Final sanitizer/static/relocated package/full/all32 exact-head gates, risk review and guarded integration/canonical closure are pending. This draft is not a completion claim. M27-05..08 and independent qualification/release activities remain inactive.
'''
Path('/tmp/cpp-m27-04-pr.md').write_text(body)
existing=json.loads(run('gh','api','repos/tranquilWorks/cpp-rt-car/pulls?state=open&head=tranquilWorks:agent/m27-04-telemetry'));assert len(existing)<=1
if existing:number=existing[0]['number']
else:
 payload=Path('/tmp/cpp-m27-04-create.json');payload.write_text(json.dumps({'title':'feat: optional native telemetry exporters (M27-04)','head':'agent/m27-04-telemetry','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/cpp-rt-car/pulls','--input',str(payload));Path('/tmp/cpp-m27-04-create-result.json').write_text(raw);number=json.loads(raw)['number']
Path('/tmp/cpp-m27-04-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/cpp-rt-car/pull/'+str(number),flush=True)
