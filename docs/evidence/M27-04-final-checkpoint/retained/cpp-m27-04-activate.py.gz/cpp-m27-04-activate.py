from pathlib import Path
import json,subprocess,yaml,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');c=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
for _ in range(180):
 p=Path('/tmp/cpp-m27-04-plan-merge.log')
 if p.exists() and 'MERGED' in p.read_text():break
 time.sleep(5)
else:raise SystemExit('Canonical merge pending')
m=json.loads(Path('/tmp/cpp-m27-04-plan-merge.json').read_text());assert m['merged'];rev=m['sha'];path='products/cpp-rt-car/batches/M27-04.yaml'
def run(*a):return subprocess.check_output(a,cwd=r,text=True).strip()
assert not run('git','status','--porcelain');assert run('git','rev-parse','origin/main')=='5f9a8a4c554cb065cb2ace33f10444d07466c313';run('git','switch','-c','agent/m27-04-telemetry','origin/main')
raw=subprocess.check_output(['git','show',rev+':'+path],cwd=c);blob=subprocess.check_output(['git','rev-parse',rev+':'+path],cwd=c,text=True).strip();d=yaml.safe_load(raw);d['sources'].update(control_plane_revision=rev,canonical_revision=rev,canonical_blob_sha=blob);(r/'contracts/active-batch.yaml').write_text(yaml.safe_dump(d,sort_keys=False,width=100))
with (r/'AGENTS.md').open('a') as f:f.write('\n## M27-04 activation\n\nCanonical plan595 merged at '+rev+', blob '+blob+'.\nThe owner selected04 after completed target288/control594. Deliver only the\noptional installed telemetry source kit with bounded host queue, explicit\nclock/owner/loss semantics and real native Perfetto/OTLP/Windows ETW consumers.\nPreserve Runtime, default SDK, experimental/native sources, original tests and\nprior evidence. Full local/all32 exact-head/native/sanitizer/static/relocated\ngates and guarded target/canonical closure remain required under standing\nscoped publication/merge authority. M27-05..08 and external qualification/\nUnreal/human/signing/release/deployment remain inactive.\n')
print('ACTIVATED',rev,blob,flush=True)
