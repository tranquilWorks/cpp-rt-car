from pathlib import Path
import json,gzip,hashlib,subprocess,fnmatch,yaml,shutil
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24');out=r/'docs/evidence/M27-04-final-checkpoint'
assert 'PASS default/optional actual CPack' in Path('/tmp/cpp-m27-04-package04.log').read_text()
assert 'PASS queue and shipped example' in Path('/tmp/cpp-m27-04-loss-final-sanitizers-progress.log').read_text()
assert json.loads(Path('/tmp/cpp-m27-04-native05/result.json').read_text())['collector_metrics']==128
bindings=json.loads(Path('/tmp/cpp-m27-04-gate-source-bindings04.json').read_text());assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in bindings.items())
out.mkdir(exist_ok=False);records=[]
skip={'cpp-m27-04-tools-venv','cpp-m27-04-predecessor-package'}
for root in sorted(Path('/tmp').glob('cpp-m27-04-*')):
 if root.name in skip:continue
 paths=[root] if root.is_file() else sorted(root.rglob('*')) if root.is_dir() else []
 for p in paths:
  if not p.is_file() or p.is_symlink():continue
  if p.name=='cpp-m27-04-asan.log.gz':
   raw=p.read_bytes();dest=out/'retained'/p.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
   records.append(dict(original=str(p),retained=str(dest.relative_to(out)),stored_bytes=len(raw),stored_sha256=hashlib.sha256(raw).hexdigest(),encoding='original gzip; decompressed hash/size in asan.archive.json'));continue
  if p.suffix not in ('.log','.json','.txt','.py','.cpp','.hpp','.md','.plist','.ndjson','.pb','.pftrace','.stdout','.stderr','.yaml'):continue
  if p.stat().st_size>20_000_000:raise RuntimeError('Unexpected large artifact '+str(p))
  raw=p.read_bytes();relative=p.relative_to('/tmp');dest=out/'retained'/str(relative.parent)/(relative.name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0))
  records.append(dict(original=str(p),retained=str(dest.relative_to(out)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
for name in ('result.json','negative.log'):
 p=Path('/tmp/cpp-m27-04-predecessor-package')/name;raw=p.read_bytes();dest=out/'retained/predecessor'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);records.append(dict(original=str(p),retained=str(dest.relative_to(out)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
(out/'retained-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'risk-review.md').write_bytes((r/'docs/evidence/M27-04-risk-review.md').read_bytes())
for p in [r/'samples/golden_audit/catalog.py',r/'tests/golden_audit/test_catalog.py',r/'docs/golden_audit/capabilities.json',r/'tools/check_release_contract.py']:
 bindings[str(p.relative_to(r))]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'reviewed-sources.json').write_text(json.dumps(bindings,indent=2)+'\n')
paths=set(subprocess.check_output(['git','diff','--name-only','5f9a8a4c554cb065cb2ace33f10444d07466c313'],cwd=r,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines());batch=yaml.safe_load((r/'contracts/active-batch.yaml').read_text())
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in batch['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in batch['scope']['forbidden_paths']),p
protected=['rt','include','bench','hal','gpu','abi','VERSION.txt','LICENSE','tests/test_observability.cpp','tests/test_timing_reliability.cpp','tests/timing_reliability','tests/package_consumer/package_contract.cmake','.github/workflows']
for path in protected:assert not subprocess.check_output(['git','diff','--name-only','5f9a8a4c554cb065cb2ace33f10444d07466c313','--',path],cwd=r,text=True).strip(),path
(out/'scope-review.json').write_text(json.dumps(dict(canonical=batch['sources']['canonical_revision'],baseline=batch['sources']['baseline_commit'],changed_paths=sorted(paths),protected_unchanged=protected),indent=2)+'\n')
package=r/'build/m27-04-package04';installed=[]
for p in sorted(package.rglob('*')):
 if p.is_file() and p.suffix in ('.log','.json','.txt','.md','.stdout','.stderr','.pb','.pftrace','.ndjson'):
  raw=p.read_bytes();dest=out/'installed'/(str(p.relative_to(package))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));installed.append(dict(path=str(p.relative_to(package)),sha256=hashlib.sha256(raw).hexdigest()))
workspace=Path((package/'relocation-directory.txt').read_text().strip())
for p in sorted(workspace.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 if 'independent tests' in p.parts or p.name in ('compile_commands.json','provenance.json','LastTest.log','CTestTestfile.cmake','CMakeCache.txt'):
  raw=p.read_bytes();dest=out/'installed-workspace'/(str(p.relative_to(workspace))+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(raw,mtime=0));installed.append(dict(workspace_path=str(p.relative_to(workspace)),sha256=hashlib.sha256(raw).hexdigest()))
(out/'installed-evidence.json').write_text(json.dumps(installed,indent=2)+'\n')
print('PASS retained',len(records),'artifacts;',len(installed),'installed records; scope/protected/source bindings',flush=True)
