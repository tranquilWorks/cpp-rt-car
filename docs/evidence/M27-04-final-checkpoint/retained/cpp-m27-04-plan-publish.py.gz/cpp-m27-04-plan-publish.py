from pathlib import Path
import subprocess,json
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'Control plane validation passed.' in Path('/tmp/cpp-m27-04-plan-control.log').read_text()
assert run('git','branch','--show-current')=='agent/cpp-m27-04-plan'
Path('/tmp/cpp-m27-04-plan-base.txt').write_text(run('git','rev-parse','HEAD')+'\n')
paths=['products/cpp-rt-car/'+x for x in ['automation.json','milestones/M27.md','README.md','CODEX_HANDOFF.md','roadmap.yaml','batches/M27-04.yaml']]
changed=set(run('git','diff','--name-only','HEAD').splitlines())|set(run('git','ls-files','--others','--exclude-standard').splitlines());assert changed==set(paths),(changed,set(paths))
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','plan(cpp-rt-car): activate M27-04 optional native telemetry exporters'),flush=True)
assert not run('git','status','--porcelain');head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-04-plan-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','-u','origin','agent/cpp-m27-04-plan'),flush=True)
body=f"""Activate M27-04 after completed target288/control594. Deliver an optional installed host-side telemetry source kit with bounded queue/loss/lifecycle semantics and explicit session/Runtime/clock correlation. Use native Perfetto protobuf and OTLP HTTP/protobuf with real Trace Processor and Collector validation; collect and decode actual Windows TraceLogging events on the existing Windows CI. The intermediate spool is explicitly not a native format.

Preserve Runtime, original tests, experimental/native sources, default SDK headers/targets, ABI/schema/default/support claims and predecessor evidence. Full local control validation PASS, head `{head}`, tree `{tree}`. Require focused/negative/sanitizer/static/relocated/native/full/all32 exact-head target gates, risk review and guarded integration/canonical closure. Only04 selected;05..08 and independent qualification/release remain inactive. No target/local waiver.
"""
Path('/tmp/cpp-m27-04-plan-pr.md').write_text(body)
x=json.loads(run('gh','api','repos/tranquilWorks/portfolio-control/pulls?state=open&head=tranquilWorks:agent/cpp-m27-04-plan'));assert len(x)<=1
if x:number=x[0]['number']
else:
 p=Path('/tmp/cpp-m27-04-plan-create.json');p.write_text(json.dumps({'title':'plan(cpp-rt-car): M27-04 optional native telemetry exporters','head':'agent/cpp-m27-04-plan','base':'main','draft':True,'body':body}));raw=run('gh','api','--method','POST','repos/tranquilWorks/portfolio-control/pulls','--input',str(p));Path('/tmp/cpp-m27-04-plan-create-result.json').write_text(raw+'\n');number=json.loads(raw)['number']
Path('/tmp/cpp-m27-04-plan-pr-number.txt').write_text(str(number)+'\n');print('https://github.com/tranquilWorks/portfolio-control/pull/'+str(number),flush=True)
