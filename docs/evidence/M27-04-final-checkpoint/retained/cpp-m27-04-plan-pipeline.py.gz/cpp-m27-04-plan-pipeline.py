from pathlib import Path
import subprocess,json,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/control/cpp-rt-car-m24')
for _ in range(180):
 if 'Control plane validation passed.' in Path('/tmp/cpp-m27-04-plan-control.log').read_text():break
 time.sleep(5)
else:raise SystemExit('local validation pending/failed')
for phase in ['publish','merge']:
 if phase=='merge':
  head=Path('/tmp/cpp-m27-04-plan-identity.txt').read_text().splitlines()[0]
  for _ in range(120):
   p=subprocess.run(['gh','api',f'repos/tranquilWorks/portfolio-control/commits/{head}/check-runs?per_page=100'],capture_output=True,text=True,timeout=90)
   if p.returncode==0:
    checks=json.loads(p.stdout)['check_runs']
    if len(checks)==1 and checks[0]['status']=='completed':break
   time.sleep(10)
  else:raise SystemExit('hosted validation pending')
 with open('/tmp/cpp-m27-04-plan-'+phase+'.log','w') as f:p=subprocess.run(['python3','/tmp/cpp-m27-04-plan-'+phase+'.py'],cwd=r,stdout=f,stderr=subprocess.STDOUT)
 print(phase,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
