from pathlib import Path
import json,subprocess,hashlib,os,resource,time
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
bindings=json.loads(Path('/tmp/cpp-m27-04-gate-source-bindings04.json').read_text());records=[]
def check():assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v for p,v in bindings.items())
def limits():resource.setrlimit(resource.RLIMIT_FSIZE,(2097152,2097152))
def run(name,cmd,env=None,limited=False):
 check();log=Path('/tmp/cpp-m27-04-loss-final-'+name+'.log');start=time.monotonic()
 with log.open('w') as f:
  f.write('COMMAND '+json.dumps(cmd)+'\n');f.flush()
  try:p=subprocess.run(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=90,preexec_fn=limits if limited else None);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 records.append(dict(name=name,command=cmd,exit=code,log=str(log),seconds=time.monotonic()-start));Path('/tmp/cpp-m27-04-loss-final-sanitizer-results.json').write_text(json.dumps(records,indent=2));check();return code,log.read_text()
common=['g++','-fno-pie','-no-pie','-std=c++20','-O1','-g','-pthread','-Irt/include','-Icore/include','-Iinclude','-Iintegrations/telemetry','integrations/telemetry/telemetry.cpp']
for label,source in [('queue','tests/telemetry_export/main.cpp'),('example','integrations/telemetry/main.cpp')]:
 for mode in ('asan','tsan'):
  binary='/tmp/cpp-m27-04-loss-final-'+label+'-'+mode
  flag='-fsanitize=address,undefined' if mode=='asan' else '-fsanitize=thread'
  code,_=run(label+'-'+mode+'-build',common+[source,'build/agent-quick/librtfw_runtime.a',flag,'-fno-omit-frame-pointer','-o',binary]);assert code==0
  if mode=='asan':
   code,_=run(label+'-'+mode,[binary],dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'),True);assert code==0
  else:
   for n in range(1,101):
    code,out=run(label+'-tsan-%02d'%n,[binary],dict(os.environ,TSAN_OPTIONS='halt_on_error=1:verbosity=1'),True)
    if code==0:
     assert 'Running under ThreadSanitizer' in out;break
    if 'WARNING: ThreadSanitizer' in out:raise SystemExit('Actual TSan finding '+records[-1]['log'])
    # Actual pre-main mmap/allocator SIGSEGV stack retained in tsan-diagnostics/attempt04.log.
    body='\n'.join(out.splitlines()[1:]).strip()
    if 'unexpected memory mapping' in out or (code==-11 and not body):continue
    raise SystemExit('Unclassified TSan failure '+records[-1]['log'])
   else:raise SystemExit('No initialized TSan pass; UNPERFORMED')
code,out=run('static',['clang++-14','--analyze','-std=c++20','-Xanalyzer','-analyzer-output=text','-Irt/include','-Icore/include','-Iinclude','-Iintegrations/telemetry','integrations/telemetry/telemetry.cpp','-o','/tmp/cpp-m27-04-final-static.plist']);assert code==0 and 'warning:' not in out
print('PASS queue and shipped example ASan/UBSan/leaks, initialized TSan, clang static; no suppressions; unchanged Runtime archive not reinstrumented',flush=True)
