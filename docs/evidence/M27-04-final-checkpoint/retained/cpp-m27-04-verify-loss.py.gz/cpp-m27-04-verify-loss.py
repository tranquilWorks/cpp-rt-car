from pathlib import Path
import importlib.util,sys,json,hashlib
p=Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('export',p);e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
raw=Path('/tmp/cpp-m27-04-spool-loss-negative.ndjson')
print('SOURCE',p,hashlib.sha256(p.read_bytes()).hexdigest(),'INPUT',hashlib.sha256(raw.read_bytes()).hexdigest())
try:
 with raw.open('rb') as f:e.load_spool(f)
except ValueError as ex:print('PASS deleted event without reported loss rejected:',ex);raise SystemExit(0)
print('FAIL deleted event accepted with reported loss0');raise SystemExit(42)
