from pathlib import Path
import json,subprocess,fnmatch,yaml
r=Path('/home/kbianco/.local/share/portfolio-control/worktrees/targets/cpp-rt-car-m24')
def run(*a):return subprocess.check_output(a,cwd=r,text=True,timeout=180).strip()
assert 'completed=' in Path('/tmp/cpp-m27-04-contract05.log').read_text()
assert 'PASS default/optional actual CPack' in Path('/tmp/cpp-m27-04-package02.log').read_text()
assert 'PASS queue and shipped example' in Path('/tmp/cpp-m27-04-final-sanitizers-progress.log').read_text()
b=yaml.safe_load((r/'contracts/active-batch.yaml').read_text());paths=run('git','diff','--name-only','HEAD').splitlines()+run('git','ls-files','--others','--exclude-standard').splitlines()
for p in paths:
 assert any(fnmatch.fnmatch(p,x) for x in b['scope']['allowed_paths']),p
 assert not any(p.startswith(x) if x.endswith('/') else fnmatch.fnmatch(p,x) for x in b['scope']['forbidden_paths']),p
run('git','add','--',*paths);run('git','diff','--cached','--check');print(run('git','commit','-m','fix: validate telemetry sample clocks and native Windows consumers'),flush=True)
head=run('git','rev-parse','HEAD');tree=run('git','rev-parse','HEAD^{tree}');Path('/tmp/cpp-m27-04-candidate02-identity.txt').write_text(head+'\n'+tree+'\n');print(run('git','push','origin','agent/m27-04-telemetry'),flush=True)
p=Path('/tmp/cpp-m27-04-pr.md');s=p.read_text()+f'\nCandidate02 `{head}` fixes the actual TSan sample-clock race with atomic clock reads and the Windows TraceLogging string_view compile failure with a terminated local string. It strengthens actual ETL/TDH value checks and adds an installed/relocated Windows ETW consumer. Fresh queue/sample ASan/UBSan/leaks and initialized TSan, static analysis,25 preserved observability/no-allocation tests, default/optional relocated CPack/native consumers/all71 existing SDK consumers and eight transport negatives PASS. Prior failures remain retained. Windows collection and final full/all32 exact-head/risk/integration gates remain mandatory and pending.\n';p.write_text(s);payload=Path('/tmp/cpp-m27-04-pr-body02.json');payload.write_text(json.dumps({'body':s}));run('gh','api','--method','PATCH','repos/tranquilWorks/cpp-rt-car/pulls/289','--input',str(payload));print('Candidate02 published',head,tree,flush=True)
